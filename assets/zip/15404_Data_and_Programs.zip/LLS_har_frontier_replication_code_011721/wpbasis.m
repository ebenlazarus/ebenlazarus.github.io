%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function computes the set of Fourier basis functions.
% Inputs:
% T: sample size
% B_T: number of basis functions (for each sin and cos)
% Outputs:
% wpbasis: matrix of basis functions
function [wpbasis]=wpbasis(T,B_T)
trange=1:T;
mrange=1:B_T;
f_t1=@(t) 2^.5*cos(mrange'*2*t*pi/T);
f_t2=@(t) 2^.5*sin(mrange'*2*t*pi/T);
coss=f_t1(trange);
sins=f_t2(trange);
wpbasis=[];
for i=1:B_T
    wpbasis=[wpbasis;coss(i,:);sins(i,:)];
end
end

