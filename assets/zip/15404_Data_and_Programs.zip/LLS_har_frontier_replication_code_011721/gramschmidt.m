%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function performs Gram-Schmidt orthonormalization.
% Inputs:
% a: non-orthonormal basis functions
% Outputs:
% b: orthonormalized basis functions
function b = gramschmidt(a)
tt = size(a,1); 
m = size(a,2);
b = a;
for j = 2:m
    bhatj = (b(:,1:(j-1))'*b(:,1:(j-1)))\(b(:,1:(j-1))'*b(:,j));
    b(:,j) = b(:,j)-b(:,1:(j-1))*bhatj;
end
b = b./( ones(tt,1)*sqrt(mean(b.*b)) );
b'*b/tt;
end
