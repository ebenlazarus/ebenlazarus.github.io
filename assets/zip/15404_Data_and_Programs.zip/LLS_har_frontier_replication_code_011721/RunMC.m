%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file runs all Monte Carlo specification used to generate the figures
% in the Supplement, S4-S7, S9-S11. The results should be loaded into the
% workspace before running Constructfigures.m.

% Run MC for all figures
% Location, m=1
 [a55,b55]=MCsizepower(.5,50,@ARmean,100000,1,1);
 disp('1')
 [a51,b51]=MCsizepower(.5,100,@ARmean,100000,1,1);
  disp('2')
 [a52,b52]=MCsizepower(.5,200,@ARmean,100000,1,1);
  disp('3')
 [a54,b54]=MCsizepower(.5,400,@ARmean,100000,1,1);
  disp('4')
 [a58,b58]=MCsizepower(.5,800,@ARmean,100000,1,1);
  disp('5')
 [a516,b516]=MCsizepower(.5,1600,@ARmean,100000,1,1);
  disp('6')
[a72,b72]=MCsizepower(.7,200,@ARmean,100000,1,1);
  disp('7')

% Stochastic, m=1
[a52s,b52s]=MCsizepower(.5,200,@stochasAR,100000,1,1);
 disp('8')

% Stochastic, m=2
[a52s2,b52s2]=MCsizepower(.5,200,@stochasAR,100000,2,2);
 disp('9')

% ARMA, m=1
[a4,b4]=MCsizepower([.04782;.248;-.064],200,@ARMA21,100000,1,1);
 disp('10')

% Location, m=2
 [al25,bl25]=MCsizepower(.5,200,@loc2,100000,2,2);
  disp('11')
 [al27,bl27]=MCsizepower(.7,200,@loc2,100000,2,2);
  disp('12')
