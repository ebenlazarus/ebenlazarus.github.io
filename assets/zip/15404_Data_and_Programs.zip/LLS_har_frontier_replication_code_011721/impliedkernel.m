%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function computes the implied mean kernel in the time domain and 
% frequency domain for orthogonal basis functions (as in Figures S1 and S2)
% Inputs:
% pbasis: Tx(dof+1) matrix of basis functions (including "zeroth" basis
% function)
% Outputs:
% ktime: values of the implied mean time domain kernel
% kfreq: values of the implied mean frequency domain kernel

function [ktime,kfreq] = impliedkernel(pbasis)
% pbasis: basis functions
tt = size(pbasis,1);
ndf = size(pbasis,2);
k = zeros(tt,1);
for j = 1:tt
    for m = 1:ndf
        k(j) = k(j) + pbasis(1:(tt-j+1),m)'*pbasis(j:tt,m);
    end
end
ktime = k/(ndf*pbasis(:,1)'*pbasis(:,1));
ktime = ktime./(1-(0:(tt-1)/tt));
kfreq = zeros(tt,1);
om1 = 2*pi*(1:(tt-1))'/tt;
for j = 1:tt
    kfreq(j) = ktime(1) + 2*cos(om1*(j-1))'*ktime(2:end);
end
kfreq = kfreq/(tt/ndf);
end
