%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file computes the size-adjusted power loss values and curves found
% Table 1 in the main text and Figure S1.
 
clear all;
close all;
table=NaN(4,3);
for m=1:4 % restrictions to test
    %% Setup
    % Parameters
    
    alpha = 0.05; % Nominal significance level of test
    delta_sq = [0:0.25:25]'; % Chi-squared noncentrality parameter values to calculate over
    
    % Calculate relevant quantile and pdf values
    chi_quantile = chi2inv(1-alpha,m); % 1-alpha quantile of relevant chi-squared
    chi_nc_pdf = ncx2pdf(chi_quantile,m+2,delta_sq); % PDF of noncentral chi-squared with m+2 df at chi_quantile value, across all values of delta_sq
    
    % Kernel or basis function degrees of freedom selection
    nu_ewp = [4 8 16]; % Calculate for Fourier-4, -8, and -16 for now
    nu_adjust_to_qs = (6.2832/5.8403); % Adjustment from EWP to QS (change if not using EWP)
    nu_qs = nu_adjust_to_qs*nu_ewp; % Calculate equivalent df for QS
    % Calculate power loss versus QS for eqch value of delta_sq
    loss = delta_sq/2.*chi_nc_pdf*chi_quantile*(1./nu_ewp-1./nu_qs);
    table(m,:)=max(loss);
    if m==1
        %% Plot   
        figure;
        lw = 1; % line width
        p1 = plot(delta_sq,loss(:,1),'b-',delta_sq,loss(:,2),'r--',delta_sq,loss(:,3),'g:');
        p1(1).LineWidth = lw;
        p1(2).LineWidth = lw;
        p1(3).LineWidth = lw;
        lg1 = legend('EWP-4','EWP-8','EWP-16','Location','NorthEast');
        set(lg1,'Interpreter','latex');
        legend(gca,'boxoff');
        xl1 = xlabel(gca,'$\chi^2$ Noncentrality Parameter ($\delta^2$)');
        set(xl1,'Interpreter','latex');
        yl1 = ylabel('Size-Adjusted Power Loss Against Local Alternative');
        set(yl1,'Interpreter','latex');
        ylim(gca,[0 0.018]);
        set(gca,'XColor','k');
        set(gca,'YColor','k');
    end
end
table
