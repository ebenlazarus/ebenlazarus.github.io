%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function generates data from an AR(1) location model, estimates the
% mean, and outputs the residuals times the regressor (a constant), the
% estimated mean, the raw data, and the residuals. 
% Inputs:
% T: sample length
% rho: AR parameter
% Outputs:
% zeta: residuals times regressor (a constant)
% b: estimated mean
% y: raw simulated data
% data: RHS variable (constant)
% r: residuals
function [zeta,b,y,data,r]=ARmean(T,rho,~)
% Simulate data
u = filter(1, [1 -rho], randn(T,1)); %Generate autocorrelated errors u_t = rho*u_{t-1} + epsilon_t, t=1,2,...,T
y = 0 + u; %Generate y_t = beta + u_t
data=ones(T,1);
[b,~,r]=regress(y,data);
zeta=r; %Generate zeta
end




