%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file generates Figure 1 in the main text of the paper. 

xaxis=0:.001:.5;
% Set externally calculated constants (see genconstants.m):
c(1)=.3368;
c(2)=.3624;
c(3)=.646;
c(4)=.695;
c(5)=.9491;
c(6)=1.0211;

% Produce figure:
figure
for i=1:6
ploss=c(i)*1./sqrt(xaxis); % see equations (28) and (29)
plot(xaxis,ploss)
if i==1 
    hold on
end
if i==6
    legend('All, m=1','t/F critical values, m=1','All, m=2','t/F critical values, m=2','All, m=3','t/F critical values, m=3')
    hold off
end
ylim([0 12])
xlabel('$\frac{T^{2/3} \Delta_{S}}{\omega^{(2)}}$')
ylabel('$T^{2/3}\Delta_{P}^{max}$')
end
