%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function computes the Newey-West kernel.
% Inputs:
% T: sample size
% B_T: truncation parameter
% Outputs:
% nwkernel: vector of kernel values
function nwkernel=nwkernel(T,B_T)
mrange=1:B_T-1;
nwkernel=(B_T-mrange)/B_T;
nwkernel=[nwkernel,zeros(1,T-B_T)];
end
