%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function generates data from an ARMA(2,1) process, estimates the
% mean, and outputs the residuals times the regressor (a constant), the
% estimated mean, the raw data, and the residuals. 
% Inputs:
% T: sample length
% params: ARMA params
% Outputs:
% zeta: residuals times regressor (a constant)
% b: estimated mean
% y: raw simulated data
% data: RHS variable (constant)
% r: residuals
function [zeta,b,y,data,r]=ARMA21(T,params,~)
% assign model parameters
alpha1=params(1);
alpha2=params(2);
theta=params(3);
model = arima('Constant',0,'AR',{alpha1,alpha2},'MA',theta,'Variance',1); % generate data from ARMA(2,1)
y=simulate(model,T);
data=ones(T,1);
[b,~,r]=regress(y,data);
zeta=r; %Generate zeta
end
