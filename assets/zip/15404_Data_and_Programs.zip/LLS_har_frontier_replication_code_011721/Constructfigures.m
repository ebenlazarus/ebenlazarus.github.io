%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file constructs the Monte Carlo figures in the Supplement, S2-S3, as 
% well as many additional Monte Carlo figures included in the Supplement of
% the working paper version. 
% First, RunMC should be run to conduct all simulations and the results 
% should be loaded in the Matlab workspace.
%% Preliminary values
c1=[.3368,.0637,.3624,.3624,.0956]';
c2=[0.6460 0.1398 0.6950 0.6950 0.2097]';
dels=0:.0001:.4;



%% QS/NW/EWP comparison - Location (Figure S2)
% Estimators against theory - one figure for each estimator, for each class
% of DGP/m
w2=4;
w1=4/3;
frontiersloc5=@(T) repmat(c1.*[w2;w1;w2;w2;w1].^[.5,;1;.5;.5;1],1,length(dels))./(repmat(dels,5,1).^repmat([.5,;1;.5;.5;1],1,length(dels))*T);
MCsize5=abs(a52-.05);
dx=.002;
dy=.002;
labs=cellstr({'8' '16' '32' '64'});
labsNW=cellstr({'8' '16' '32' '64','KVB'});
cols=[1,0,0;0,0,1];
marks=cellstr({'+','o','*'});
lines=cellstr({'-','--',':'});
figure
for i=1:3
    hold on
    % Frontiers
    ft=frontiersloc5(200);
    plot(dels,ft(i,:),char(lines(i)),'Color',cols(1,:));

    % MC scatters
    if i==2 % Need to add KVB to NW plots
        scatter([MCsize5(4*i-3:i*4),MCsize5(end)],[b52(4*i-3:i*4),b52(end)],'MarkerEdgeColor',cols(1,:))
        text([MCsize5(4*i-3:i*4),MCsize5(end)]+dx,[b52(4*i-3:i*4),b52(end)]+dy,labsNW, 'FontSize',12);

    else
        scatter(MCsize5(4*i-3:i*4),b52(4*i-3:i*4),char(marks(i)),'MarkerEdgeColor',cols(1,:))
        text(MCsize5(4*i-3:i*4)+dx,b52(4*i-3:i*4)+dy,labs, 'FontSize',12);


    end
end
% Formatting
xlim([0,min(max(MCsize5(1:12)+.01),.25)]);

ylim([0,b52(end)+.01]);
set(gca,'FontSize',16)
xl1=xlabel('$\Delta_{S}$');
yl1=ylabel('$\Delta_{P}^{max}$');
set(xl1,'Interpreter','latex');
set(yl1,'Interpreter','latex');
t=title('Location Model, $\alpha=0.5, T=200$');
set(t,'Interpreter','latex');
legend('QS','QS','NW','NW','EWP','EWP');
legend('boxoff')
hold off

%% QS/NW/EWP comparison - Location m=2
% Estimators against theory - one figure for each estimator, for each class
% of DGP/m
w2=4;
w1=4/3;
frontier=@(T) repmat(c2.*[w2;w1;w2;w2;w1].^[.5,;1;.5;.5;1],1,length(dels))./(repmat(dels,5,1).^repmat([.5,;1;.5;.5;1],1,length(dels))*T);
MCsize5=abs(al25-.05);
dx=.002;
dy=.002;
labs=cellstr({'8' '16' '32' '64'});
labsNW=cellstr({'8' '16' '32' '64','KVB'});
cols=[1,0,0;0,0,1];
marks=cellstr({'+','o','*'});
lines=cellstr({'-','--',':'});
figure
for i=1:3
hold on
% Frontiers

ft=frontier(200);
plot(dels,ft(i,:),char(lines(i)),'Color',cols(1,:));

% MC scatters
if i==2 % Need to add KVB to NW plots
scatter([MCsize5(4*i-3:i*4),MCsize5(end)],[bl25(4*i-3:i*4),bl25(end)],'MarkerEdgeColor',cols(1,:))
text([MCsize5(4*i-3:i*4),MCsize5(end)]+dx,[bl25(4*i-3:i*4),bl25(end)]+dy,labsNW, 'FontSize',12);

else
scatter(MCsize5(4*i-3:i*4),bl25(4*i-3:i*4),char(marks(i)),'MarkerEdgeColor',cols(1,:))
text(MCsize5(4*i-3:i*4)+dx,bl25(4*i-3:i*4)+dy,labs, 'FontSize',12);
end
end
% Formatting
xlim([0,min(max(MCsize5(1:12)+.01),.25)]);
ylim([0,bl25(end)+.01]);
set(gca,'FontSize',16)
xl1=xlabel('$\Delta_{S}$');
yl1=ylabel('$\Delta_{P}^{max}$');
set(xl1,'Interpreter','latex');
set(yl1,'Interpreter','latex');
t=title('Location, $m=2, \alpha=0.5, T=200$');
set(t,'Interpreter','latex');
legend('QS','QS','NW','NW','EWP','EWP');
legend('boxoff')
hold off

%% QS/NW/EWP comparison - Stochastic m=1 (Figure S3)
% Estimators against theory - one figure for each estimator, for each class
% of DGP/m
w2=0.8889;
w1=0.5333;
frontierstoch5=@(T) repmat(c1.*[w2;w1;w2;w2;w1].^[.5,;1;.5;.5;1],1,length(dels))./(repmat(dels,5,1).^repmat([.5,;1;.5;.5;1],1,length(dels))*T);
MCsize5=abs(a52s-.05);

dx=.002;
dy=.002;
labs=cellstr({'8' '16' '32' '64'});
labsNW=cellstr({'8' '16' '32' '64','KVB'});
cols=[1,0,0;0,0,1];
marks=cellstr({'+','o','*'});
lines=cellstr({'-','--',':'});
figure
for i=1:3
    hold on
    % Frontiers

    ft=frontierstoch5(200);
    plot(dels,ft(i,:),char(lines(i)),'Color',cols(1,:));



    % MC scatters
    if i==2 % Need to add KVB to NW plots
        scatter([MCsize5(4*i-3:i*4),MCsize5(end)],[b52s(4*i-3:i*4),b52s(end)],'MarkerEdgeColor',cols(1,:))
        text([MCsize5(4*i-3:i*4),MCsize5(end)]+dx,[b52s(4*i-3:i*4),b52s(end)]+dy,labsNW, 'FontSize',12);

    else
        scatter(MCsize5(4*i-3:i*4),b52s(4*i-3:i*4),char(marks(i)),'MarkerEdgeColor',cols(1,:))
        text(MCsize5(4*i-3:i*4)+dx,b52s(4*i-3:i*4)+dy,labs, 'FontSize',12);


    end
end
% Formatting
xlim([0,min(max(MCsize5(1:12)+.01),.25)]);

ylim([0,b52s(end)+.01]);
set(gca,'FontSize',16)
xl1=xlabel('$\Delta_{S}$');
yl1=ylabel('$\Delta_{P}^{max}$');
set(xl1,'Interpreter','latex');
set(yl1,'Interpreter','latex');
t=title('Stochastic Regressor, $m=1, \alpha=0.5, T=200$');
set(t,'Interpreter','latex');
legend('QS','QS','NW','NW','EWP','EWP');
legend('boxoff')
hold off

%% Location Figures by Estimator
w2=4;
w1=4/3;
frontiersloc5=@(T) repmat(c1.*[w2;w1;w2;w2;w1].^[.5,;1;.5;.5;1],1,length(dels))./(repmat(dels,5,1).^repmat([.5,;1;.5;.5;1],1,length(dels))*T);
Ts=[50,100,200,400,800,1600];
% Estimators against theory - one figure for each estimator, for each class
% of DGP/m
% Calculate distortion from nominal size
MCsize5=abs(a55-.05);
MCsize1=abs(a51-.05);
MCsize2=abs(a52-.05);
MCsize4=abs(a54-.05);
MCsize8=abs(a58-.05);
MCsize16=abs(a516-.05);
dx=.002;
dy=.002;
labs=cellstr({'8' '16' '32' '64'});
labsNW=cellstr({'8' '16' '32' '64','KVB'});
titles=cellstr({'QS' 'NW' 'EWP' 'COS' 'SS'});
cols=[1,.5,0;1,0,1;0,1,1;1,0,0;0,1,0;0,0,1];
for i=1:5
figure
hold on
% Frontiers
for t=1:6
T=Ts(t);
ft=frontiersloc5(T);
plot(dels,ft(i,:),'Color',cols(t,:));
end
legend('T=50','T=100','T=200','T=400','T=800','T=1600','AutoUpdate','off');
legend('boxoff')
% MC scatters
if i==2 % Need to add KVB to NW plots
scatter([MCsize5(4*i-3:i*4),MCsize5(end)],[b55(4*i-3:i*4),b55(end)],'MarkerEdgeColor',cols(1,:))
text([MCsize5(4*i-3:i*4),MCsize5(end)]+dx,[b55(4*i-3:i*4),b55(end)]+dy,labsNW, 'FontSize',12);
scatter([MCsize1(4*i-3:i*4),MCsize1(end)],[b51(4*i-3:i*4),b51(end)],'MarkerEdgeColor',cols(2,:))
text([MCsize1(4*i-3:i*4),MCsize1(end)]+dx,[b51(4*i-3:i*4),b51(end)]+dy,labsNW, 'FontSize',12);
scatter([MCsize2(4*i-3:i*4),MCsize2(end)],[b52(4*i-3:i*4),b52(end)],'MarkerEdgeColor',cols(3,:))
text([MCsize2(4*i-3:i*4),MCsize2(end)]+dx,[b52(4*i-3:i*4),b52(end)]+dy,labsNW, 'FontSize',12);
scatter([MCsize4(4*i-3:i*4),MCsize4(end)],[b54(4*i-3:i*4),b54(end)],'MarkerEdgeColor',cols(4,:))
text([MCsize4(4*i-3:i*4),MCsize4(end)]+dx,[b54(4*i-3:i*4),b54(end)]+dy,labsNW, 'FontSize',12);
scatter([MCsize8(4*i-3:i*4),MCsize8(end)],[b58(4*i-3:i*4),b58(end)],'MarkerEdgeColor',cols(5,:))
text([MCsize8(4*i-3:i*4),MCsize8(end)]+dx,[b58(4*i-3:i*4),b58(end)]+dy,labsNW, 'FontSize',12);
scatter([MCsize16(4*i-3:i*4),MCsize16(end)],[b516(4*i-3:i*4),b516(end)],'MarkerEdgeColor',cols(6,:))
text([MCsize16(4*i-3:i*4),MCsize16(end)]+dx,[b516(4*i-3:i*4),b516(end)]+dy,labsNW, 'FontSize',12);
else
scatter(MCsize5(4*i-3:i*4),b55(4*i-3:i*4),'MarkerEdgeColor',cols(1,:))
text(MCsize5(4*i-3:i*4)+dx,b55(4*i-3:i*4)+dy,labs, 'FontSize',12);
scatter(MCsize1(4*i-3:i*4),b51(4*i-3:i*4),'MarkerEdgeColor',cols(2,:))
text(MCsize1(4*i-3:i*4)+dx,b51(4*i-3:i*4)+dy,labs, 'FontSize',12);
scatter(MCsize2(4*i-3:i*4),b52(4*i-3:i*4),'MarkerEdgeColor',cols(3,:))
text(MCsize2(4*i-3:i*4)+dx,b52(4*i-3:i*4)+dy,labs, 'FontSize',12);
scatter(MCsize4(4*i-3:i*4),b54(4*i-3:i*4),'MarkerEdgeColor',cols(4,:))
text(MCsize4(4*i-3:i*4)+dx,b54(4*i-3:i*4)+dy,labs, 'FontSize',12);
scatter(MCsize8(4*i-3:i*4),b58(4*i-3:i*4),'MarkerEdgeColor',cols(5,:))
text(MCsize8(4*i-3:i*4)+dx,b58(4*i-3:i*4)+dy,labs, 'FontSize',12);
scatter(MCsize16(4*i-3:i*4),b516(4*i-3:i*4),'MarkerEdgeColor',cols(6,:))
text(MCsize16(4*i-3:i*4)+dx,b516(4*i-3:i*4)+dy,labs, 'FontSize',12);
end

% Formatting
xlim([0,min(max(MCsize5(4*i-3:i*4)+.01),.25)]);
ylim([0,min(max(b55(4*i-3:i*4)+.01),.25)]);
if i==2
ylim([0,b55(end)+.01]);
end
set(gca,'FontSize',16)
xl1=xlabel('$\Delta_{S}$');
yl1=ylabel('$\Delta_{P}^{max}$');
set(xl1,'Interpreter','latex');
set(yl1,'Interpreter','latex');
title(titles(i))
hold off
end

%% QS/NW/EWP comparison - ARMA21
% Estimators against theory - one figure for each estimator, for each class
% of DGP/m
w2=4;
w1=1.9933;
frontiersarma=@(T) repmat(c1.*[w2;w1;w2;w2;w1].^[.5,;1;.5;.5;1],1,length(dels))./(repmat(dels,5,1).^repmat([.5,;1;.5;.5;1],1,length(dels))*T);


MCsize5=abs(a4-.05);

dx=.002;
dy=.002;
labs=cellstr({'8' '16' '32' '64'});
labsNW=cellstr({'8' '16' '32' '64','KVB'});
cols=[1,0,0;0,0,1];
marks=cellstr({'+','o','*'});
lines=cellstr({'-','--',':'});
figure
for i=1:3
hold on
% Frontiers
ft=frontiersarma(200);
plot(dels,ft(i,:),char(lines(i)),'Color',cols(1,:));

% MC scatters
if i==2 % Need to add KVB to NW plots
scatter([MCsize5(4*i-3:i*4),MCsize5(end)],[b4(4*i-3:i*4),b4(end)],'MarkerEdgeColor',cols(1,:))
text([MCsize5(4*i-3:i*4),MCsize5(end)]+dx,[b4(4*i-3:i*4),b4(end)]+dy,labsNW, 'FontSize',12);

else
scatter(MCsize5(4*i-3:i*4),b4(4*i-3:i*4),char(marks(i)),'MarkerEdgeColor',cols(1,:))
text(MCsize5(4*i-3:i*4)+dx,b4(4*i-3:i*4)+dy,labs, 'FontSize',12);

end
end
% Formatting
xlim([0,min(max(MCsize5(1:12)+.01),.25)]);

ylim([0,max(b4(end),b4(end))+.01]);
set(gca,'FontSize',16)
xl1=xlabel('$\Delta_{S}$');
yl1=ylabel('$\Delta_{P}^{max}$');
set(xl1,'Interpreter','latex');
set(yl1,'Interpreter','latex');
title('ARMA(2,1) Model')
legend('QS','QS','NW','NW','EWP','EWP');
legend('boxoff')
hold off

%% Location, m=2, by Estimator
w2=4;
w1=4/3;
frontier5=@(T) repmat(c2.*[w2;w1;w2;w2;w1].^[.5,;1;.5;.5;1],1,length(dels))./(repmat(dels,5,1).^repmat([.5,;1;.5;.5;1],1,length(dels))*T);
w2=15.5556;
w1=2.7451;
frontier7=@(T) repmat(c2.*[w2;w1;w2;w2;w1].^[.5,;1;.5;.5;1],1,length(dels))./(repmat(dels,5,1).^repmat([.5,;1;.5;.5;1],1,length(dels))*T);
% Estimators against theory - one figure for each estimator, for each class
% of DGP/m

MCsize5=abs(al25-.05);
MCsize7=abs(al27-.05);

dx=.002;
dy=.002;
labs=cellstr({'8' '16' '32' '64'});
labsNW=cellstr({'8' '16' '32' '64','KVB'});
titles=cellstr({'QS' 'NW' 'EWP' 'COS' 'SS'});
for i=1:5
figure
hold on
% Frontiers
ft=frontier5(200);
plot(dels,ft(i,:),'b');
ft=frontier7(200);
plot(dels,ft(i,:),'r');

legend('\alpha=.5','\alpha=.7','AutoUpdate','off');
legend('boxoff')
% MC scatters
if i==2 % Need to add KVB to NW plots
scatter([MCsize5(4*i-3:i*4),MCsize5(end)],[bl25(4*i-3:i*4),bl25(end)],'b')
text([MCsize5(4*i-3:i*4),MCsize5(end)]+dx,[bl25(4*i-3:i*4),bl25(end)]+dy,labsNW, 'FontSize',12);
scatter([MCsize7(4*i-3:i*4),MCsize7(end)],[bl27(4*i-3:i*4),bl27(end)],'r')
text([MCsize7(4*i-3:i*4),MCsize7(end)]+dx,[bl27(4*i-3:i*4),bl27(end)]+dy,labsNW, 'FontSize',12);

else
scatter(MCsize5(4*i-3:i*4),bl25(4*i-3:i*4),'b')
text(MCsize5(4*i-3:i*4)+dx,bl25(4*i-3:i*4)+dy,labs, 'FontSize',12);
scatter(MCsize7(4*i-3:i*4),bl27(4*i-3:i*4),'r')
text(MCsize7(4*i-3:i*4)+dx,bl27(4*i-3:i*4)+dy,labs, 'FontSize',12);

end

% Formatting
xlim([0,min(max(MCsize7(4*i-3:i*4)+.01),.25)]);
ylim([0,min(max(bl27(4*i-3:i*4)+.01),.25)]);
if i==2
ylim([0,max(bl25(end),bl27(end))+.03]);
end
set(gca,'FontSize',16)
xl1=xlabel('$\Delta_{S}$');
yl1=ylabel('$\Delta_{P}^{max}$');
set(xl1,'Interpreter','latex');
set(yl1,'Interpreter','latex');
title(titles(i))
hold off
end


%% QS/NW/EWP comparison - Stochastic m=2
% Estimators against theory - one figure for each estimator, for each class
% of DGP/m
w2=0.8889;
w1=0.5333;
frontierstoch25=@(T) repmat(c2.*[w2;w1;w2;w2;w1].^[.5,;1;.5;.5;1],1,length(dels))./(repmat(dels,5,1).^repmat([.5,;1;.5;.5;1],1,length(dels))*T);


MCsize5=abs(a52s2-.05);

dx=.002;
dy=.002;
labs=cellstr({'8' '16' '32' '64'});
labsNW=cellstr({'8' '16' '32' '64','KVB'});
cols=[1,0,0;0,0,1];
marks=cellstr({'+','o','*'});
lines=cellstr({'-','--',':'});
figure
for i=1:3
    hold on
    % Frontiers

    ft=frontierstoch25(200);
    plot(dels,ft(i,:),char(lines(i)),'Color',cols(1,:));

    % MC scatters
    if i==2 % Need to add KVB to NW plots
        scatter([MCsize5(4*i-3:i*4),MCsize5(end)],[b52s2(4*i-3:i*4),b52s2(end)],'MarkerEdgeColor',cols(1,:))
        text([MCsize5(4*i-3:i*4),MCsize5(end)]+dx,[b52s2(4*i-3:i*4),b52s2(end)]+dy,labsNW, 'FontSize',12);

    else
        scatter(MCsize5(4*i-3:i*4),b52s2(4*i-3:i*4),char(marks(i)),'MarkerEdgeColor',cols(1,:))
        text(MCsize5(4*i-3:i*4)+dx,b52s2(4*i-3:i*4)+dy,labs, 'FontSize',12);

    end
end
% Formatting

xlim([0,min(max(MCsize5(1:12)+.01),.25)]);

ylim([0,b52s2(end)+.01]);
set(gca,'FontSize',16)
xl1=xlabel('$\Delta_{S}$');
yl1=ylabel('$\Delta_{P}^{max}$');
set(xl1,'Interpreter','latex');
set(yl1,'Interpreter','latex');
t=title('Stochastic Regressor, $m=2, \alpha=0.5, T=200$');
set(t,'Interpreter','latex');
legend('QS','QS','NW','NW','EWP','EWP');
legend('boxoff')
hold off









