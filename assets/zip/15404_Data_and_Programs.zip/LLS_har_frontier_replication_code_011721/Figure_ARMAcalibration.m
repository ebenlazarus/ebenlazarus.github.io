%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file confirms that the ARMA(2,1) parameters used to calibrate the 
% alternative DGP yield the spectral density included as a figure in
% the Supplement of the working paper version and have the the property 
% that omega(2)=4 both analytically and numerically.

%% Spectral density of an ARMA(2,1) (analytically)
sd=@(w,alpha1,alpha2,theta) (1+2*theta*cos(w)+theta^2)/(conj(1-alpha1*exp(1i*w)-alpha2*exp(1i*w*2))*(1-alpha1*exp(1i*w)-alpha2*exp(1i*w*2))); % analytical formula
% Take analytical second derivative of SD
syms 'al1' 'al2' 'th' 'w1'
s=(1+2*th*cos(w1)+th^2)/(conj(1-al1*exp(1i*w1)-al2*exp(1i*w1*2))*(1-al1*exp(1i*w1)-al2*exp(1i*w1*2)));
spp=diff(s,w1,2);
% Evaluate -sd''(w)/sd(w)
omega2=@(w,alpha1,alpha2,theta) -1*subs(spp,[w1 al1 al2 th],[w alpha1 alpha2 theta])/sd(w,alpha1,alpha2,theta);


% For expositional purposes we want the ARMA(2,1) to have omega2=4, but
% have an "m-shaped" spectral density. The below parameters deliver that

alpha1=.04782;
alpha2=.248;
theta=-.064;
double(omega2(0,alpha1,alpha2,theta))
% Plot spectral density
densplot(alpha1,alpha2,theta)

%% Double check using ACF approach (numerically)
% We can compute the ACF for this ARMA using analytical formulas
% Solving these externally delivers the values below
psi0=1;
psi1=theta+alpha1*psi0;
gamma=zeros(100000,1);
gamma(1)=1.06554;
gamma(2)=-0.0173485;
gamma(3)=0.263423;
for j=4:100000
    gamma(j)=alpha1*gamma(j-1)+alpha2*gamma(j-2);
end
% To check this, simulate a bunch of data, compute the ACF, and compare
z=ARMA21(10000000,[alpha1;alpha2;theta],[]);
acf=xcov(z,20,'biased');
figure
subplot(1,2,1)
plot(gamma(2:21))
subplot(1,2,2)
plot(acf(22:end))
% Confirmed: ACF is correct

% Now we can check the spectral density formula. We know we can also
% calculate this as the sum of ACF from -inf to inf
sd(0,alpha1,alpha2,theta)
2*ones(1,99999)*gamma(2:end)+gamma(1)
% Confirmed: SD is correct

% Now compare the  analytical second derivative to the parzen generalized 2nd derivative.
% They should differ only by sign. Note that the analytical derivative
% checks out against a numerical second derivative

% Analytical derivative:
double(subs(spp,[w1 al1 al2 th],[0 alpha1 alpha2 theta]))
% Parzen derivative:
j=0:99999;
j2=j.^2;
2*j2*gamma

%% Finally, reporting omega(2) and omega(1)
% Analytically,
double(omega2(0,alpha1,alpha2,theta))
% via ACF,
2*j2*gamma/(2*ones(1,99999)*gamma(2:end)+gamma(1))

% omega(1)
% via ACF,
2*j*gamma




