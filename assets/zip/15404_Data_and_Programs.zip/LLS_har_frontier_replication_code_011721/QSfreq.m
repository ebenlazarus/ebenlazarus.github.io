%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function computes the QS kernel in the frequency domain. 
% Inputs:
% T: sample size
% J: degrees of freedom
% Outputs:
% W: vector of kernel values
function [W]=QSfreq(T,J)
j=1:J;
M=T/J/2;
W=1-(M*2*j/T).^2;
W=W/sum(W);
W=[W,zeros(1,T-J)];
end
