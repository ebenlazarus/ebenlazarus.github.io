%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function generates data from a two-dimensional AR(1) location model, estimates the
% means, and outputs the residuals times the regressors (a constant), the
% estimated mean, the raw data, and the residuals. 
% Inputs:
% T: sample length
% rho: AR parameter (same for both dimensions)
% Outputs:
% zeta: residuals times regressor (a constant)
% b: estimated mean
% data: RHS variable (constant)
% r: residuals
function [zeta,b,y,data,r]=loc2(T,rho,~)
% rho: AR parameter
u1 = filter(1, [1 -rho], randn(T,1)); %Generate autocorrelated errors u_t = rho*u_{t-1} + epsilon_t, t=1,2,...,T
u2 = filter(1, [1 -rho], randn(T,1)); %Generate autocorrelated errors u_t = rho*u_{t-1} + epsilon_t, t=1,2,...,T
y1=u1;
y2=u2;
y=[y1 y2];
data=ones(T,1);
[b1,~,r1]=regress(y1,data); % estimate mean for first dimension
[b2,~,r2]=regress(y2,data); % estimate mean for second dimension
b=[b1;b2];
r=[r1,r2];
zeta=r; % generate zeta
end
