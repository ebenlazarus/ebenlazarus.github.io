%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function computes the KVB kernel.
% Inputs:
% T: sample size
% Outputs:
% kvbkernel: vector of kernel values
function kvbkernel=kvbkernel(T)
mrange=1:T-1;
kvbkernel=(1-mrange/T);
end
