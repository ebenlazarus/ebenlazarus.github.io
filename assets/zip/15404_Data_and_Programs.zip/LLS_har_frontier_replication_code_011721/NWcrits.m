%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file computes fixed-b critical values for the Newey-West LRV 
% estimator in the time domain. These values are hard-coded into the 
% file MCsizepower.
%% m=1

%initialize
tic
rng(715)
draws=100000;
T=10000;
dof=[8,16,32,64]; % degrees of freedom
SNW=ceil(3*T./(2*dof));
regs=1;
knw=[nwkernel(T,SNW(1));nwkernel(T,SNW(2));nwkernel(T,SNW(3));nwkernel(T,SNW(4))];
omegastoreNW=NaN(draws,4,regs,regs);
betadev=NaN(draws,1);

% Calculate test statistics based on white-noise data
for i=1:draws
    z=randn(T,1);
    betadev(i)=mean(z);
    zdemean=z-betadev(i);
    % Autocovariance Function
    ACF=0;
    for j=1:ceil(3/16*T)
        ACF(j,:)=reshape(((zdemean(j:end,:))'*(zdemean(1:end-j+1,:))),regs^2,1)/T; %Compute ACF at lag j without substracting mean - as per Jim's notes
    end
    ACF=[flipud(ACF(2:end,1));ACF];
    XX=1;
    % Calculate omega_hat
    for d=1:length(dof)
        omegastoreNW(i,d,:,:)=T/(T-regs)*XX^-1*reshape([fliplr(knw(d,1:(length(ACF)-1)/2)),1,knw(d,1:(length(ACF)-1)/2)]*ACF,regs,regs)*XX^-1;
    end
end

% Compute t-stats
tNW=T^.5*repmat(betadev,1,length(dof))./squeeze(omegastoreNW(:,:,1,1).^.5);
quantile(tNW,[.025,.975])
toc
%% m=2

% Intitialize
rng(715)
betadev=NaN(draws,2);
regs=2;
FNW=NaN(draws,length(dof));
omegastoreNW=NaN(draws,4,regs,regs);
tic

% Calculate test statistics based on white-noise data
for i=1:draws
    if 1000*floor(i/1000)==i
        i
    end
    z=randn(T,2);
    betadev(i,:)=mean(z);
    zdemean=z-repmat(betadev(i,:),T,1);
    % Compute Autocovariance Function
    ACF=NaN(ceil(3/16*T),regs^2);
    for j=1:ceil(3/16*T)
        ACF(j,:)=reshape(((zdemean(j:end,:))'*(zdemean(1:end-j+1,:))),regs^2,1)/T; %Compute ACF at lag j without substracting mean - as per Jim's notes
    end
    ACF=[flipud(ACF(2:end,:));[ACF(:,1),fliplr(ACF(:,2:3)),ACF(:,4)]]; % Duplicate for -j
    XX=1;
    for d=1:length(dof)
        omegastoreNW(i,d,:,:)=T/(T-regs)*XX^-1*reshape([fliplr(knw(d,1:(length(ACF)-1)/2)),1,knw(d,1:(length(ACF)-1)/2)]*ACF,regs,regs)*XX^-1;
    end
end

% Compute F-statistics
for i=1:draws
    for d=1:length(dof)
        FNW(i,d)=T*betadev(i,:)*squeeze(omegastoreNW(i,d,:,:))^-1*betadev(i,:)'/2;
    end
end
quantile(FNW,.95)
toc
