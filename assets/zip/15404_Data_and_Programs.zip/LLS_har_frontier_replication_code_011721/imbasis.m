%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function computes the set of "split-sample" basis functions.
% Inputs:
% T: sample size
% B_T: number of basis functions
% Outputs:
% imbasis: matrix of basis functions
function f_im2=imbasis(T,B_T)
f_im_split = zeros(T,B_T+1);
tim = floor(T/(B_T+1));
for j = 1:(B_T+1);
    for t = 1:T;
        f_im_split(t,j) = (t>(j-1)*tim)*(t<=j*tim);
    end;
end;
mm = eye(B_T+1)-(1/(B_T+1))*ones(B_T+1,1)*ones(1,B_T+1);
[vv,dd]=eig(mm);
f_im2n = f_im_split*vv(:,2:end);
f_im2 = gramschmidt(f_im2n);
f_im2=f_im2';
end
