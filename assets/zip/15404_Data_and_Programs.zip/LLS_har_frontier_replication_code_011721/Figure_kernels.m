%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file computes implied mean kernels of WOS estimators in the time and
% frequency domain plots them to create figures included in the Supplement
% of the working paper version. 

%% Set up ARMA dgp: (1 - rho*L)y(t) = (1 + theta*L)eps(t);
rho = 0.5;
theta = 0;
ndf = 8; % must be even
tim = 20;
tt = (ndf+1)*tim; %IM divides data set into ndf+1 segments
u = ((1:tt)-(tt/2))'/(tt/2);
freq = 2*pi*([1:tt]-1)'/tt;

%% ---- equal wtd periodogram, real ---
% Compute basis functions
m_spj = zeros(ndf+1,1);
bper = ones(tt,1+ndf/2);
for j = 2:2:(1+ndf)
    bper(:,j) = sqrt(2)*cos(freq(1+j/2)*[1:tt])';
    bper(:,j+1) = sqrt(2)*sin(freq(1+j/2)*[1:tt])';
end
pbper = gramschmidt(bper);
% Implied kernel
[kt_per,kf_per] = impliedkernel(pbper);
plot(1:tt,kt_per);
plot(freq(1:tt/2),kf_per(1:tt/2));

%% -------- Split-Sample basis functions ---------
% Compute basis functions
bim = zeros(tt,ndf+1);
for j = 1:(ndf+1)
    for t = 1:tt
        bim(t,j) = (t>(j-1)*tim)*(t<=j*tim);
    end
end
% orthonormal basis function from evecs of orth proj matrix onto constant
mm = eye(ndf+1)-(1/(ndf+1))*ones(ndf+1,1)*ones(1,ndf+1);
[vv,dd]=eig(mm);
bim1=bim*vv;
pbim = gramschmidt(bim1);
% % Implied kernel
[kt_bim,kf_bim] = impliedkernel(pbim);


%% ---- cosine transform ---
% Compute basis functions
bcos = zeros(tt,ndf+1);
for j = 1:(ndf+1)
    bcos(:,j) = cos(freq(j)*([1:tt]-0.5)/2)';
end
pbcos = gramschmidt(bcos);
% % Implied kernel
[kt_cos,kf_cos] = impliedkernel(pbcos);

%% Plots
figure
set(0,'defaulttextInterpreter','latex') 
plot((1:tt)/tt,[kt_per kt_cos kt_bim ]);
ylabel('$$k_{T}^{OS}(u/S)$$')
xlabel('$$\frac{u}{S}$$')
legend('EWP','cos','SS')
kf = [kf_per kf_cos kf_bim ];
figure
plot((1:36)-1,kf(1:36,:));
ylabel('$$k_{jT}^{OS}(\frac{2\pi j}{T})$$')
xlabel('j')
legend('EWP','cos','SS')
