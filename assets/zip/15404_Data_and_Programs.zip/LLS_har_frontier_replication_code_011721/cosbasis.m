%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function computes the set of type-2 cosine basis functions.
% Inputs:
% T: sample size
% B_T: number of basis functions
% Outputs:
% cosbasis: matrix of basis functions
function [cosbasis]=cosbasis(T,B_T)
trange=1:T;
mrange=1:B_T;
f_t=@(t) 2^.5*cos(mrange'*(t-1/2)*pi/T);
cosbasis=f_t(trange);
end

