%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file computes the object omega^(q), the normalized curvature of the
% spectral density at frequency zero for q=1 and q=2 kernels and location
% and stochastic regressor DGPs, according to equation (12).

alphas=[.5 .7];
for i=1:2
    alpha = alphas(i); % set persistence
    %% Location
    % Compute spectral density
    location_om = 1/(1-alpha)^2; % value of Omega
    varz11_loc = 1/(1-alpha^2); % variance of residual
    sum_loc1 = 0;
    sum_loc2 = 0;
    for j = 1:100000 % approximate infinite sum of omega(1) and omega(2), equation (12)
        gamma_j_loc = alpha^j*varz11_loc;
        sum_loc1 = sum_loc1 + 2*j^1*gamma_j_loc*inv(location_om);
        sum_loc2 = sum_loc2 + 2*j^2*gamma_j_loc*inv(location_om);
    end
    sum_loc1
    sum_loc2
    
    %% Stochastic
    % Compute basic moments of data and spectral density
    sigma2e = [1 0;0 2*alpha^2/(1-alpha^2)+1];
    beta = [alpha 0; 0 alpha^2];
    Omega = inv(eye(2)-beta)*sigma2e*inv(eye(2)-beta); % value of Omega
    varz11 = 1/(1-alpha^2); % variance of residual (times constant)
    varz22 = sigma2e(2,2)/(1-alpha^4); % variance of residual times x
    varz = [varz11 0;0 varz22]; % var-covar of z vector
    sum1=zeros(2,2);
    sum2 = zeros(2,2);
    for j=1:100000 % approximate infinite sum of omega(1) and omega(2), equation (12)
        gamma_j = beta^j*varz;
        gamma_j_neg = gamma_j';
        sum1(:,:) = sum1(:,:)+j^1*gamma_j*inv(Omega)+j^1*gamma_j_neg*inv(Omega);
        sum2(:,:) = sum2(:,:)+j^2*gamma_j*inv(Omega)+j^2*gamma_j_neg*inv(Omega);
    end
    sum1
    sum2
end
