%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This function generates data from a model where both a stochastic 
% regressor and the residuals follow AR(1) processes. It estimates the
% mean, and outputs the residuals times the regressors, the estimated mean, 
% the raw data, and the residuals.
% Inputs:
% T: sample size
% rho: autoregressive parameter (same for X and residuals)
% m: number of regresors
% Outputs:
% zeta: residuals times regressor (a constant)
% b: estimated mean
% y: raw simulated data
% data: stochastic regressors
% r: residuals

function [zeta,b,y,data,r]=stochasAR(T,rho,m)
% Simulate data
u = filter(1, [1 -rho], randn(T,1)); %Generate autocorrelated errors u_t = rho*u_{t-1} + epsilon_t, t=1,2,...,T
x = filter(1, [1 -rho], randn(T,1));
y = 0 + u; %Generate y_t = beta + u_t
% de-mean
ytilde=y-mean(y);
xtilde=x-mean(x);
if m==2 % Generate second regressor, if necessary
    x2=filter(1, [1 -rho], randn(T,1));
    x2tilde=x2-mean(x2);
    xtilde=[xtilde,x2tilde];
end
data=xtilde;
[b,~,r]=regress(ytilde,xtilde);
zeta=xtilde.*repmat(r,1,m); %Generate zeta



end




