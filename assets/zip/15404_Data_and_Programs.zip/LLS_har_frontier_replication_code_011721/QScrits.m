%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file computes fixed-b critical values for the QS LRV estimator in
% the frequency domain. These values are hard-coded into the file
% MCsizepower.
%% m=1

% Initialize
rng(715)
m=1;
T=10000;
Ndraws=1000000;
nu=[8,16,32,64]'; % degrees of freedom 
num=NaN(Ndraws, 1);
Ostar=NaN(Ndraws,length(nu),1);

% Generate weights, Wj
Wqs=[QSfreq(T,ceil(nu(1)/(5/3)));QSfreq(T,ceil(nu(2)/(5/3)));QSfreq(T,ceil(nu(3)/(5/3)));QSfreq(T,ceil(nu(4)/(5/3)))];

for i=1:Ndraws
    num(i)=randn(1,m); % numerator is random normal
chis=1/2*chi2rnd(2,1,length(Wqs));
Ostar(i,:,:)=sum(Wqs.*repmat(chis,length(nu),1),2); % omega is weighted sum of chi-squareds
end

% Compute t-stats
tstats=repmat(num,1,length(nu))./sqrt(Ostar);
quantile(tstats,[.025,.975])
%% m=2

% Initialize
rng(17072015);
m=2;
Ndraws=1000000;
T=10000;
nurange=[8,16,32,64];
factor=(nu-m+1)./nu;
Fstats=NaN(Ndraws,1);

for b=1:length(nurange)
    nu=nurange(b);
J=ceil(nu/(5/3));

% Weights
W=QSfreq(T,J);

% Numerator is 2-d random normal
z1=randn(Ndraws,J);
z2=randn(Ndraws,J);
zeta=randn(2,Ndraws); 

% Compute weighted sums of wisharts
z1a=randn(Ndraws,J);
z2a=randn(Ndraws,J);
wish11=z1.*z1+z1a.*z1a;
wish12=z1.*z2+z1a.*z2a;
wish22=z2.*z2+z2a.*z2a;
kw11=W(1:J)*wish11'/2;
kw12=W(1:J)*wish12'/2;
kw22=W(1:J)*wish22'/2;

% Construct omega from weighted sums
Ostar=[permute(kw11',[3,2,1]),permute(kw12',[3,2,1]);permute(kw12',[3,2,1]),permute(kw22',[3,2,1])]; % omega is weighted sum of chi-squareds

% Construct F-stats
for i=1:Ndraws
    Fstats(i)=zeta(:,i)'*Ostar(:,:,i)^-1*zeta(:,i)/m;
end
quantile(Fstats,.95)
end

