%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file computes the constants used for the analytical frontiers in 
% Theorem 5. The constants are ordered as QS,NW,EWP/EWC,SS.

consts=NaN(3,4);
for i=1:3 % looping over m values
m=i; % dimension of test
q=[2,1,2,1]; % characteristic exponents
% compute different terms in the formula:
kq=[pi^2/10,1,pi^2/6,1];
intk2=[6/5,2/3,1,1];
part2=kq.^(1./q).*intk2;
delta=0:.01:25; % grid
chicrit=chi2inv(.95,m);
a1=1/2*delta.^2.*ncx2pdf(chicrit,m+2,delta.^2)*chicrit*(chi2pdf(chicrit,m)*chicrit)^1;
a2=1/2*delta.^2.*ncx2pdf(chicrit,m+2,delta.^2)*chicrit*(chi2pdf(chicrit,m)*chicrit)^.5;
supa1=max(a1); % take maximum over first part
supa2=max(a2); % take maximum over first part
part1=[supa2,supa1,supa2,supa1];
consts(i,:)=part1.*part2; % constants
end
consts
