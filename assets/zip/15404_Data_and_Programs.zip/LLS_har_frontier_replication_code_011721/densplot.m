%% Lazarus, Lewis, and Stock (2020), "The Size-Power Tradeoff in HAR Inference"
% This file produces a plot of the spectral density of an ARMA(2,1)
% process (included in Supplement of working paper). 
% Inputs:
% a: first AR parameter
% b: second AR parameter
% c: MA parameter
function densplot(a,b,c)
% a: alpha1
% b: alpha2
% c: theta
sd=@(w,alpha1,alpha2,theta) (1+2*theta*cos(w)+theta^2)/(conj(1-alpha1*exp(1i*w)-alpha2*exp(1i*w*2))*(1-alpha1*exp(1i*w)-alpha2*exp(1i*w*2)));

w=0:.01:3.14;
for i=1:length(w)
dens(i)=sd(w(i),a,b,c);
end
figure
plot(w,dens/(2*pi),'b','LineWidth',2)
ax = gca;
ax.XTick = [0,pi/4,pi/2,3*pi/4,pi];
ax.XTickLabel = {'0','\pi/4','\pi/2','3\pi/4','\pi'};
yl1=ylabel('$s_z(\omega)$');
xl1=xlabel('$\omega$');
ylim([0,.3]);
set(gca,'FontSize',16)
set(xl1,'Interpreter','latex');
set(yl1,'Interpreter','latex');
dens(1)
end
