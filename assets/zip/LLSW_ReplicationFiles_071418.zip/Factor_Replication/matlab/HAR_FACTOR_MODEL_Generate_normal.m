% Generate variables from factor model using normal innovations
%

clear all;
small = 1.0e-10;
big = 1.0e+6;
rng(63876498);
% Demeaning Parameters .. model for data when estimates
i_demean = 1;  % 0 Do Nothing
               % 1 Eliminate low-frequency by local Demeaning
               % 2 Eliminate low-frequency trend by full-sample demeaning;
 

% -- File Directories  
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
sdata_dir = 'sdata/';
procs_dir = '../m_utilities/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p1=path(procs_dir,p);
fstr = [matdir 'har_fac_' num2str(i_demean)];load(fstr); 
M = har_fac.var_M;
Q = har_fac.var_Q;
G = har_fac.var_G;
uar_coef_mat = har_fac.uar_coef_mat;
uar_ser_mat = har_fac.uar_ser_mat;
lam_mat = har_fac.lam_mat;

% Generate draws of factors
T = 700;           % Number of observations to generate
T_initial = 500;   % Initial obs
nrep = 10000;
% Generate Factors
F_mat = generate_data_VAR_companion(T,nrep,Q,M,G,T_initial);

ny = size(lam_mat,1);
for i = 1:ny;
    i
    s_mat = NaN(T,nrep);
    lam = lam_mat(i,:);
    arcoef = uar_coef_mat(i,:);
    se_ar = uar_ser_mat(i);
    u_mat = generate_data_univariate_ar(T,nrep,arcoef,se_ar,T_initial);
    for t = 1:T;
        F = squeeze(F_mat(t,:,:));
        s_mat(t,:) = lam*F+u_mat(t,:);
    end;
    fstr = [sdata_dir 'sdata_normal_' num2str(i_demean) '_' num2str(i)];save(fstr,'s_mat','-v7.3');
end;
        

path(p);  % Reset path