% HAR factor model estimation
%

clear all;
small = 1.0e-10;
big = 1.0e+6;

% -- File Directories  
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
matcvdir = 'mat_cv/';
procs_dir = '../m_utilities/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p1=path(procs_dir,p);

% ----------- Sample Period, Calendars and so forth
[dnobs_m,calvec_m,calds_m] = calendar_make([1959 1],[2014 12],12);  % Monthly Calendar
[dnobs_q,calvec_q,calds_q] = calendar_make([1959 1],[2014 4],4);    % Quarterly Calendar

% -- Load Data
load_data=1;
  % Demeaning Parameters
  i_demean = 1;  % 0 Do Nothing
               % 1 Eliminate low-frequency by local Demeaning
               % 2 Eliminate low-frequency trend by full-sample demeaning;
    
  bw_bw = 100;   % Bi-Weight Parameter for local demeaning
datain_all;      % datain_all reads in the full dataset .. all variables, etc. saved in datain.xx


% Factor Parameters
nfac = 6;
est_par.fac_par.nfac.unobserved = nfac;
est_par.fac_par.nfac.observed = 0;
est_par.fac_par.nfac.total = nfac;

% Sampling parameters
est_par.smpl_par.nfirst = [1959 3];       % start date
est_par.smpl_par.nlast  = [2014 4];       % end date
est_par.smpl_par.calvec = datain.calvec;  % calendar
est_par.smpl_par.nper   = 4;              % number of periods a year

% Factor analysis parameters
est_par.fac_par.nt_min                  = 20;     % min number of obs for any series used to est factors
est_par.lambda.nt_min                   = 40;     % min number of obs for any series used to estimate lamba, irfs, etc.
est_par.fac_par.tol                     = 10^-8;  % precision of factor estimation (scaled by by n*t)

% Restrictions on factor loadings to identify factors
est_par.fac_par.lambda_constraints_est  = 1;  % no constraints on lambda
est_par.fac_par.lambda_constraints_full = 1;  % no constraints on lambda

% VAR parameters for factors
est_par.var_par.nlag   = 2;    % number of lags
est_par.var_par.iconst = 1;    % include constant
est_par.var_par.icomp  = 1;    % compute companion form of model .. excluding constant

% yit equation parameters
est_par.n_uarlag = 2;  % number of arlags for uniqueness

% Matrices for storing results
n_series = size(datain.bpdata,2);

fac_est_out = factor_estimation_ls_full(datain.bpdata,datain.bpinclcode,est_par);                  % estimation

% Save some output;
% Calendar, etc;
har_fac.calvec = est_par.smpl_par.calvec;
% Factors
har_fac.nfac = nfac; % number of factors
har_fac.fac = fac_est_out.fac;   % Factor Estimates
% Variable indentifiers
har_fac.bpnamevec = datain.bpnamevec;
har_fac.bplabvec_long = datain.bplabvec_long;
har_fac.bplabvec_short = datain.bplabvec_short;
har_fac.bptcodevec = datain.bptcodevec;
% Factor VAR
har_fac.var_nlag = est_par.var_par.nlag;
har_fac.var_M = fac_est_out.varout.coef.M;
har_fac.var_Q = fac_est_out.varout.coef.Q;
har_fac.var_G = fac_est_out.varout.coef.G;
har_fac.var_seps = fac_est_out.varout.seps;
har_fac.var_resid = fac_est_out.varout.resid;
% Univariate AR
har_fac.uar_coef_mat = fac_est_out.uar_coef_mat;
har_fac.uar_ser_mat = fac_est_out.uar_ser_mat;
har_fac.uar_resid_mat = fac_est_out.uar_resid_mat;
% Factor loadings
har_fac.lam_mat = fac_est_out.lam_mat;

fstr = [matdir 'har_fac_' num2str(i_demean)];save(fstr,'har_fac'); 


path(p);  % Reset path