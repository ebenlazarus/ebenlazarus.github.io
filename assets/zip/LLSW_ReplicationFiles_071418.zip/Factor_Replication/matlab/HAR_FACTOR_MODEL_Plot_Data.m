% HAR factor model estimation
%

clear all;
small = 1.0e-10;
big = 1.0e+6;

% -- File Directories  
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
matcvdir = 'mat_cv/';
procs_dir = '../m_utilities/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p1=path(procs_dir,p);

% ----------- Sample Period, Calendars and so forth
[dnobs_m,calvec_m,calds_m] = calendar_make([1959 1],[2014 12],12);  % Monthly Calendar
[dnobs_q,calvec_q,calds_q] = calendar_make([1959 1],[2014 4],4);    % Quarterly Calendar

% -- Load Data
load_data=1;
  % Demeaning Parameters
  i_demean = 1;  % 0 Do Nothing
               % 1 Eliminate low-frequency by local Demeaning
               % 2 Eliminate low-frequency trend by full-sample demeaning;
    
  bw_bw = 100;   % Bi-Weight Parameter for local demeaning
datain_all;      % datain_all reads in the full dataset .. all variables, etc. saved in datain.xx
bpnamevec = datain.bpnamevec;
bpdata = datain.bpdata;
calvec = datain.calvec;
bptcodevec = datain.bptcodevec;
T = size(calvec,1);

% Plot Some Data series
% Experiment 1
[~,ii] = ismember('GDPC96',bpnamevec); gdp = bpdata(:,ii);
[~,ii] = ismember('GCEC96',bpnamevec); govspending = bpdata(:,ii);
[~,ii] = ismember('AWHMAN',bpnamevec); awhman = bpdata(:,ii);
[~,ii] = ismember('MVOL',bpnamevec); vxo = bpdata(:,ii);
[~,ii] = ismember('USSTHPI',bpnamevec); hprice = bpdata(:,ii);

ax_fs = 20;
figure;
 subplot(3,2,1);
 plot(calvec,gdp,'- b','LineWidth',3);
 title('GDP');
 ax = gca;
 ax.FontSize = ax_fs;
 
 subplot(3,2,2);
 plot(calvec,govspending,'- b','LineWidth',3);
 title('Gov Spending');
 ax = gca;
 ax.FontSize = ax_fs;
 
 subplot(3,2,3);
 plot(calvec,awhman,'- b','LineWidth',3);
 title('AWHours Man');
 ax = gca;
 ax.FontSize = ax_fs;
 
 subplot(3,2,4);
 plot(calvec,vxo,'- b','LineWidth',3);
 title('VIX');
 ax = gca;
 ax.FontSize = ax_fs;
 
 subplot(3,2,5);
 plot(calvec,hprice,'- b','LineWidth',3);
 title('housing prices');
 ax = gca;
 ax.FontSize = ax_fs;
 
 set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
%  fig_str = ['Figure_group3_d']; str_fig = [figdir fig_str];
%  saveas(gcf,[str_fig '.png']);
%  close(gcf);


path(p);  % Reset path