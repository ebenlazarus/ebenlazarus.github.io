% HAR factor model compute ACVs
%

clear all;
small = 1.0e-10;
big = 1.0e+6;

% -- File Directories  
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
matcvdir = 'mat_cv/';
procs_dir = '../m_utilities/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p1=path(procs_dir,p);

% ----------- Sample Period, Calendars and so forth
[dnobs_m,calvec_m,calds_m] = calendar_make([1959 1],[2014 12],12);  % Monthly Calendar
[dnobs_q,calvec_q,calds_q] = calendar_make([1959 1],[2014 4],4);    % Quarterly Calendar

% -- Load Data
load_data=0;
  % Demeaning Parameters
  i_demean = 1;  % 0 Do Nothing
               % 1 Eliminate low-frequency by local Demeaning
               % 2 Eliminate low-frequency trend by full-sample demeaning;
    
  bw_bw = 100;   % Bi-Weight Parameter for local demeaning
% datain_all;      % datain_all reads in the full dataset .. all variables, etc. saved in datain.xx
fstr = [matdir 'har_fac_' num2str(i_demean)];load(fstr,'har_fac'); 

% Calendar, etc;
calvec = har_fac.calvec; % number of factors
fac = har_fac.fac;   % Factor Estimates
% Variable indentifiers
bpnamevec = har_fac.bpnamevec;
bplabvec_long = har_fac.bplabvec_long;
bplabvec_short = har_fac.bplabvec_short;
bptcodevec = har_fac.bptcodevec;
% Factor VAR
var_nlag = har_fac.var_nlag;
M = har_fac.var_M;
Q = har_fac.var_Q;
G = har_fac.var_G;
var_seps = har_fac.var_seps;
var_resid = har_fac.var_resid;
% Univariate AR
uar_coef_mat = har_fac.uar_coef_mat;
uar_ser_mat = har_fac.uar_ser_mat;
uar_resid_mat = har_fac.uar_resid_mat;
% Factor loadings
lam_mat = har_fac.lam_mat;

% Compute AR roots;
nar = size(uar_coef_mat,2);
rt = NaN(size(bpnamevec,2),nar);
for i = 1:size(bpnamevec,2);
    sname = char(bpnamevec(i));
    ar = uar_coef_mat(i,:);
    tmp = zeros(nar,nar);
    tmp(1,:) = ar;
    tmp(2:end,1:end-1) = eye(nar-1);
    aa = sort(abs(eig(tmp)));
    rt(i,:) = aa';
end;

% Eigenvalues of companion matrix for factors
sort(abs(eig(M)))

pct = [0.5;0.75;0.90;0.95;0.975;0.99;1.00];
tmp = pctile(rt(:,end),pct);




    




path(p);  % Reset path