% This program computes the optimal rule parameters shown in Tables 2 and 3
% mww: 20180507
% 
% --- Admin Commands
clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

% ---
alpha = 0.05;   % Size of Test: Results shown for this value of alpha

% Compute Constants
m_max = 10;
[size_const_vec,power_constant_vec] = compute_size_power_constants(m_max,alpha);
q_ewc = 2;
kq_ewc = pi^2/6;
int_ksq_ewc = 1;
q_nw = 1;
kq_nw = 1;
int_ksq_nw = 2/3;

% Table 2 results
ar_mat = (0.1:0.1:.9)';
kappa_mat = [0.5 0.75 0.80 0.85 0.90 0.95 0.99];
b0_ewc_mat = NaN(size(ar_mat,1),size(kappa_mat,2));
b0_nw_mat = NaN(size(ar_mat,1),size(kappa_mat,2));
for i = 1:size(ar_mat,1);
    % Compute Omega values
    ar_coef = ar_mat(i);
    n_acv = 1000;
    acv = arma_acv(ar_coef,0,n_acv);
    acv_0 = acv(1);
    acv_L = acv(2:end);
    spec_0 = acv_0 + 2*sum(acv_L,1);
    tmp = (1:1:n_acv)';
    tmp2 = tmp.^2;
    sec_1 = 2*sum(tmp.*acv_L,1);
    sec_2 = 2*sum(tmp2.*acv_L,1);
    omega_1 = sec_1/spec_0;
    omega_2 = sec_2/spec_0;
    
    % Results for NW
    q = q_nw;
    kq = kq_nw;
    int_ksq = int_ksq_nw;
    omega = omega_1;
    dmaq = (size_const_vec(1)/power_constant_vec(1))^(1/(1+q));
    kapq_vec = (q*kappa_mat./(1-kappa_mat)).^(1/(2*(1+q)));
    omfac = omega^(1/(1+q));
    kfac = (kq/int_ksq)^(1/(1+q));
    b0 = dmaq*kfac*omfac*kapq_vec;
    b0_nw_mat(i,:) = b0;
    
    % Results for ewc
    q = q_ewc;
    kq = kq_ewc;
    int_ksq = int_ksq_ewc;
    omega = omega_2;
    dmaq = (size_const_vec(1)/power_constant_vec(1))^(1/(1+q));
    kapq_vec = (q*kappa_mat./(1-kappa_mat)).^(1/(2*(1+q)));
    omfac = omega^(1/(1+q));
    kfac = (kq/int_ksq)^(1/(1+q));
    b0 = dmaq*kfac*omfac*kapq_vec;
    b0_ewc_mat(i,:) = b0;    
end;

v0_ewc_mat = (1/int_ksq_ewc)*(1./b0_ewc_mat);
v0_nw_mat = (1/int_ksq_nw)*(1./b0_nw_mat);

        
% Save results;

% Table 2 v0 Results for EWC
file_str = [outdir 'Table2a.csv'];
fileID = fopen(file_str,'w');
fprintf(fileID,'nu = aT^(2/3), where a is a function of rho and kappa, given below \n\n');
fprintf(fileID,'Results for 5% tests and 1 restriction \n');
fprintf(fileID,'rho is given in row headings, kappa are given in the column headings \n\n');
fprintf(fileID,',,');
prtmat_comma(kappa_mat,fileID,'%5.2f%','\n\n');
for i = 1:size(ar_mat,1);
  fprintf(fileID,'%5.2f,,',ar_mat(i));
  prtmat_comma(v0_ewc_mat(i,:),fileID,'%6.2f','\n');
end;
    
% Table 2 b0 Results for NW
file_str = [outdir 'Table2b.csv'];
fileID = fopen(file_str,'w');
fprintf(fileID,'S = aT^(1/2), where a is a function of rho and kappa, given below \n\n');
fprintf(fileID,'Results for 5% tests and 1 restriction \n');
fprintf(fileID,'rho is given in row headings, kappa are given in the column headings \n\n');
fprintf(fileID,',,');
prtmat_comma(kappa_mat,fileID,'%5.2f%','\n\n');
for i = 1:size(ar_mat,1);
  fprintf(fileID,'%5.2f,,',ar_mat(i));
  prtmat_comma(b0_nw_mat(i,:),fileID,'%6.2f','\n');
end;

% Table 3 results for m = 1,... 10, AR(1) = 0.7 and kappa = 0.9
mvec = (1:1:10);
b0_nw_mat = NaN(10,1);
b0_ewc_mat = NaN(10,1);
% Compute Omega values
ar_coef = 0.7;
n_acv = 1000;
acv = arma_acv(ar_coef,0,n_acv);
acv_0 = acv(1);
acv_L = acv(2:end);
spec_0 = acv_0 + 2*sum(acv_L,1);
tmp = (1:1:n_acv)';
tmp2 = tmp.^2;
sec_1 = 2*sum(tmp.*acv_L,1);
sec_2 = 2*sum(tmp2.*acv_L,1);
omega_1 = sec_1/spec_0;
omega_2 = sec_2/spec_0;
 
kappa = 0.9;
for m = 1:10;
  % Results for NW
  q = q_nw;
  kq = kq_nw;
  int_ksq = int_ksq_nw;
  omega = omega_1;
  dmaq = (size_const_vec(m)/power_constant_vec(m))^(1/(1+q));
  kapq = (q*kappa/(1-kappa))^(1/(2*(1+q)));
  omfac = omega^(1/(1+q));
  kfac = (kq/int_ksq)^(1/(1+q));
  b0 = dmaq*kfac*omfac*kapq;
  b0_nw_mat(m) = b0;
  
  % Results for ewc
  q = q_ewc;
  kq = kq_ewc;
  int_ksq = int_ksq_ewc;
  omega = omega_2;
  dmaq = (size_const_vec(m)/power_constant_vec(m))^(1/(1+q));
  kapq = (q*kappa./(1-kappa))^(1/(2*(1+q)));
  omfac = omega^(1/(1+q));
  kfac = (kq/int_ksq)^(1/(1+q));
  b0 = dmaq*kfac*omfac*kapq;
  b0_ewc_mat(m) = b0;    
end;   

v0_ewc_mat = (1/int_ksq_ewc)*(1./b0_ewc_mat);
v0_nw_mat = (1/int_ksq_nw)*(1./b0_nw_mat);

% Save results;
mvec = (1:1:10)';


% Table 3 v0 Results for EWC
file_str = [outdir 'Table3_EWC.csv'];
fileID = fopen(file_str,'w');
fprintf(fileID,'v = aT^(2/3), where a is a function of rho and kappa, given below \n\n');
fprintf(fileID,'Results for 5% tests, rhobar = 0.9, kappa = 0.9 \n');
fprintf(fileID,'Results are show for m different m-values');
fprintf(fileID,'\n\n');
fprintf(fileID,'m = ,');
prtmat_comma(mvec',fileID,'%2i','\n');
fprintf(fileID,'a = ,');
prtmat_comma(v0_ewc_mat',fileID,'%6.2f','\n');

% Table 3 b0 Results for NW
file_str = [outdir 'Table3_NW.csv'];
fileID = fopen(file_str,'w');
fprintf(fileID,'S = aT^(1/2), where a is a function of rho and kappa, given below \n\n');
fprintf(fileID,'Results for 5% tests, rhobar = 0.9, kappa = 0.9 \n');
fprintf(fileID,'Results are show for m different m-values');
fprintf(fileID,'\n\n');
fprintf(fileID,'m = ,');
prtmat_comma(mvec',fileID,'%2i','\n');
fprintf(fileID,'a = ,');
prtmat_comma(b0_nw_mat',fileID,'%6.2f','\n');

path(p);  % Reset path
 