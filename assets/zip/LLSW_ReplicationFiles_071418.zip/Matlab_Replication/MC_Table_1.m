% MC Results for Table 1
%
clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
matcvdir = 'mat_cv/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

% Some parameters for calculations
nrep = 100000;
sz = 0.05;      % Size to use for calculations
T = 200;
rho_vec = [0.3 0.5 0.7]';

% Matrices For Saving Rejection Rates
NW_TB_UX = NaN(3,1);
NW_TB_UHATX = NaN(3,1);
NW_UX = NaN(3,1);
NW_UHATX = NaN(3,1);
TRG_UX = NaN(3,1);
TRG_UHATX = NaN(3,1);

% Construct NW and Cosine Weights
nu_Cos = floor(0.41*T^(2/3));
Cos_Mat = cosine_weight(T,nu_Cos);
k_TB = ceil(0.75*T^(1/3));
NW_TB_Mat = NW_Weight_1SD(k_TB);
k_NW = ceil(1.3*T^(1/2));
NW_Mat = NW_Weight_1SD(k_NW);

% Description of Experiment
dataparm.T = T;
dataparm.m = 1;
dataparm.k = 0;
dataparm.arma_x = zeros(2,1);
dataparm.arma_u = zeros(2,1);
dataparm.experiment_group = 1;  % regression with gaussian variables

% Matrices for Storing Rejection Frequencies
NW_ux_rf = NaN(3,1);
NW_uhatx_rf = NaN(3,1);
NW_TB_ux_rf = NaN(3,1);
NW_TB_uhatx_rf = NaN(3,1);
Cos_ux_rf = NaN(3,1);
Cos_uhatx_rf = NaN(3,1);
Cos_lls = NaN(3,1);
NW_lls = NaN(3,1);

for i_rho = 1:size(rho_vec,1);
    rho = rho_vec(i_rho);
    dataparm.arma_x(1) = sqrt(rho);
    dataparm.arma_u(1) = sqrt(rho);
    fprintf('Experiment %4i: ',i_rho);
    tic;
    rng(876997);                            % Same Seed for all experiments
    bhat_mat = NaN(nrep,1);
    Cos_var_ux_mat =  NaN(nrep,1);
    Cos_var_uhatx_mat =  NaN(nrep,1);
    NW_var_ux_mat =  NaN(nrep,1);
    NW_var_uhatx_mat =  NaN(nrep,1);
    NW_TB_var_ux_mat =  NaN(nrep,1);
    NW_TB_var_uhatx_mat =  NaN(nrep,1);
    parfor irep = 1:nrep;
      [bhat_mat(irep,1),ux,uhatx]=gendata(dataparm);
      [Cos_var_ux_mat(irep,1)]=omega_hat_cos(ux,Cos_Mat,nu_Cos);
      [Cos_var_uhatx_mat(irep,1)]=omega_hat_cos(uhatx,Cos_Mat,nu_Cos);
      [NW_var_ux_mat(irep,1)]=omega_hat_nw(ux,NW_Mat);
      [NW_var_uhatx_mat(irep,1)]=omega_hat_nw(uhatx,NW_Mat);
      [NW_TB_var_ux_mat(irep,1)]=omega_hat_nw(ux,NW_TB_Mat);
      [NW_TB_var_uhatx_mat(irep,1)]=omega_hat_nw(uhatx,NW_TB_Mat);
     end;
     NW_ux = T*(bhat_mat.^2)./NW_var_ux_mat;
     NW_uhatx = T*(bhat_mat.^2)./NW_var_uhatx_mat;
     NW_TB_ux = T*(bhat_mat.^2)./NW_TB_var_ux_mat;
     NW_TB_uhatx = T*(bhat_mat.^2)./NW_TB_var_uhatx_mat;
     Cos_ux = T*(bhat_mat.^2)./Cos_var_ux_mat;
     Cos_uhatx = T*(bhat_mat.^2)./Cos_var_uhatx_mat;
     
     % Read in asymptotic critical values
     NW_cv = get_nw_cv(dataparm,k_NW,sz,matcvdir);
     Cos_cv = get_cos_cv(dataparm,sz,nu_Cos);
     NW_TB_cv = chi2inv(1-sz,1);
     
     % Rejection Frequencies
     NW_ux_rf(i_rho,1) = mean(NW_ux > NW_cv);
     NW_uhatx_rf(i_rho,1) = mean(NW_uhatx > NW_cv);
     NW_TB_ux_rf(i_rho,1) = mean(NW_TB_ux > NW_TB_cv);
     NW_TB_uhatx_rf(i_rho,1) = mean(NW_TB_uhatx > NW_TB_cv);
     Cos_ux_rf(i_rho,1) = mean(Cos_ux > Cos_cv);
     Cos_uhatx_rf(i_rho,1) = mean(Cos_uhatx > Cos_cv); 
     
     % Compute Size from LLS approximations
     q_cos = 2;
     kq_cos = pi^2/6;
     int_ksq_cos = 1;
     b_cos = 1/(nu_Cos*int_ksq_cos);
     q_nw = 1;
     kq_nw = 1;
     int_ksq_nw = 2/3;
     b_nw = k_NW/T;
     
     ndf = 1;
     cv_chi2 = chi2inv(1-sz,ndf); % critical value
     tmp = chi2pdf(cv_chi2,ndf);       % G'_m
     Gp = tmp*cv_chi2;                 % G'_m times chi-squared ordinate
     % Compute omega_1 and omega_2
     n_acv = 1000;
     acvu = arma_acv(rho,0,n_acv);
     acv = acvu;
     acv_0 = acv(1);
     acv_L = acv(2:end);
     spec_0 = acv_0 + 2*sum(acv_L,1);
     tmp = (1:1:n_acv)';
     tmp2 = tmp.^2;
     sec_1 = 2*sum(tmp.*acv_L,1);
     sec_2 = 2*sum(tmp2.*acv_L,1);
     omega_1 = sec_1/spec_0;
     omega_2 = sec_2/spec_0;
     
     q = q_cos;
     kq = kq_cos;
     int_ksq = int_ksq_cos;
     omq = omega_2;
     b = b_cos;
     Cos_lls(i_rho) = sz+Gp*omq*kq*(b*T).^(-q);
     
     q = q_nw;
     kq = kq_nw;
     int_ksq = int_ksq_nw;
     omq = omega_1;
     b = b_nw;
     NW_lls(i_rho) = sz+Gp*omq*kq*(b*T).^(-q);
    
    toc;
 end; 
 
 % save results
 outfile_name = [outdir 'Table1.out'];
 fileID = fopen(outfile_name,'w');
 fprintf(fileID,'Table 1 Results \n');
 fprintf(fileID,'Estimator,0.3,0.5,0.7 \n');
 fprintf(fileID,'NW_TB_uhatx,');  prtmat_comma(NW_TB_uhatx_rf',fileID,'%5.3f','\n');
 fprintf(fileID,'NW_uhatx,');  prtmat_comma(NW_uhatx_rf',fileID,'%5.3f','\n');
 fprintf(fileID,'Cos_uhatx,');  prtmat_comma(Cos_uhatx_rf',fileID,'%5.3f','\n');
 fprintf(fileID,'NW_TB_ux,');  prtmat_comma(NW_TB_ux_rf',fileID,'%5.3f','\n');
 fprintf(fileID,'NW_ux,');  prtmat_comma(NW_ux_rf',fileID,'%5.3f','\n');
 fprintf(fileID,'Cos_ux,');  prtmat_comma(Cos_ux_rf',fileID,'%5.3f','\n');
 fprintf(fileID,'NW_lls,');  prtmat_comma(NW_lls',fileID,'%5.3f','\n');
 fprintf(fileID,'Cos_lls,');  prtmat_comma(Cos_lls',fileID,'%5.3f','\n');


 

path(p);  % Reset path
 