% Plot Figure 2

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
matcvdir = 'mat_cv/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

sz = 0.05;      % Size to use for calculations

% Compute Omega values
ar_coef = 0.7;
n_acv = 1000;
acv = arma_acv(ar_coef,0,n_acv);
acv_0 = acv(1);
acv_L = acv(2:end);
spec_0 = acv_0 + 2*sum(acv_L,1);
tmp = (1:1:n_acv)';
tmp2 = tmp.^2;
sec_1 = 2*sum(tmp.*acv_L,1);
sec_2 = 2*sum(tmp2.*acv_L,1);
omega_1 = sec_1/spec_0;
omega_2 = sec_2/spec_0;
[size_constant_vec,power_constant_vec] = compute_size_power_constants(1,sz);
bvec = linspace(0.001,1.00,400);
q_trg = 2;
kq_trg = pi^2/6;
int_ksq_trg = 1;
q_nw = 1;
kq_nw = 1;
int_ksq_nw = 2/3;
T = 200;

% Compute Bounds;
    
% Results for NW
    q = q_nw;
    kq = kq_nw;
    int_ksq = int_ksq_nw;
    omega = omega_1;
    nw_sd_lls = size_constant_vec(1)*omega*kq*(bvec*T).^(-q);
    nw_pd_lls = power_constant_vec(1)*(int_ksq*bvec);
    
% Results for trg
    q = q_trg;
    kq = kq_trg;
    int_ksq = int_ksq_trg;
    omega = omega_2;
    cos_sd_lls = size_constant_vec(1)*omega*kq*(bvec*T).^(-q);
    cos_pd_lls = power_constant_vec(1)*(int_ksq*bvec);   
    
% Read in Results
    fstr = [matdir 'rslt_regression_figure5'];
    load(fstr);
    NW_ux_rslt = rslt.NW_ux_rslt;
    Cos_ux_rslt = rslt.Cos_ux_rslt;
    NW_uhatx_rslt = rslt.NW_uhatx_rslt;
    Cos_uhatx_rslt = rslt.Cos_uhatx_rslt;
    
    nw_ux_sd = NW_ux_rslt.size - sz;
    cos_ux_sd = Cos_ux_rslt.size - sz;
    nw_ux_pd = NW_ux_rslt.pow_dif_sizeadj;
    cos_ux_pd = Cos_ux_rslt.pow_dif_sizeadj;
    
    nw_uhatx_sd = NW_uhatx_rslt.size - sz;
    cos_uhatx_sd = Cos_uhatx_rslt.size - sz;
    nw_uhatx_pd = NW_uhatx_rslt.pow_dif_sizeadj;
    cos_uhatx_pd = Cos_uhatx_rslt.pow_dif_sizeadj;
    
    plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
    hold on;
      plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
      plot(cos_uhatx_sd,cos_uhatx_pd,'bs','LineWidth',3,'MarkerSize',15);
      plot(nw_uhatx_sd,nw_uhatx_pd,'ro','LineWidth',3,'MarkerSize',15);
      plot(cos_ux_sd,cos_ux_pd,'bs','LineWidth',3,'MarkerSize',15,'MarkerFaceColor','b');
      plot(nw_ux_sd,nw_ux_pd,'ro','LineWidth',3,'MarkerSize',15,'MarkerFaceColor','r');
    hold off;
    ax = gca;
    ax.FontSize = 35;
    xlabel('Size Distortion'); 
    ylabel('Power Loss');
    xlim([0 0.15]);
    ylim([0 0.25]);
    lgd=legend('EWC: GLM asymptotic frontier','NW: GLM asymptotic frontier','EWC: finite sample','NW: finite sample','EWC: finite sample with null imposed','NW: finite sample with null imposed');
    lgd.FontSize = 25;
    fig_str = 'Figure_5'; str_fig = [figdir fig_str]; 
    set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
    saveas(gcf,str_fig);
    saveas(gcf,[str_fig '.png']);
    close(gcf);
    
path(p);  % Reset path
 