function [var_inv] = omega_hat_inv_scl(var,scl);

var_inv = NaN(size(var));

i1 = size(var,1);

if i1 == 1
 for i = 1:size(var,3);
    tmp = (scl^2)*squeeze(var(1,1,i,:));
    var_inv(1,1,i,:) = 1./tmp;
 end
end

if i1 > 1
 for i = 1:size(var,3);
    parfor j = 1:size(var,4);
        var_inv(:,:,i,j)=inv(scl'*squeeze(var(:,:,i,j))*scl);
    end;
 end;

end


end

