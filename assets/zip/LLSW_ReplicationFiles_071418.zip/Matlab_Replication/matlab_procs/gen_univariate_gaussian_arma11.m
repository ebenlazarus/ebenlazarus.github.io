function [y] = gen_univariate_gaussian_arma11(rho,theta,T)
% innovation variance 1; stationary
%
y = NaN(T,1);

% Initial condition
if rho == theta
 y(1) = randn(1);
 elag = y(1);
else
 F = zeros(2,2);
 F(1,1) = rho;
 F(1,2) = -theta;
 V = inv(eye(4) - kron(F,F))*ones(4,1);
 V = [V(1:2) V(3:4)];
 CV = chol(V);
 x = CV'*randn(2,1);
 y(1) = x(1);
 elag = x(2);
end

for t = 2:T;
    e = randn(1,1);
    y(t) = rho*y(t-1)+e - theta*elag;
    elag = e;
end;

end

