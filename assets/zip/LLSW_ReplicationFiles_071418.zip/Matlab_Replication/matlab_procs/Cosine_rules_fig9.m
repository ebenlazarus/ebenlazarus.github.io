function [Cos_Mat,qvec,i_qvec] = Cosine_rules_fig9(T)
% Various Cosine weights for different Rules

q = floor(0.41*T^(2/3));
ql = floor(0.5*0.41*T^(2/3));
qu = floor(1.5*0.41*T^(2/3));
qvec = [ql;q;qu];
qmax = max(qvec);
Cos_Mat = cosine_weight(T,qmax);

end
