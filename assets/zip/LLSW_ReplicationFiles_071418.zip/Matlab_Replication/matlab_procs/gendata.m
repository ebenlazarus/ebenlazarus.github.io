function [bhat,ux,uhatx]=gendata_depnull(dataparm)
% Generate data and statistics for har_mc project
% Z is partialled out of regression. X is normalized so that Sxx = eye(m)
% (after Z is partialled out).

if dataparm.experiment_group == 0;
  u = NaN(dataparm.T,dataparm.m);
  for im = 1:dataparm.m;
      u(:,im) = gen_univariate_gaussian_arma11(dataparm.arma_u(1),dataparm.arma_u(2),dataparm.T);
  end;
  bhat = mean(u)';
  ux = u;
  uhatx = u - mean(u);
end;
   
if dataparm.experiment_group > 0;
  [u,x,z] = gendata_1(dataparm);
  if size(z,1) > 1;
   tmp = z\u;
   u = u - z*tmp;
   tmp = z\x;
   x = x - z*tmp;
  end;
  % normalize x so sxx = eye(m);
  sxx = x'*x/dataparm.T;
  cxx = chol(sxx);
  opts.UT = true;
  cxx_i = linsolve(cxx,eye(dataparm.m),opts);
  x = x*cxx_i;
  
  bhat = x'*u/dataparm.T;
  uhat = u - x*bhat;
  ux = u.*x;
  uhatx = uhat.*x;
end;
  
end

