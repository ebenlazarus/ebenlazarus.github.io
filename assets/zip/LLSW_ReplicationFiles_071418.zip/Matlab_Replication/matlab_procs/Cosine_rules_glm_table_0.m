function [Cos_Mat,qvec] = Cosine_rules_glm_table_0(T)
% Various Cosine weights for different Rules

qvec = floor(0.4*T^(2/3));
qmax = max(qvec);
Cos_Mat = cosine_weight(T,qmax);

end
