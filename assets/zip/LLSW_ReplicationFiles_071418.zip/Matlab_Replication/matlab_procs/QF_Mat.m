function [QFvec] = QF_Mat(Xmat,Vmat)
% Xmat is k x n
% Vmat is k x k x n
% Let X denote the i'th column of Xmat
% Lev V denote the kxk matrix from Vmat(:,:,i)
% QFvec(i) = X'*V*X;
%
% Note .. this is organized to be (relatively) fast when n >> k
% Note QF = trace(V * XX);
% Form XXmat;
k = size(Xmat,1);
n = size(Xmat,2);
XXmat = NaN(k,k,n);
for i = 1:k;
    for j = i:k;
        XXmat(i,j,:) = Xmat(i,:).*Xmat(j,:);
        XXmat(j,i,:) = XXmat(i,j,:);
    end;
end;
QFvec = zeros(n,1);
for i = 1:k;
    for j = 1:k;
        v = squeeze(Vmat(i,j,:));
        xx = squeeze(XXmat(j,i,:));
        QFvec = QFvec + v.*xx;
    end;
end;


end

