function [y_mat,T] =  har_glm_fac_experiment(fac_dir,i_demean,i_dgp,sdata_dir,i_series)

% Function that defines experiments
T = 200;

% Read in Data
if i_dgp == 1
    suf = ['independent_' num2str(i_demean) '_'];
elseif i_dgp == 2
    suf = ['normal_' num2str(i_demean) '_'];
elseif i_dgp == 3
    suf = ['empirical_' num2str(i_demean) '_'];
end;

fstr = [sdata_dir 'sdata_' suf num2str(i_series)]; load(fstr); 
y_mat = s_mat(1:T,:);
   
end

