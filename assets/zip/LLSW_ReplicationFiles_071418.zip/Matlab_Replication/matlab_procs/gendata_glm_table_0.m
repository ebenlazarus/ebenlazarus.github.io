function [bhat,uhat,u]=gendata_glm_table_0(dataparm)
% Generate Gaussion location moodel data

  u = NaN(dataparm.T,dataparm.m);
  for i = 1:dataparm.m
   u(:,i) = gen_univariate_gaussian_arma11(dataparm.rho,0,dataparm.T);
  end;
  bhat = mean(u)';
  uhat = u - mean(u);

end

