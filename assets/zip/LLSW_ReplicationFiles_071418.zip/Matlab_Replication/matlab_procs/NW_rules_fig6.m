function [NW_Mat,kvec] = NW_rules_fig6
% Various NW weights for different Rules

kvec = [28 19 10 5]';

kvec_max = max(kvec);
nk = size(kvec,1);
NW_Mat = zeros(kvec_max+1,nk);
for ik = 1:nk;
    k = kvec(ik);
    [nw_w] = NW_Weight_1SD(k);
    NW_Mat(1:k+1,ik) = nw_w;
end;


end

