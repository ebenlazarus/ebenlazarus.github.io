function [ NW_cv ]= get_nw_uc_cv(dataparm,kvec,sz,matdir);
%
T = dataparm.T;
m = dataparm.m;
nk = size(kvec,1);
NW_cv = NaN(nk,1);
% Read in fixed b critical values
fstr = [matdir 'cv_nw_uc_10']; load(fstr);
fstr = [matdir 'cv_nw_uc_05']; load(fstr);
fstr = [matdir 'cv_nw_uc_01']; load(fstr);
if sz == 0.10;
    cv_nw = cv_nw_uc_10;
end;
if sz == 0.05;
    cv_nw = cv_nw_uc_05;
end;
if sz == 0.01;
    cv_nw = cv_nw_uc_01;
end;

for ik = 1:nk;
    b = kvec(ik)/T;
    bvec = cv_nw(:,1);
    [tmp,ii] = min(abs(bvec-b));
    NW_cv(ik,1) = cv_nw(ii,m+1);
end;

end

