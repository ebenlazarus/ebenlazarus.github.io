function [rho] = omega_to_rho(om)
% omega to rho
% ome = 2*r/(1-r)^2
% so (1-2r+r^2)om = 2r
% or om*r^2 + r*(-2*om-2) + om = 0

rho = NaN;
if om == 0;
    rho = 0;
end;
a = om;
b = -2*(om+1);
c = om;
r1 = (-b+sqrt(b^2-4*a*c))/(2*a);
r2 = (-b-sqrt(b^2-4*a*c))/(2*a);
if abs(r1) < 1;
    rho = r1;
end;
if abs(r2) < 1;
    rho = r2;
end;

end

