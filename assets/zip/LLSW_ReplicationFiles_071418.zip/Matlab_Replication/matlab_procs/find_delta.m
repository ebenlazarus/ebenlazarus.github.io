function [del] = find_delta(cv,pct,nu1,nu2)
% Find value of delta so that P[X>cv] = pct, where X ~ NonCentF(nu1,nu2,delta)
close = .00001;  % Close if PCT is in this range
del1 = 0;
del2 = 100;
% Make sure pct(del1) < pct and pct(del2) > pct
ii = 1;
while ii == 1;
    p = ncfcdf(cv,nu1,nu2,del1,'upper');
    if p < pct
        ii = 0;
    else
        del1 = 0.5*del1;
    end
end;

ii = 1;
while ii == 1;
    p = ncfcdf(cv,nu1,nu2,del2,'upper');
    if p > pct
        ii = 0;
    else
        del2 = 2*del2;
    end
end;

ii = 1;
while ii == 1;
    del = (del1+del2)/2;
    pctc = ncfcdf(cv,nu1,nu2,del,'upper');
    if abs(pctc-pct) < close
        ii = 0;
    else
        if pctc > pct
            del2 = del;
        else
            del1 = del;
        end
    end
end;
  
end

