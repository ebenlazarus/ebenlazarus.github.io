function [psi] = cosine_weight(T,q)
% Compute Cosine weights
%

% Cosine weights
fvec = pi*(1:1:q);
tvec = (0.5:1:T)'/T;
psi = (sqrt(2)/sqrt(T))*cos(tvec*fvec);  % normalized so that psi'psi = 1

end

