function [rslt_mat] = rslt_to_mat(rslt,rslt_mat,i,n)

j = size(rslt.size,1);
if i == 1;
    rslt_mat.size = NaN(j,n);
    rslt_mat.pow_dif_sizeadj = NaN(j,n);
    rslt_mat.pow_dif_notsizeadj = NaN(j,n);
    rslt_mat.pow_50_sizeadj = NaN(j,n);
    rslt_mat.pow_50_notsizeadj = NaN(j,n);
end;
rslt_mat.size(:,i) = rslt.size;
rslt_mat.pow_dif_sizeadj(:,i) = rslt.pow_dif_sizeadj;
rslt_mat.pow_dif_notsizeadj(:,i) = rslt.pow_dif_notsizeadj;
rslt_mat.pow_50_sizeadj(:,i) = rslt.pow_dif_sizeadj;
rslt_mat.pow_50_notsizeadj(:,i) = rslt.pow_dif_notsizeadj;

end

