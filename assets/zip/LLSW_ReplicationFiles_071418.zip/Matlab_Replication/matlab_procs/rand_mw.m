function [y] = rand_mw(nrep,imw)
% Generate nrep draws of random variables from Marron-Wand normal mixtures
% 
if imw == 1  % Gaussian
    y = randn(nrep,1);
elseif imw == 2;  % Skewed unimodal
    p = [1/5 1/5 3/5];
    m = [0 1/2 13/12];
    s = [ 1 2/3 5/9];
    k = size(p,2);
    e = randn(nrep,k);
    e = e.*s;
    e = e+m;
    x = mnrnd(1,p,nrep);
    y = sum(x.*e,2);
    % Compute Scales for mean 0 and variance `
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    scl_y = 1/sqrt(m2 - m1^2);
    my = m1;
    y = scl_y*(y - my);
 elseif imw == 3  % Strongly skewed
    p = (1/8)*ones(1,8);
    k = size(p,2);
    m = NaN(1,8);
    s = NaN(1,8);
    for i = 0:7;
       m(i+1) = 3*((2/3)^i-1);
       s(i+1) = (2/3)^i;
    end; 
    e = randn(nrep,k);
    e = e.*s;
    e = e+m;
    x = mnrnd(1,p,nrep);
    y = sum(x.*e,2);
    % Compute Scales for mean 0 and variance `
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    scl_y = 1/sqrt(m2 - m1^2);
    my = m1;
    y = scl_y*(y - my);
 elseif imw == 4;  % kurtotic unimodal
    p = [2/3 1/3];
    m = [0 0];
    s = [1 1/10];
    k = size(p,2);
    e = randn(nrep,k);
    e = e.*s;
    e = e+m;
    x = mnrnd(1,p,nrep);
    y = sum(x.*e,2);
    % Compute Scales for mean 0 and variance `
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    scl_y = 1/sqrt(m2 - m1^2);
    my = m1;
    y = scl_y*(y - my);
 elseif imw == 5;  % outlier
    p = [1/10 9/10];
    m = [0 0];
    s = [1 1/10];
    k = size(p,2);
    e = randn(nrep,k);
    e = e.*s;
    e = e+m;
    x = mnrnd(1,p,nrep);
    y = sum(x.*e,2);
    % Compute Scales for mean 0 and variance `
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    scl_y = 1/sqrt(m2 - m1^2);
    my = m1;
    y = scl_y*(y - my);
elseif imw == 6;  % bimodal
    p = [1/2 1/2];
    m = [-1 1];
    s = [2/3 2/3];
    k = size(p,2);
    e = randn(nrep,k);
    e = e.*s;
    e = e+m;
    x = mnrnd(1,p,nrep);
    y = sum(x.*e,2);
    % Compute Scales for mean 0 and variance `
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    scl_y = 1/sqrt(m2 - m1^2);
    my = m1;
    y = scl_y*(y - my);  
 elseif imw == 7;  % separated bimodal
    p = [1/2 1/2];
    m = [-3/2 3/2];
    s = [1/2 1/2];
    k = size(p,2);
    e = randn(nrep,k);
    e = e.*s;
    e = e+m;
    x = mnrnd(1,p,nrep);
    y = sum(x.*e,2);
    % Compute Scales for mean 0 and variance `
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    scl_y = 1/sqrt(m2 - m1^2);
    my = m1;
    y = scl_y*(y - my);  
 elseif imw == 8;  % skewed bimodal
    p = [3/4 1/4];
    m = [0 3/2];
    s = [1 1/3];
    k = size(p,2);
    e = randn(nrep,k);
    e = e.*s;
    e = e+m;
    x = mnrnd(1,p,nrep);
    y = sum(x.*e,2);
    % Compute Scales for mean 0 and variance `
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    scl_y = 1/sqrt(m2 - m1^2);
    my = m1;
    y = scl_y*(y - my);  
 elseif imw == 9;  % tri-modal
    p = [9/20 9/20 1/10];
    m = [-6/5 6/5 0];
    s = [3/5 3/5 1/4];
    k = size(p,2);
    e = randn(nrep,k);
    e = e.*s;
    e = e+m;
    x = mnrnd(1,p,nrep);
    y = sum(x.*e,2);
    % Compute Scales for mean 0 and variance `
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    scl_y = 1/sqrt(m2 - m1^2);
    my = m1;
    y = scl_y*(y - my);    
end

end
