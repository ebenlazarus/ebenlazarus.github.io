function [Cos_Mat,qvec,i_qvec] = Cosine_rules_fig6(T)
% Various Cosine weights for different Rules

qvec = [7 14 21]';
qmax = max(qvec);
Cos_Mat = cosine_weight(T,qmax);
i_qvec = 1;

end
