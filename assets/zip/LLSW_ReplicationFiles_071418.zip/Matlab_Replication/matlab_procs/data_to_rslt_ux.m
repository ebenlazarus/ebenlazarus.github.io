function [rslt] = data_to_rslt_ux(bhat_mat,var_inv_mat,cv,sz,bvec,power_inf_bvec,dataparm);
  n = size(cv,1); 
  for j = 1:n;
    tmp = data_to_rslt_1_ux(bhat_mat,var_inv_mat(:,:,j,:,:),cv(j,:),sz,bvec,power_inf_bvec,dataparm);
       if j == 1
           rslt.size = tmp.size;
           rslt.pow_dif_sizeadj = tmp.pow_dif_sizeadj;
       else
           rslt.size = [rslt.size ;tmp.size];
           rslt.pow_dif_sizeadj = [rslt.pow_dif_sizeadj ;tmp.pow_dif_sizeadj];
       end  
  end;

end

