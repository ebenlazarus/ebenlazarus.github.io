function [Cos_Mat,qvec,i_qvec] = Cosine_rules_glm(T,m)
% Various Cosine weights for different Rules

qvec = (2:1:5)';
qvec = [qvec;(7:2:51)'];
tmp = [0.4;0.5;0.66;0.75]*T;
tmp = ceil(tmp);
qvec = [qvec;tmp];
tmp = 0.41*T^(2/3);
tmp = floor(tmp);
qvec = [qvec;tmp];
qmax = max(qvec);
Cos_Mat = cosine_weight(T,qmax);

% Only keep values with 2 or more degrees of freedom
i_qvec = qvec >= m+1;
qvec = qvec(i_qvec == 1);

end
