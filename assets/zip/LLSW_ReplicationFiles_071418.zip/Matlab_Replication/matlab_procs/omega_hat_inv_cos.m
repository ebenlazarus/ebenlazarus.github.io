function [omega_hat_inv_mat]=omega_hat_inv_cos(x,w,qvec);
% Compute omega_hat using orthogonal series weights
% x is T x m
% w is T x qmax matrix of weights
% qvec is vector of q values
%
m = size(x,2);
nq = size(qvec,1);
omega_hat_inv_mat = NaN(m,m,nq);

  xdm = x - mean(x);  % just to be sure .. weights should be orthogonal to 1 anyway
  y = w'*xdm;
  
  omega_hat_mat = NaN(m,m,nq);
  for i = 1:nq;
     q = qvec(i);
     omega_hat_mat(:,:,i) = y(1:q,:)'*y(1:q,:)/q;
  end; 
  if m == 1
    omega_hat_inv_mat = 1./omega_hat_mat;
  end
  if m > 1
    for in = 1:nq;
     omega_hat_inv_mat(:,:,in) = inv(squeeze(omega_hat_mat(:,:,in)));
    end;
  end



end