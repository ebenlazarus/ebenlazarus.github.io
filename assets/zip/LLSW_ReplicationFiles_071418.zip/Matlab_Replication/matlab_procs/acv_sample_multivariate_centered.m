function [acv_mat] = acv_sample_multivariate_centered(x,n_acv )
% Construct autovariances from a data matrix x with x is T x n
% n_acv are the number of autocovariances to compute
% note, divisor is T throughout
% Centered .. deviations from sample mean
% ACV at lag k is the SUM of autocovariance at lag k and lag -k

T = size(x,1);
m = size(x,2);

acv_mat = NaN(n_acv+1,m,m);

xdm = x - mean(x);
acv = xdm'*xdm/T;
acv_mat(1,:,:) = acv;

for ilag = 1:n_acv
    acv = xdm(1+ilag:end,:)'*xdm(1:end-ilag,:)/T;
    acv_mat(ilag+1,:,:) = acv + acv';             % Can sum because kernel is symmetric
end

end

