function [Cos_Mat,qvec,i_qvec] = Cosine_rules_tab6(T)
% Various Cosine weights for different Rules

q = floor(0.4*T^(2/3));
qvec = [q];
qmax = max(qvec);
Cos_Mat = cosine_weight(T,qmax);
i_qvec = 1;
end
