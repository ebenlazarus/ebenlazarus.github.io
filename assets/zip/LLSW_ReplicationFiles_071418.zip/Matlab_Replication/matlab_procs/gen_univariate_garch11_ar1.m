function [y] = gen_univariate_garch11_ar1(rho,b,T)
% innovation variance 1; stationary
%
y = NaN(2*T,1);
v = 1/(1-rho^2);
e = rand_garch11(2*T,b,T);
y(1) = sqrt(v)*e(1);
for t = 2:2*T;
    y(t) = rho*y(t-1)+e(t);
end;
y = y(T+1:end);

end

