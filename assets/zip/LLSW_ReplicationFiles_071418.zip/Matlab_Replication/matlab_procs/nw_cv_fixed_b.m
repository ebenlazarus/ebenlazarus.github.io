% Construct NW Critical Values for fixed b for df = m.
% critical values as a function of k/T, where k is the truncation term
% approximation based on large T
% 

% Notation: var_ubar_actual: Exact Finite-Sample Covariance matrix for ubar 

clear all;
small = 1.0e-10;
rng(88741997);

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p1=path(procs_dir,p);

T = 1000;                   % Large T analysis
nrep = 1000;                % Number of replications for CV tests
m_max = 12;

kfrac = (0.0:0.001:0.99);
kfrac = kfrac';
kvec = floor(T*kfrac);
n_kvec = size(kvec,1);
% Generate NW weight matrix
wght = zeros(n_kvec,T);
wght(:,1) = ones(n_kvec,1);
for ii = 1:n_kvec;
 k = kvec(ii);
 if k > 0
    wght(ii,2:k+1) = 2*(k:-1:1)/(k+1);  % 2 for leads and lags .. univariate simplifications
 end
end;

% 
% 
% F_mc = NaN(Nrep,m_max);
% 
% 
% % Generate data for covariance matrix
% u_mat = randn(T,nrep);
% ubar = mean(u_mat);
% u_hat = u_mat-ubar;
% % Compute autocovariances
% acv = acv_sample(u_hat,T-1);
% 
% 
% var = wght*acv/T;
% error('tmp');
% fstat_mat = repmat(ubar.^2,n_kvec,1)./var;
% cv_nw_univariate = NaN(n_kvec,n_size);
% parfor ik = 1:n_kvec;
%     f = fstat_mat(ik,:)';
%     cv = pctile(f,1-size_vec);
%     cv_nw_univariate(ik,:)=cv';
% end;
% cv_nw_univariate = [kfrac cv_nw_univariate];
% cv_chi2_asymp = chi2inv(1-size_vec,1);
% fstr = [matdir 'cv_nw_univariate'];
% save(fstr,'cv_nw_univariate');
 

path(p);  % Reset path
 