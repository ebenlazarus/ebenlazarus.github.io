function [bhat,ux,uhatx]=reg_har_fac(u,x,z);
 
        T = size(x,1);
        m = size(x,2);
        tmp = z\u;
        u = u - z*tmp;
        tmp = z\x;
        x = x - z*tmp;
        % normalize x so sxx = eye(m);
        sxx = x'*x/T;
        cxx = chol(sxx);
        opts.UT = true;
        cxx_i = linsolve(cxx,eye(m),opts);
        x = x*cxx_i;
        bhat = x'*u/T;
        uhat = u - x*bhat;
        ux = u.*x;
        uhatx = uhat.*x;
        
end

