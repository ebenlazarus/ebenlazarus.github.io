function [rslt] = data_to_rslt_1_ux(bhat_mat,var_inv_mat,cv_asymp,sz,bvec,power_inf,dataparm);
%
%
nrep = size(bhat_mat,2);
T = dataparm.T;
m = dataparm.m;
n_b = size(bvec,2);

% Step 1: compute full statistics under null
f_null = NaN(nrep,1);

if m == 1;
    var_inv = squeeze(var_inv_mat(1,1,1,1,:));
    f_null = T*(bhat_mat.^2)'.*var_inv;
end

if m > 1
    f_null = QF_Mat(bhat_mat,squeeze(var_inv_mat(:,:,1,1,:)));
    f_null = T*f_null/m;
end

% Compute size using asymptotic critical values
rslt.size = mean(f_null > cv_asymp);

% Compute finite-sample critical values
pct_vec = 1-sz;
cv_finite = pctile(f_null,pct_vec)';
rslt.size_finite = mean(f_null > cv_finite);

pow_sizeadj = NaN(n_b,1);

if m == 1
  for i = 1:n_b;
    var_inv = squeeze(var_inv_mat(1,1,1,i+1,:));
    bhat = bhat_mat+repmat(bvec(:,i),1,nrep);
    f = T*(bhat.^2)'.*var_inv;
    pow_sizeadj(i,:) = mean(f > cv_finite);
  end;
end

if m > 1
  parfor i = 1:n_b;
    bhat_tmp = bhat_mat+repmat(bvec(:,i),1,nrep);
    f = QF_Mat(bhat_tmp,squeeze(var_inv_mat(:,:,1,i+1,:)));
    f = T*f/m;
    pow_sizeadj(i,:) = mean(f > cv_finite);
  end;  
end

rslt.pow_dif_sizeadj = max(power_inf-pow_sizeadj);

end