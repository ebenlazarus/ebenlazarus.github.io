function [rslt] = data_to_rslt(bhat_mat,var_inv_mat,cv,sz,dvec,power_inf_dvec,dataparm);
  n = size(cv,1); 
  for j = 1:n;
    tmp = data_to_rslt_1(bhat_mat,var_inv_mat(:,:,j,:),cv(j,:),sz,dvec,power_inf_dvec,dataparm);
       if j == 1
           rslt.size = tmp.size;
           rslt.pow_dif_sizeadj = tmp.pow_dif_sizeadj;
       else
           rslt.size = [rslt.size ;tmp.size];
           rslt.pow_dif_sizeadj = [rslt.pow_dif_sizeadj ;tmp.pow_dif_sizeadj];
       end  
  end;

end

