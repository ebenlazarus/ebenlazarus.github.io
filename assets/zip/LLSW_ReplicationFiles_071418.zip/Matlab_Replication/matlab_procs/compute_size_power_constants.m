function [size_const_vec,power_constant_vec] = compute_size_power_constants(m_max,sz)
% Compute Size and power factors 
   size_const_vec = NaN(m_max,1);
   power_constant_vec = NaN(m_max,1);
   delta = (0:.001:100)';
   for m = 1:m_max;
     cv_chi2 = chi2inv(1-sz,m); % critical value
     tmp = chi2pdf(cv_chi2,m);       % G'_m
     size_const_vec(m) = tmp*cv_chi2;  
     Y = ncx2pdf(cv_chi2,m+2,delta);
     X = delta.*Y;
     power_constant_vec(m) = 0.5*max(X)*cv_chi2;              % Contains 1/2 factor   
   end;
   
end

