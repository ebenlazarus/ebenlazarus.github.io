function [bhat,uhat]=gendata_glm(dataparm)
% Generate Gaussion location moodel data

if dataparm.experiment_group == 1;
  u = NaN(dataparm.T,dataparm.m);
  for i = 1:dataparm.m
   u(:,i) = gen_univariate_gaussian_arma11(dataparm.rho,0,dataparm.T);
  end;
  bhat = mean(u)';
  uhat = u - mean(u);
end;

if dataparm.experiment_group == 2;
  u = NaN(dataparm.T,dataparm.m);
  for i = 1:dataparm.m
   u(:,i) = gen_univariate_mw_ar1(dataparm.rho,dataparm.imw,dataparm.T);
  end;
  bhat = mean(u)';
  uhat = u - mean(u);
end;

if dataparm.experiment_group == 3;
  u = NaN(dataparm.T,dataparm.m);
  for i = 1:dataparm.m
   u(:,i) = gen_univariate_garch11_ar1(dataparm.rho,dataparm.b,dataparm.T);
  end;
  bhat = mean(u)';
  uhat = u - mean(u);
end;

if dataparm.experiment_group == 4;
  u = NaN(dataparm.T,dataparm.m);
  for i = 1:dataparm.m
   u(:,i) = gen_univariate_gaussian_arma11(dataparm.rho,0,dataparm.T);
  end;
  bhat = mean(u)';
  uhat = u - mean(u);
end;

end

