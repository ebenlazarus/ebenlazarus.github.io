function [ Cos_cv ]= get_cos_cv(dataparm,sz,qvec);
%
T = dataparm.T;
m = dataparm.m;
nq = size(qvec,1);
Cos_cv = NaN(nq,1);

for iq = 1:nq;
    q = qvec(iq);
    % Compute F(m,q-m+1) CVs
    cv = finv(1-sz,m,q-m+1);
    Cos_cv(iq,1) = cv*q/(q-m+1);   % From F to Hotelling T-squared
end;


end