function [nw_w] = NW_Weight_1SD(k)
% Compute Newey-West Weights (1-sided) 
% 

nw_w = NaN(k+1,1);
nw_w(1) = 1;
if k > 0
    nw_w(2:k+1) = (k:-1:1)'/(k+1);  
end


end

