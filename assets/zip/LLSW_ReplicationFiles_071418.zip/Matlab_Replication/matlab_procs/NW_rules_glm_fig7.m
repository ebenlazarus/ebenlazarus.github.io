function [NW_Mat,kvec] = NW_rules_glm_fig7(T)
% Various NW weights for different Rules

bvec = (.04:.02:0.30)';
tmp = [0.40:0.50];
bvec = [bvec;tmp];
kvec = NaN(size(bvec));
for ib = 1:size(bvec,1);
    kvec(ib) = ceil(bvec(ib)*T);
end;

kvec = [kvec;14];
ktb = ceil(0.75*T^(1/3));
kvec = [kvec;ktb];

kvec_max = max(kvec);
nk = size(kvec,1);
NW_Mat = zeros(kvec_max+1,nk);
for ik = 1:nk;
    k = kvec(ik);
    [nw_w] = NW_Weight_1SD(k);
    NW_Mat(1:k+1,ik) = nw_w;
end;


end

