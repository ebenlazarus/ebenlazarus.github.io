function [NW_Mat,kvec] = NW_rules_fig5(T)
% Various NW weights for different Rules

bvec = (.01:.01:.10)';
tmp = (.12:.02:0.30)';
bvec = [bvec;tmp];
tmp = (0.35:0.05:0.75)';
bvec = [bvec;tmp];
kvec = NaN(size(bvec));
for ib = 1:size(bvec,1);
    kvec(ib) = ceil(bvec(ib)*T);
end;

kvec = [kvec;14];
ktb = ceil(0.75*T^(1/3));
kvec = [kvec;ktb];
kkvb = T-1;
kvec = [kkvb;kvec];

kvec_max = max(kvec);
nk = size(kvec,1);
NW_Mat = zeros(kvec_max+1,nk);
for ik = 1:nk;
    k = kvec(ik);
    [nw_w] = NW_Weight_1SD(k);
    NW_Mat(1:k+1,ik) = nw_w;
end;


end

