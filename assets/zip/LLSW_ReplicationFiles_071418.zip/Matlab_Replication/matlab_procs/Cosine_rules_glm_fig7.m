function [Cos_Mat,qvec,i_qvec] = Cosine_rules_glm(T,m)
% Various Cosine weights for different Rules

qvec = (2:1:5)';
qvec = [qvec;(6:3:40)'];
qvec = [16;qvec];
qmax = max(qvec);
Cos_Mat = cosine_weight(T,qmax);

% Only keep values with 2 or more degrees of freedom
i_qvec = qvec >= m+1;
qvec = qvec(i_qvec == 1);

end
