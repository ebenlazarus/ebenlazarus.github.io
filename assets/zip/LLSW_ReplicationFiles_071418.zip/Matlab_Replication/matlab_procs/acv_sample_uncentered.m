function [acv] = acv_sample_uncentered(x,n_acv )
% Construct autovariances from a data matrix x with x is T x n
% n_acv are the number of autocovariances to compute
% note, divisor is T throughout
% Centered .. deviations from sample mean

T = size(x,1);
n = size(x,2);

acv = NaN(n_acv+1,n);

xdm = x;  % Note: not deviated from at sample mean

parfor ilag = 0:n_acv
    acv(1+ilag,:) = sum(xdm(1+ilag:end,:).*xdm(1:end-ilag,:),1)/T;
end

end

