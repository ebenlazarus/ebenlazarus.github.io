function [u_mat] = rand_garch11(T,b,T_burnin)
% Generate nrep replicates of the time Tx1 time series u
% That follows GARCH_1_1 process with Gaussian errors
% 

b0 = b(1);
b1 = b(2);
b2 = b(3);

unc_variance = b0/(1-b1-b2);   % unconditional variance

u_mat = NaN(T_burnin+T,1);
var_t = unc_variance*ones(1,1);
u_mat(1,1) = sqrt(var_t).*randn(1,1);

for t = 2:T_burnin+T;
    var_t = b0 + b1*var_t + b2*(u_mat(t-1,:).^2);
    u_mat(t,1) = sqrt(var_t).*randn(1,1);
end;
u_mat = u_mat(T_burnin+1:end,:);

end


