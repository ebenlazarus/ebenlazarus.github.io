function [rslt_update] = cos_rslt_update(rslt,iq)

n_q = size(iq,1);

rslt_update.size = NaN(n_q,1);
rslt_update.size(iq==1) = rslt.size;

rslt_update.pow_dif_sizeadj = NaN(n_q,1);
rslt_update.pow_dif_sizeadj(iq==1) = rslt.pow_dif_sizeadj;

rslt_update.pow_dif_notsizeadj = NaN(n_q,1);
rslt_update.pow_dif_notsizeadj(iq==1) = rslt.pow_dif_notsizeadj;

rslt_update.pow_50_sizeadj = NaN(n_q,1);
rslt_update.pow_50_sizeadj(iq==1) = rslt.pow_50_sizeadj;           

rslt_update.pow_50_notsizeadj = NaN(n_q,1);
rslt_update.pow_50_notsizeadj(iq==1) = rslt.pow_50_notsizeadj;
          
end

