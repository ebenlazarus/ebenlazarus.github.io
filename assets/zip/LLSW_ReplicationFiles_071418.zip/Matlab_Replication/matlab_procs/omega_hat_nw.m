function [omega_hat_mat] = omega_hat_nw(x,w)
% Compute omega_hat using weighted sample autocovariances
% x is T x m
% w is (k+1)xn where k are the number of autocovariances and n is the
% number of different sets of weights
k = size(w,1)-1;
m = size(x,2);
n = size(w,2);

[acv_mat] = acv_sample_multivariate_centered(x,k);

omega_hat_mat = NaN(m,m,n);
for ii = 1:m;
    for jj = ii:m;
          omega_hat_mat(ii,jj,:) = w'*acv_mat(:,ii,jj);
          omega_hat_mat(jj,ii,:) = omega_hat_mat(ii,jj,:);
     end;
end;

end