function [bhat,uhatx,ux_mat]=reg_har_fac_depnull(u,x,z,bvec);
 
        T = size(x,1);
        m = size(x,2);
        tmp = z\u;
        u = u - z*tmp;
        tmp = z\x;
        x = x - z*tmp;
        % normalize x so sxx = eye(m);
        sxx = x'*x/T;
        cxx = chol(sxx);
        opts.UT = true;
        cxx_i = linsolve(cxx,eye(m),opts);
        x = x*cxx_i;
        
        
        bhat = x'*u/T;
        uhat = u - x*bhat;
        ux = u.*x;
        uhatx = uhat.*x;
        
        bhat = x'*u/T;
        uhat = u - x*bhat;
        uhatx = uhat.*x;
        n_b = size(bvec,2);
        ux_mat = NaN(size(uhatx,1),size(uhatx,2),n_b+1);
        ux_mat(:,:,1) = u.*x;
        for ib = 1:n_b;
            ux_mat(:,:,1+ib) = (u+x*bvec(:,ib)).*x;
        end;      
end

