function [u,x,z] = gendata_1(dataparm)
 
 if dataparm.experiment_group == 1;
  % Gaussian ARMA(1,1) Models
  u = gen_univariate_gaussian_arma11(dataparm.arma_u(1),dataparm.arma_u(2),dataparm.T);
  x = gen_univariate_gaussian_arma11(dataparm.arma_x(1),dataparm.arma_x(2),dataparm.T);
  for i = 2:dataparm.m;
     x1 = gen_univariate_gaussian_arma11(dataparm.arma_x(1),dataparm.arma_x(2),dataparm.T);
     x = [x x1];
  end;
  z = ones(dataparm.T,1);
  for i = 1:dataparm.k;
     z1 = gen_univariate_gaussian_arma11(dataparm.arma_x(1),dataparm.arma_x(2),dataparm.T);
     z = [z z1];
  end;
 
 end;
 
end

