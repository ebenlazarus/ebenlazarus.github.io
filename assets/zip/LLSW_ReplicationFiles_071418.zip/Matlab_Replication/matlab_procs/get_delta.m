function [dvec,power_inf_dvec]=get_delta(m,sz,matdir);

fstr = [matdir 'delta_mat_' num2str(m) '_' num2str(100*sz)];
load(fstr);
dvec = delta_mat(:,1);
power_inf_dvec = delta_mat(:,2);

end

