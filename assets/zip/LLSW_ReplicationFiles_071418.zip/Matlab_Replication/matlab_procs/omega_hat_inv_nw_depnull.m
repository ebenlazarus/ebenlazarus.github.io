function [omega_hat_inv_mat] = omega_hat_inv_nw_depnull(xmat,w)
% Compute omega_hat using weighted sample autocovariances
% x is T x m
% w is (k+1)xn where k are the number of autocovariances and n is the
% number of different sets of weights

k = size(w,1)-1;
m = size(xmat,2);
n = size(w,2);
nb = size(xmat,3);

omega_hat_inv_mat =  NaN(m,m,n,nb);

for ib = 1:nb;
  x = squeeze(xmat(:,:,ib));
  [acv_mat] = acv_sample_multivariate_centered(x,k);
  omega_hat_mat = NaN(m,m,n);
  for ii = 1:m;
    for jj = ii:m;
          omega_hat_mat(ii,jj,:) = w'*acv_mat(:,ii,jj);
          omega_hat_mat(jj,ii,:) = omega_hat_mat(ii,jj,:);
     end;
  end;

  if m == 1
    omega_hat_inv_mat(:,:,:,ib) = 1./omega_hat_mat;
  end

  if m > 1
    for in = 1:n;
       omega_hat_inv_mat(:,:,in,ib) = inv(squeeze(omega_hat_mat(:,:,in)));
    end;
  end

end;

end