function [NW_Mat,kvec] = NW_rules_fig4(T)
% Various NW weights for different Rules

k = ceil(1.3*T^(1/2));
kvec = [k];

kvec_max = max(kvec);
nk = size(kvec,1);
NW_Mat = zeros(kvec_max+1,nk);
for ik = 1:nk;
    k = kvec(ik);
    [nw_w] = NW_Weight_1SD(k);
    NW_Mat(1:k+1,ik) = nw_w;
end;


end

