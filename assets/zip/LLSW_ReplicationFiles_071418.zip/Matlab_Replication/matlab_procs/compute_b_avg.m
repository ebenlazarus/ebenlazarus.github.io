function [b_avg] = compute_b_avg(ym,xm,zm)

nreg = size(xm,1) + size(zm,1);
nrep = size(ym,2);
bsum = zeros(nreg,1);

for irep = 1:nrep;
    y = ym(:,irep);
    x = squeeze(xm(:,:,irep))';
    z = squeeze(zm(:,:,irep))';
    w = [x z]; 
    b = w\y;
    bsum = bsum+b;
end;
b_avg = bsum/nrep;

end

