function [rslt_mat] = rslt_to_mat_randn(rslt,rslt_mat,i_s,n_s)

j = size(rslt.size,1);
if (i_s == 1);
    rslt_mat.size = NaN(j,n_s);
    rslt_mat.pow_dif_sizeadj = NaN(j,n_s);
end;
rslt_mat.size(:,i_s) = rslt.size;
rslt_mat.pow_dif_sizeadj(:,i_s) = rslt.pow_dif_sizeadj;

end

