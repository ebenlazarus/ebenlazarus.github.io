function [power_inf] = compute_power_inf_bvec(bhat_mat,bvec,sz);
%
%
nrep = size(bhat_mat,2);
m = size(bhat_mat,1);
n_b = size(bvec,2);

% Compute Variance matrix for bhat
v = bhat_mat*bhat_mat'/nrep;
vi = inv(v);

% Compute f-statistics under null
f_null = NaN(nrep,1);

if m == 1;
    f_null = vi*(bhat_mat.^2)';
end

if m > 1
%     parfor irep = 1:nrep;
%        var_inv = squeeze(var_inv_mat(:,:,1,irep));
%        bhat = bhat_mat(:,irep);   
%        f_null(irep) = T*bhat'*var_inv*bhat/m;
%     end;
    f_null = QF_Mat_1(bhat_mat,vi);
    f_null = f_null/m;
end

% Compute critical value under null
pct_vec = 1-sz;
cv_finite = pctile(f_null,pct_vec)';

% Compute power
pow_sizeadj = NaN(n_b,1);
if m == 1
  for i = 1:n_b;
    bhat_tmp = bhat_mat + repmat(bvec(:,i),1,nrep);
    f = vi*(bhat_tmp.^2)';
    pow_sizeadj(i,:) = mean(f > cv_finite);
  end;
end

if m > 1
  parfor i = 1:n_b;
%     f = NaN(nrep,1);
%     for irep = 1:nrep;
%       var_inv = squeeze(var_inv_mat(:,:,1,irep));
%       bhat = bhat_mat(:,irep);
%       bhat(1) = bhat(1)+dvec(i);
%       f(irep) = T*bhat'*var_inv*bhat/m;
%     end;
    bhat_tmp = bhat_mat + repmat(bvec(:,i),1,nrep);
    f = QF_Mat_1(bhat_tmp,vi);
    f = f/m;
    pow_sizeadj(i,:) = mean(f > cv_finite);
  end;  
end

power_inf = pow_sizeadj;

end