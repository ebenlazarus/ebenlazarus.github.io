function [y_mat,x_mat,z_mat,T,ind_series] =  har_fac_experiment_randn(iexp,fac_dir,i_demean,i_dgp,i_series,sdata_dir)

% Function that defines experiments
T = 200;

fstr = [fac_dir 'har_fac_' num2str(i_demean)];load(fstr); 
bpnamevec = har_fac.bpnamevec; 
bptcodevec = har_fac.bptcodevec;

tr_all = (1:1:207)';

% Read in Data
if i_dgp == 1
    suf = ['independent_' num2str(i_demean) '_'];
elseif i_dgp == 2
    suf = ['normal_' num2str(i_demean) '_'];
elseif i_dgp == 3
    suf = ['empirical_' num2str(i_demean) '_'];
end;

nlast = 0;

num_dist_lag = 3;
if (iexp >= nlast+1) & (iexp <= nlast+num_dist_lag); 
      if i_series <= 207
         iw = i_series;
      else 
         iw = i_series-207;
      end
      ii = tr_all == iw;
      tmp = tr_all(ii == 0);
      jj = rand_int(1,206);
      iv = tmp(jj);
      fstr = [sdata_dir 'sdata_' suf num2str(iw)]; load(fstr); s_w = s_mat;
      fstr = [sdata_dir 'sdata_' suf num2str(iv)]; load(fstr); s_v = s_mat; 
      nrep = size(s_mat,2);
      if i_series <= 207
         s_y = s_w;
         s_x = s_v;
         ind_series = [iw iv]';
      else 
         s_y = s_v;
         s_x = s_w;
         ind_series = [iv iw]';
      end
      
      if iexp == nlast+1
         nlag = 1;
      end 
      if iexp == nlast+2
        nlag = 5;
      end
      if iexp == nlast+3
        nlag = 10;
      end
      
      y_mat = s_y(nlag:T+nlag-1,:);
      k = 1;
      z_mat = NaN(k,T,nrep);
      z_mat(1,:,:) = ones(T,nrep);
      m = nlag;  % number of regressors)
      x_mat = NaN(m,T,nrep);
      for i = 1:nlag;
        x_mat(i,:,:) = s_x(nlag+1-i:T+nlag-i,:);
      end;
end;
nlast = nlast + num_dist_lag;

num_fcst = 12;
if (iexp >= nlast+1) & (iexp <= nlast+num_fcst);
    if i_series <= 207
         iw = i_series;
    else 
         iw = i_series-207;
    end
    
    ii = tr_all == iw;
    tmp = tr_all(ii == 0);
    jj = rand_int(1,206);
    iv = tmp(jj);
    fstr = [sdata_dir 'sdata_' suf num2str(iw)]; load(fstr); s_w = s_mat;
    fstr = [sdata_dir 'sdata_' suf num2str(iv)]; load(fstr); s_v = s_mat; 
    nrep = size(s_mat,2);
    
    if i_series <= 207
         s_y = s_w;
         s_x = s_v;
         ind_series = [iw iv]';
         tc = bptcodevec(iw);
    else 
         s_y = s_v;
         s_x = s_w;
         ind_series = [iv iw]';
         tc = bptcodevec(iv);
    end
    
    if iexp == nlast+1;
        nph = 1;
        nlagx = 1;  % lag 1 is "t"
        nlagy = 0;
    end; 
    if iexp == nlast+2;
        nph = 4;
        nlagx = 1;  % lag 1 is "t"
        nlagy = 0;
    end;
    if iexp == nlast+3;
        nph = 8;
        nlagx = 1;
        nlagy = 0;
    end;
    if iexp == nlast+4;
        nph = 12;
        nlagx = 1;
        nlagy = 0;
    end;
    
    if iexp == nlast+5;
        nph = 1;
        nlagx = 3;
        nlagy = 0;
    end;
    
    if iexp == nlast+6;
        nph = 4;
        nlagx = 3;
        nlagy = 0;
    end;
    if iexp == nlast+7;
        nph = 8;
        nlagx = 3;
        nlagy = 0;
    end;
    if iexp == nlast+8;
        nph = 12;
        nlagx = 3;
        nlagy = 0;
    end;
    if iexp == nlast+9;
        nph = 1;
        nlagx = 3;
        nlagy = 3;
    end;
    if iexp == nlast+10;
        nph = 4;
        nlagx = 3;
        nlagy = 3;
    end;
    if iexp == nlast+11;
        nph = 8;
        nlagx = 3;
        nlagy = 3;
    end;
    if iexp == nlast+12;
        nph = 12;
        nlagx = 3;
        nlagy = 3;
    end;
    nn = max([nlagx;nlagy]);
    x_mat = NaN(nlagx,T,nrep);
    for ii = 1:nlagx
     x_mat(ii,:,:) = s_x(1+nn-ii:T+nn-ii,:);
    end;
    k = 1+nlagy;
    z_mat = NaN(k,T,nrep);
    z_mat(1,:,:) = ones(T,nrep);
    for ii = 1:nlagy;
        z_mat(1+ii,:,:) = s_y(1+nn-ii:T+nn-ii,:); 
    end;
    
    cum_s_y = cumsum(s_y);
    cum_cum_s_y = cumsum(cum_s_y);
    if (tc==1) | (tc==4)
        y_mat = s_y(nph+nn:T+nph+nn-1,:);
    end
    if (tc==2) | (tc==5)
        y_mat = cum_s_y(nph+nn:T+nph+nn-1,:)-cum_s_y(nn:T+nn-1,:);
    end
    if (tc==3) | (tc==6)
        y_mat = cum_cum_s_y(nph+nn:T+nph+nn-1,:)-cum_cum_s_y(nn:T+nn-1,:)-nph*cum_s_y(nn:T+nn-1,:);
    end
    
end;
nlast = nlast + 12;

num_lp = 4;
if (iexp >= nlast+1) & (iexp <= nlast+num_lp);
   if i_series <= 207
          iw = i_series;
    else 
          iw = i_series-207;
   end  
   % Choose 3 other series
   tmp = tr_all;
   ii = tmp == iw;
   tmp = tmp(ii == 0);
   jj = rand_int(1,206);
   iv1 = tmp(jj);
   
   ii = tmp == iv1;
   tmp = tmp(ii == 0);
   jj = rand_int(1,205);
   iv2 = tmp(jj);
   
   ii = tmp == iv2;
   tmp = tmp(ii == 0);
   jj = rand_int(1,204);
   iv3 = tmp(jj);
      
   fstr = [sdata_dir 'sdata_' suf num2str(iw)];  load(fstr); s_w = s_mat;
   fstr = [sdata_dir 'sdata_' suf num2str(iv1)]; load(fstr); s_v1 = s_mat; 
   fstr = [sdata_dir 'sdata_' suf num2str(iv2)]; load(fstr); s_v2 = s_mat;
   fstr = [sdata_dir 'sdata_' suf num2str(iv3)]; load(fstr); s_v3 = s_mat;
   nrep = size(s_mat,2);
   
   nlag = 2;    % Current and nlag lags are included
   npad = 10;   % exta time periods for padding for use with initial conditions
   m = 1;
   k = 1+3+2*nlag;
    if iexp == nlast+1
      nph = 1;
   end
   if iexp == nlast+2
      nph = 4;
   end
   if iexp == nlast+3
      nph = 8;
   end
   if iexp == nlast+4
      nph = 12;
   end
   
   if i_series <= 207
       ind_series = [iw iv1 iv2 iv3]';
       s1 = s_w;
       s2 = s_v1;
       tc = bptcodevec(iw);
   else
       ind_series = [iv1 iw iv2 iv3]';
       s1 = s_v1;
       s2 = s_w;
       tc = bptcodevec(iv1);
   end
   
   x_mat = NaN(1,T,nrep);
   x_mat(1,:,:) = s2(npad+nlag+1:npad+T+nlag,:); 
   z_mat = NaN(1+3+nlag*4,T,nrep);
   z_mat(1,:,:) = ones(T,nrep);
   z_mat(2,:,:) = s1(npad+nlag+1:npad+T+nlag,:); 
   z_mat(3,:,:) = s_v2(npad+nlag+1:npad+T+nlag,:); 
   z_mat(4,:,:) = s_v3(npad+nlag+1:npad+T+nlag,:); 
   for i = 1:nlag;
       j = i*4;
       z_mat(j+1,:,:) = s2(npad+nlag+1-i:npad+T+nlag-i,:);
       z_mat(j+2,:,:) = s1(npad+nlag+1-i:npad+T+nlag-i,:);
       z_mat(j+3,:,:) = s_v2(npad+nlag+1-i:npad+T+nlag-i,:);
       z_mat(j+4,:,:) = s_v3(npad+nlag+1-i:npad+T+nlag-i,:);
   end;
   
   cum_s_y = cumsum(s1);
   cum_cum_s_y = cumsum(cum_s_y);
   
   if (tc == 1) | (tc == 4)
       y_mat = s1(npad+nph+1+nlag:npad+T+nph+nlag,:);
   elseif (tc == 2) | (tc == 5)
       y_mat = cum_s_y(npad+nph+1+nlag:npad+T+nph+nlag,:) - cum_s_y(npad+1+nlag:npad+T+nlag,:);
   elseif (tc ==3) | (tc == 6)
       y_mat = cum_cum_s_y(npad+nph+1+nlag:npad+T+nph+nlag,:) - cum_cum_s_y(npad+1+nlag:npad+T+nlag,:)-nph*cum_s_y(npad+1+nlag:npad+T+nlag,:);
   end 
   
end;
nlast = nlast+num_lp;


% Function that defines experiments
num_fcst2 = 4;
if (iexp >= nlast+1) & (iexp <= nlast+num_lp);
   if i_series <= 207
          iw = i_series;
    else 
          iw = i_series-207;
   end  
   % Choose 3 other series
   tmp = tr_all;
   ii = tmp == iw;
   tmp = tmp(ii == 0);
   jj = rand_int(1,206);
   iv1 = tmp(jj);
   
   ii = tmp == iv1;
   tmp = tmp(ii == 0);
   jj = rand_int(1,205);
   iv2 = tmp(jj);
   
   ii = tmp == iv2;
   tmp = tmp(ii == 0);
   jj = rand_int(1,204);
   iv3 = tmp(jj);
      
   fstr = [sdata_dir 'sdata_' suf num2str(iw)];  load(fstr); s_w = s_mat;
   fstr = [sdata_dir 'sdata_' suf num2str(iv1)]; load(fstr); s_v1 = s_mat; 
   fstr = [sdata_dir 'sdata_' suf num2str(iv2)]; load(fstr); s_v2 = s_mat;
   fstr = [sdata_dir 'sdata_' suf num2str(iv3)]; load(fstr); s_v3 = s_mat;
   nrep = size(s_w,2);
   
   m = 3;
   k = 1;
   if iexp == nlast+1
      nph = 1;
   end
   if iexp == nlast+2
      nph = 4;
   end
   if iexp == nlast+3
      nph = 8;
   end
   if iexp == nlast+4
      nph = 12;
   end
   
   if i_series <= 207
       ind_series = [iw iv1 iv2 iv3]';
       s1 = s_w;
       s2 = s_v1;
       tc = bptcodevec(iw);
   else
       ind_series = [iv1 iw iv2 iv3]';
       s1 = s_v1;
       s2 = s_w;
       tc = bptcodevec(iv1);
   end
   
   x_mat = NaN(3,T,nrep);
   x_mat(1,:,:) = s2(1:T,:); 
   x_mat(2,:,:) = s_v2(1:T,:); 
   x_mat(3,:,:) = s_v3(1:T,:); 
   z_mat = NaN(k,T,nrep);
   z_mat(1,:,:) = ones(T,nrep);
   
   cum_s_y = cumsum(s1);
   cum_cum_s_y = cumsum(cum_s_y);
   
   if (tc == 1) | (tc == 4)
       y_mat = s1(nph+1:T+nph,:);
   elseif (tc == 2) | (tc == 5)
       y_mat = cum_s_y(nph+1:T+nph,:) - cum_s_y(1:T,:);
   elseif (tc ==3) | (tc == 6)
       y_mat = cum_cum_s_y(nph+1:T+nph,:) - cum_cum_s_y(1:T,:)-nph*cum_s_y(1:T,:);
   end 
   
end;
nlast = nlast+num_fcst2;
   
end

