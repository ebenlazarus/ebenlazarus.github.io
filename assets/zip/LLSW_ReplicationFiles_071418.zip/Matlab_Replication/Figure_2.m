% Figure 2
% 20180507
% 

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);
% Indicators for computing estimators

Tvec = (100:25:500)';
n_T = size(Tvec,1);
n_acv = 1000;
ar_vec = [0.3;0.5;0.7];
n_ar = size(ar_vec,1);
kappa_vec = [0.75;0.80;0.90];
n_kappa = size(kappa_vec,1);

% Compute Constants
m_max = 1;
alpha = 0.05;
[size_const_vec,power_constant_vec] = compute_size_power_constants(m_max,alpha);
q_ewc = 2;
kq_ewc = pi^2/6;
int_ksq_ewc = 1;
q_nw = 1;
kq_nw = 1;
int_ksq_nw = 2/3;



sd_ewc = NaN(n_T,n_kappa,n_ar);
sd_nw = NaN(n_T,n_kappa,n_ar);
pd_ewc = NaN(n_T,n_kappa,n_ar);
pd_nw = NaN(n_T,n_kappa,n_ar);

for iar = 1:n_ar;
  for ik = 1:n_kappa;
      kappa = kappa_vec(ik);
      ar_coef = ar_vec(iar);
      acv = arma_acv(ar_coef,0,n_acv);
      acv_0 = acv(1);
      acv_L = acv(2:end);
      spec_0 = acv_0 + 2*sum(acv_L,1);
      tmp = (1:1:n_acv)';
      tmp2 = tmp.^2;
      sec_1 = 2*sum(tmp.*acv_L,1);
      sec_2 = 2*sum(tmp2.*acv_L,1);
      omega_1 = sec_1/spec_0;
      omega_2 = sec_2/spec_0;

      q = q_ewc;
      kq = kq_ewc;
      int_ksq = int_ksq_ewc;
      omega = omega_2;
      dmaq = (size_const_vec/power_constant_vec)^(1/(1+q));
      kapq = (q*kappa/(1-kappa))^(1/(2*(1+q)));
      omfac = omega^(1/(1+q));
      kfac = (kq/int_ksq)^(1/(1+q));
      b0 = dmaq*kfac*omfac*kapq;
      b = b0*(Tvec.^(-q/(q+1)));
      sd = size_const_vec*omega*kq*(b.*Tvec).^(-q);
      pd = power_constant_vec*int_ksq*b;
      sd_ewc(:,iar,ik) = sd;
      pd_ewc(:,iar,ik) = pd;
      
      q = q_nw;
      kq = kq_nw;
      int_ksq = int_ksq_nw;
      omega = omega_1;
      dmaq = (size_const_vec/power_constant_vec)^(1/(1+q));
      kapq = (q*kappa/(1-kappa))^(1/(2*(1+q)));
      omfac = omega^(1/(1+q));
      kfac = (kq/int_ksq)^(1/(1+q));
      b0 = dmaq*kfac*omfac*kapq;
      b = b0*(Tvec.^(-q/(q+1)));
      sd = size_const_vec*omega*kq*(b.*Tvec).^(-q);
      pd = power_constant_vec*int_ksq*b;
      sd_nw(:,iar,ik) = sd;
      pd_nw(:,iar,ik) = pd;
  end;
end;

figure;
axFS = 25;
subplot(2,2,1);
iar = 3;
plot(Tvec,squeeze(sd_ewc(:,iar,1)),'- b','LineWidth',4);
hold on;
  plot(Tvec,squeeze(sd_ewc(:,iar,3)),'- r','LineWidth',2);
  plot(Tvec,squeeze(pd_ewc(:,iar,1)),'-- b','LineWidth',4);
  plot(Tvec,squeeze(pd_ewc(:,iar,3)),'-- r','LineWidth',2);
hold off;
legend('Size Distortion \kappa=0.75','Size Distortion \kappa=0.90','Power Loss \kappa=0.75','Power Loss \kappa=0.90','Location','NorthEast');
ax = gca;
ax.FontSize = axFS;
xlabel('T');
h = title('(a) EWC: $$\overline{\rho}$$ = 0.7');
set(h,'Interpreter','latex','fontsize',axFS);


subplot(2,2,2);
iar = 3;
ik = 2;
plot(Tvec,squeeze(sd_ewc(:,iar,3)),'- b','LineWidth',4);
hold on;
  plot(Tvec,squeeze(sd_nw(:,iar,3)),'- r','LineWidth',2); 
  plot(Tvec,squeeze(pd_ewc(:,iar,3)),'-- b','LineWidth',4);
  plot(Tvec,squeeze(pd_nw(:,iar,3)),'-- r','LineWidth',2);
hold off;
legend('Size Distortion EWC','Size Distortion NW','Power Loss EWC','Power Loss NW','Location','NorthEast');
ax = gca;
ax.FontSize = axFS;
xlabel('T');
h = title('(b) EWC and NW: $$\overline{\rho}$$ = 0.7 and $$\kappa$$ = 0.90');
set(h,'Interpreter','latex','fontsize',axFS);

subplot(2,2,3);
ik = 3;
plot(Tvec,squeeze(sd_ewc(:,1,ik)),'- b','LineWidth',4);
hold on;
  plot(Tvec,squeeze(sd_ewc(:,2,ik)),'-- b','LineWidth',4); 
  plot(Tvec,squeeze(sd_ewc(:,3,ik)),': b','LineWidth',4);
hold off;
h = legend('$$\overline{\rho}$$ = 0.3','$$\overline{\rho}$$ = 0.5','$$\overline{\rho}$$ = 0.7','Location','NorthEast');
set(h,'Interpreter','latex','fontsize',axFS);
ax = gca;
ax.FontSize = axFS;
xlabel('T');
h = title('(c) Size Distortions EWC: $$\kappa$$ = 0.90');
set(h,'Interpreter','latex','fontsize',axFS);

subplot(2,2,4);
ik = 3;
plot(Tvec,squeeze(sd_nw(:,1,ik)),'- b','LineWidth',4);
hold on;
  plot(Tvec,squeeze(sd_nw(:,2,ik)),'-- b','LineWidth',4); 
  plot(Tvec,squeeze(sd_nw(:,3,ik)),': b','LineWidth',4);
hold off;
h = legend('$$\overline{\rho}$$ = 0.3','$$\overline{\rho}$$ = 0.5','$$\overline{\rho}$$ = 0.7','Location','NorthEast');
set(h,'Interpreter','latex','fontsize',axFS);
ax = gca;
ax.FontSize = axFS;
xlabel('T');
h = title('(d) Size Distortions NW: $$\kappa$$ = 0.90');
set(h,'Interpreter','latex','fontsize',axFS);

set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_2'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);



path(p);  % Reset path
 