function [y_mat,x_mat,z_mat,T,ind_series] =  har_fac_experiment_randn_fig8(iexp,fac_dir,i_demean,i_dgp,i_series,sdata_dir)

% Function that defines experiments
T = 200;

fstr = [fac_dir 'har_fac_' num2str(i_demean)];load(fstr); 
bpnamevec = har_fac.bpnamevec; 
bptcodevec = har_fac.bptcodevec;

% Read in Data
if i_dgp == 1
    suf = ['independent_' num2str(i_demean) '_'];
elseif i_dgp == 2
    suf = ['normal_' num2str(i_demean) '_'];
elseif i_dgp == 3
    suf = ['empirical_' num2str(i_demean) '_'];
end;

nlast = 0;

if iexp == 7;
    
    iw = colnumber('BUSLOANS',bpnamevec);
    iv = colnumber('PCESVC96_Q',bpnamevec);
    fstr = [sdata_dir 'sdata_' suf num2str(iw)]; load(fstr); s_w = s_mat;
    fstr = [sdata_dir 'sdata_' suf num2str(iv)]; load(fstr); s_v = s_mat; 
    nrep = size(s_mat,2);
   
    s_y = s_w;
    s_x = s_v;
    ind_series = [iw iv]';
    tc = bptcodevec(iw);
       
    nph = 12;
    nlagx = 1;
    nlagy = 0;
    
    nn = max([nlagx;nlagy]);
    x_mat = NaN(nlagx,T,nrep);
    for ii = 1:nlagx
     x_mat(ii,:,:) = s_x(1+nn-ii:T+nn-ii,:);
    end;
    k = 1+nlagy;
    z_mat = NaN(k,T,nrep);
    z_mat(1,:,:) = ones(T,nrep);
    for ii = 1:nlagy;
        z_mat(1+ii,:,:) = s_y(1+nn-ii:T+nn-ii,:); 
    end;
    
    cum_s_y = cumsum(s_y);
    cum_cum_s_y = cumsum(cum_s_y);
    if (tc==1) | (tc==4)
        y_mat = s_y(nph+nn:T+nph+nn-1,:);
    end
    if (tc==2) | (tc==5)
        y_mat = cum_s_y(nph+nn:T+nph+nn-1,:)-cum_s_y(nn:T+nn-1,:);
    end
    if (tc==3) | (tc==6)
        y_mat = cum_cum_s_y(nph+nn:T+nph+nn-1,:)-cum_cum_s_y(nn:T+nn-1,:)-nph*cum_s_y(nn:T+nn-1,:);
    end
    
end;

if iexp == 19;
    
    iw = colnumber('HOUSTNE',bpnamevec);
    iv1 = colnumber('AMBSL',bpnamevec);
    iv2 = colnumber('FEDFUNDS',bpnamevec);
    iv3 = colnumber('PERMIT',bpnamevec);
   
   fstr = [sdata_dir 'sdata_' suf num2str(iw)];  load(fstr); s_w = s_mat;
   fstr = [sdata_dir 'sdata_' suf num2str(iv1)]; load(fstr); s_v1 = s_mat; 
   fstr = [sdata_dir 'sdata_' suf num2str(iv2)]; load(fstr); s_v2 = s_mat;
   fstr = [sdata_dir 'sdata_' suf num2str(iv3)]; load(fstr); s_v3 = s_mat;
   nrep = size(s_mat,2);
   
   nlag = 2;    % Current and nlag lags are included
   npad = 10;   % exta time periods for padding for use with initial conditions
   m = 1;
   k = 1+3+2*nlag;
   nph = 12;
 
       ind_series = [iw iv1 iv2 iv3]';
       s1 = s_w;
       s2 = s_v1;
       tc = bptcodevec(iw);
  
   
   x_mat = NaN(1,T,nrep);
   x_mat(1,:,:) = s2(npad+nlag+1:npad+T+nlag,:); 
   z_mat = NaN(1+3+nlag*4,T,nrep);
   z_mat(1,:,:) = ones(T,nrep);
   z_mat(2,:,:) = s1(npad+nlag+1:npad+T+nlag,:); 
   z_mat(3,:,:) = s_v2(npad+nlag+1:npad+T+nlag,:); 
   z_mat(4,:,:) = s_v3(npad+nlag+1:npad+T+nlag,:); 
   for i = 1:nlag;
       j = i*4;
       z_mat(j+1,:,:) = s2(npad+nlag+1-i:npad+T+nlag-i,:);
       z_mat(j+2,:,:) = s1(npad+nlag+1-i:npad+T+nlag-i,:);
       z_mat(j+3,:,:) = s_v2(npad+nlag+1-i:npad+T+nlag-i,:);
       z_mat(j+4,:,:) = s_v3(npad+nlag+1-i:npad+T+nlag-i,:);
   end;
   
   cum_s_y = cumsum(s1);
   cum_cum_s_y = cumsum(cum_s_y);
   
   if (tc == 1) | (tc == 4)
       y_mat = s1(npad+nph+1+nlag:npad+T+nph+nlag,:);
   elseif (tc == 2) | (tc == 5)
       y_mat = cum_s_y(npad+nph+1+nlag:npad+T+nph+nlag,:) - cum_s_y(npad+1+nlag:npad+T+nlag,:);
   elseif (tc ==3) | (tc == 6)
       y_mat = cum_cum_s_y(npad+nph+1+nlag:npad+T+nph+nlag,:) - cum_cum_s_y(npad+1+nlag:npad+T+nlag,:)-nph*cum_s_y(npad+1+nlag:npad+T+nlag,:);
   end 
   
end;

end

