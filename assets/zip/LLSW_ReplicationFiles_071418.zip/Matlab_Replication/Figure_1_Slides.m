% Compute Figure 1 .. a summary figure
% 20180509
% 

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

sz = 0.05;      % Size to use for calculations

% Compute Omega values
ar_coef = 0.7;
n_acv = 1000;
acv = arma_acv(ar_coef,0,n_acv);
acv_0 = acv(1);
acv_L = acv(2:end);
spec_0 = acv_0 + 2*sum(acv_L,1);
tmp = (1:1:n_acv)';
tmp2 = tmp.^2;
sec_1 = 2*sum(tmp.*acv_L,1);
sec_2 = 2*sum(tmp2.*acv_L,1);
omega_1 = sec_1/spec_0;
omega_2 = sec_2/spec_0;
[size_constant_vec,power_constant_vec] = compute_size_power_constants(1,sz);
bvec = linspace(0.001,1.00,400);
q_ewc = 2;
kq_ewc = pi^2/6;
int_ksq_ewc = 1;
q_nw = 1;
kq_nw = 1;
int_ksq_nw = 2/3;
q_qs = 2;
kq_qs = pi^2/10;
int_ksq_qs = 6/5;
T = 200;

% Compute Bounds;
    
% Results for NW
    q = q_nw;
    kq = kq_nw;
    int_ksq = int_ksq_nw;
    omega = omega_1;
    nw_sd_lls = size_constant_vec(1)*omega*kq*(bvec*T).^(-q);
    nw_pd_lls = power_constant_vec(1)*(int_ksq*bvec);
    
% Results for ewc
    q = q_ewc;
    kq = kq_ewc;
    int_ksq = int_ksq_ewc;
    omega = omega_2;
    cos_sd_lls = size_constant_vec(1)*omega*kq*(bvec*T).^(-q);
    cos_pd_lls = power_constant_vec(1)*(int_ksq*bvec); 
    
% Results for qs  
    q = q_qs;
    kq = kq_qs;
    int_ksq = int_ksq_qs;
    omega = omega_2;
    qs_sd_lls = size_constant_vec(1)*omega*kq*(bvec*T).^(-q);
    qs_pd_lls = power_constant_vec(1)*(int_ksq*bvec); 
    
% Read in Results
    experiment_group = 1;
    i_experiment = 1;
    fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
    NW_rslt = rslt.NW_rslt;
    Cos_rslt = rslt.Cos_rslt;
    nw_sd = NW_rslt.size - 0.05;
    cos_sd = Cos_rslt.size - 0.05;
    nw_pd = NW_rslt.pow_dif_sizeadj;
    cos_pd = Cos_rslt.pow_dif_sizeadj;
    tb_sd= nw_sd(end); tb_pd= nw_pd(end);
    kvb_sd= nw_sd(1); kvb_pd= nw_pd(1);
 
figure;
plot(qs_sd_lls,qs_pd_lls,'-. g','LineWidth',3);
ax = gca;
ax.FontSize = 25;
xlabel('Size Distortion');
ylabel('Power Loss');
xlim([0 0.10]);
ylim([0 0.25]);
legend('QS','Location','NorthEast');

set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_1_a'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);

figure;
plot(qs_sd_lls,qs_pd_lls,'-. g','LineWidth',3);
hold on;
plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
ax = gca;
ax.FontSize = 25;
xlabel('Size Distortion');
ylabel('Power Loss');
xlim([0 0.10]);
ylim([0 0.25]);
legend('QS','EWC','Location','NorthEast');

set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_1_b'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);

figure;
plot(qs_sd_lls,qs_pd_lls,'-. g','LineWidth',3);
hold on;
plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
ax = gca;
ax.FontSize = 25;
xlabel('Size Distortion');
ylabel('Power Loss');
xlim([0 0.10]);
ylim([0 0.25]);
legend('QS','EWC','NW','Location','NorthEast');

set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_1_c'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);


figure;
plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
ax = gca;
ax.FontSize = 25;
xlabel('Size Distortion');
ylabel('Power Loss');
xlim([0 0.10]);
ylim([0 0.25]);
legend('EWC','Location','NorthEast');
legend('AutoUpdate','off');

kappa = 0.90;
con = 2.14*(1-kappa)*.05^2;
s_k = linspace(0,.025,100)';
p_k = real(sqrt((con - kappa*s_k.^2)/(1-kappa)));
plot(s_k,p_k,': b','LineWidth',4);

% skstar_ewc = 0.0202;
% pkstar_ewc = 0.0505;
skstar_ewc = 0.0145;
pkstar_ewc = 0.0585;
plot(skstar_ewc,pkstar_ewc,'bp','MarkerFaceColor','b','MarkerSize',35);
set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_1_d'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);



figure;
legend('AutoUpdate','on');
plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
hold on;
plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
ax = gca;
ax.FontSize = 25;
xlabel('Size Distortion');
ylabel('Power Loss');
xlim([0 0.10]);
ylim([0 0.25]);
legend('EWC','NW','Location','NorthEast');
legend('AutoUpdate','off');

kappa = 0.90;
con = 2.14*(1-kappa)*.05^2;
s_k = linspace(0,.025,100)';
p_k = real(sqrt((con - kappa*s_k.^2)/(1-kappa)));
plot(s_k,p_k,': b','LineWidth',4);
% skstar_ewc = 0.0202;
% pkstar_ewc = 0.0505;
skstar_ewc = 0.0145;
pkstar_ewc = 0.0585;
plot(skstar_ewc,pkstar_ewc,'bp','MarkerFaceColor','b','MarkerSize',35);

%kappa = 0.75;
kappa = 0.90;
%con = 1.21*(1-kappa)*.05^2;
con = 2.05*(1-kappa)*.05^2;
%s_k = linspace(0,.032,100)';
s_k = linspace(0,.024,100)';
p_k = real(sqrt((con - kappa*s_k.^2)/(1-kappa)));
plot(s_k,p_k,': r','LineWidth',4);


% skstar_nw = 0.022;
% pkstar_nw = 0.0398;
skstar_nw = 0.0169;
pkstar_nw = 0.0515;
plot(skstar_nw,pkstar_nw,'rp','MarkerFaceColor','r','MarkerSize',35);

set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_1_e'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);

error('tmp');
%close(gcf);


    
figure;
plot(qs_sd_lls,qs_pd_lls,'-. g','LineWidth',2);
hold on;
plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
ax = gca;
ax.FontSize = 25;
xlabel('Size Distortion');
ylabel('Power Loss');
xlim([0 0.10]);
ylim([0 0.25]);
legend('QS','EWC','NW','Location','NorthEast');

set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
legend('AutoUpdate','off');

plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',20);
plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',20);
plot(tb_sd,tb_pd,'ro','MarkerFaceColor','r','MarkerSize',30);
plot(kvb_sd,kvb_pd,'r^','MarkerFaceColor','r','MarkerSize',30);
% 
%kappa = 0.75;
kappa = 0.90;
%con = 1.21*(1-kappa)*.05^2;
con = 2.05*(1-kappa)*.05^2;
%s_k = linspace(0,.032,100)';
s_k = linspace(0,.024,100)';
p_k = real(sqrt((con - kappa*s_k.^2)/(1-kappa)));
plot(s_k,p_k,': r','LineWidth',4);



% skstar_nw = 0.022;
% pkstar_nw = 0.0398;
skstar_nw = 0.0169;
pkstar_nw = 0.0515;
plot(skstar_nw,pkstar_nw,'rp','MarkerFaceColor','r','MarkerSize',35);

kappa = 0.90;
con = 2.14*(1-kappa)*.05^2;
s_k = linspace(0,.025,100)';
p_k = real(sqrt((con - kappa*s_k.^2)/(1-kappa)));
plot(s_k,p_k,': b','LineWidth',4);

% skstar_ewc = 0.0202;
% pkstar_ewc = 0.0505;
skstar_ewc = 0.0145;
pkstar_ewc = 0.0585;
plot(skstar_ewc,pkstar_ewc,'bp','MarkerFaceColor','b','MarkerSize',35);


T = 200;
[Cos_Mat,qvec,i_qvec] = Cosine_rules_glm(200,1); 
[NW_Mat,kvec] = NW_rules_glm(200);
qstar = floor(0.41*T^(2/3));
kstar = ceil(1.3*T^(1/2));
[tmp,inw] = min(abs(kvec-kstar));
[tmp,icos] = min(abs(qvec-qstar));

plot(nw_sd(inw),nw_pd(inw),'rp','MarkerSize',35,'LineWidth',5);
plot(cos_sd(icos),cos_pd(icos),'bp','MarkerSize',35,'LineWidth',5);

set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_1_kappa_90'; str_fig = [figdir fig_str]; saveas(gcf,[str_fig '.png']);

%close(gcf);




path(p);  % Reset path
 