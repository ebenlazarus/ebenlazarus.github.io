function [irand] = rand_int(i1,i2)
% Choose an integer at random between i1 and i2;
i1 = floor(i1);
i2 = ceil(i2);
n = i2-i1+1;
tmp = rand(n,1);
[mm,ii] = min(tmp);
irand = ii+(i1-1);

end