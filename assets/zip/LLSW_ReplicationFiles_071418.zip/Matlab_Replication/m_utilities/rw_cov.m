function [cov_rw ] = rw_cov(T)
% Construct random walk covariance matrix of size T .. unit variance
% innnovations, zero initial condition
  A = tril(ones(T,T));
  cov_rw = A*A';
end

