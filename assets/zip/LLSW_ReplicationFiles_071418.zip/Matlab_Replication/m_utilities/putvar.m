function [varnamevec,vardatamat] = putvar(varname,vardata,varnamevec,vardatamat)
% put data on a variable into varnamevec and vardatamat
% input:
%       varname is a string with the variable of interest
%       varnamevec is a string vector containing all variable names:
%       n_series x 1
%       vardatamat is n x nseries data matrix.
ustr = char(varname);
varnamevec = [varnamevec;ustr];
vardatamat = [vardatamat vardata];

end

