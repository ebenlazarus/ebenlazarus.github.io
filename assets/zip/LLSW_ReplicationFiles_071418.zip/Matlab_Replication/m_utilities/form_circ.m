function [ec] = form_circ(e,T)
% Form circulant of size T
ec = e;
while size(ec,1) < T;
   ec = [ec;flipud(ec(1:end-1,:))];
end;
ec = ec(1:T,:);


end

