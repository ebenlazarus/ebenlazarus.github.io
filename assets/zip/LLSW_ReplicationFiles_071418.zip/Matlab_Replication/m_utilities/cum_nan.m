% Y = cum_nan(y) 
% 
% cumulate with NaN's at the beginning
% y can have multiple series (columns), and Y will do the columns separately
% if there's an NaN in the middle, it will have NaNs thereon
% (Fernald 1/2017)

function Y = cum_nan(y);
   [obs, ser ] = size(y) ;
    Y = NaN(obs,ser); 
        
    for j = 1:ser; % 
        % drop exists = isnan(y(:,j))
         begin = find(~isnan( y(:,j) ),1) ; % first non-NaN value
         ending = find(~isnan( y(:,j) ),1,'last') ; % last non-NaN value
     
         Y(begin:ending,j)=cumsum(y(begin:ending,j)) ;
    end
       
end

