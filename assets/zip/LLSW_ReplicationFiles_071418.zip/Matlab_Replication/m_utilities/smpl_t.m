function [calvec_tdate] = smpl_t(calvec,tdate,nper)
% find index in calvec corresponding to tdate

i1 = tdate(1) + (tdate(2)-1)/nper;
calvec_tdate = find(calvec>i1-.0001, 1 );

end

