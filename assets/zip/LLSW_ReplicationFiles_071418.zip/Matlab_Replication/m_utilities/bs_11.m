function er = bs_11(e)
%
% er contains e where each entry is
% multiplied by +1 or -1 with probability 1/2;
a = rand(size(e));
a = (a <= 0.5) - (a > 0.5);
er = e.*a;

end

