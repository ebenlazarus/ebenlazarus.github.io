function [cor] = cor_compute(x,y)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
x = (x-mean(x))/std(x);
y = (y-mean(y))/std(y);

cor = sum(x.*y)/sqrt(sum(x.^2)*sum(y.^2));

end

