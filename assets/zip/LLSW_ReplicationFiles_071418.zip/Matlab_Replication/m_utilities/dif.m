function [dx] = dif(x,p)
% Form x(t) - x(t-p) with missing values for initial conditions 
 dx = x - lag(x,p);
end

