function [ i1,i2 ] = calendar_subsets(cal1,cal2)
% Find indices of cal2 that are in cal1 and vice versa
i1 = (cal1 >= cal2(1)-.0000001) .* (cal1 <= cal2(end)+.000001);
i2 = (cal2 >= cal1(1)-.0000001) .* (cal2 <= cal1(end)+.000001);

end

