% % Plot Recession
% [nobs,calvec,calds] = calendar_make([1910 1],[2017 1],12);
% 
% X = (1:nobs)';
% 
% plot(calvec,X);
% hold on;
% ax = gca;  % This gets axis limits for current plot (must be open)
% x_lim = ax.XLim;
% y_lim = ax.YLim;
% 
% 
% NBER_PT = NBER_Peak_Trough_Decimal_Dates;
% nbc = size(Rec_dd,1);
% for bc = 1:nbc;
%     % Check to see if this BC is included in plot
%     if (NBER_PT(bc,1) <= x_lim(2)) & (NBER_PT(bc,2) >= x_lim(1));
%         x1 = NBER_PT(bc,1);
%         x2 = NBER_PT(bc,2);
%         if x1 < x_lim(1);
%             x1 = x_lim(1);
%         end;
%         if x2 > x_lim(2);
%             x2 = x_lim(2);
%         end;
%         ha = area([x1 x2], [y_lim(2) y_lim(2)],y_lim(1),'LineStyle','none','FaceColor',[0.8 0.8 0.8]); 
%     end;
% end;
% plot(calvec,X,'- r','LineWidth',3);
% hold off;
% 
% hold on;
% plot(calvec,X*0.5);
% hold off;
% 


[nobs,calvec,calds] = calendar_make([1972 2],[2015 3], 4);
X = (1:nobs)';
plot(calvec,X);
ax = gca;  % This gets axis limits for current plot (must be open)
x_lim = ax.XLim;
y_lim = ax.YLim;
recession_bars(x_lim,y_lim);
hold on;
 plot(calvec,X,'- b','LineWidth',2);
hold off;

   