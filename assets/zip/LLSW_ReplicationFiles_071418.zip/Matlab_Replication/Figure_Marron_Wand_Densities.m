% Compute Figure Marron-Wand Densities
% 20171213
% 

% Notation: var_ubar_actual: Exact Finite-Sample Covariance matrix for ubar 

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);


[x_n,dens_n] = dens_mw(1);
[x_2,dens_2] = dens_mw(2);
[x_3,dens_3] = dens_mw(3);
[x_4,dens_4] = dens_mw(4);
[x_5,dens_5] = dens_mw(5);

figure;

subplot(2,2,1);
   plot(x_n,dens_n,'- b','LineWidth',1);
   hold on
     plot(x_2,dens_2,'- r','LineWidth',2);
   hold off;
   ax = gca;
   ax.FontSize = 20
   title('(a) Skewed');
 
 subplot(2,2,2);
   plot(x_n,dens_n,'- b','LineWidth',1);
   hold on
     plot(x_3,dens_3,'- r','LineWidth',2);
   hold off;
   title('(b) Stongly Skewed');
   ax = gca;
   ax = gca;
   ax.FontSize = 20
 
 subplot(2,2,3);
   plot(x_n,dens_n,'- b','LineWidth',1);
   hold on
     plot(x_4,dens_4,'- r','LineWidth',2);
   hold off;
   title('(c) Kurtotic');
   ax = gca;
   ax = gca;
   ax.FontSize = 20

 subplot(2,2,4);
   plot(x_n,dens_n,'- b','LineWidth',1);
   hold on
     plot(x_5,dens_5,'- r','LineWidth',2);
   hold off;
   title('(d) Outlier');
   ax = gca;
   ax = gca;
   ax.FontSize = 20;
 
set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_Marron_Wand_densities'; str_fig = [figdir fig_str]; saveas(gcf,[str_fig '.png']);
 
% Compute Moments:
mw_rslt=NaN(5,4);
nrep = 100000000;
for imw = 1: 5;
   y = rand_mw(nrep,imw);
   m = mean(y);
   s = std(y);
   x = (y-m)/s;
   skew = mean(x.^3);
   kurt = mean(x.^4);
   [imw m s skew kurt]
end;

% Compute moments of AR(1) Versions;
n_burnin = 10000;
for imw = 1: 5;
   e = rand_mw(nrep+n_burnin,imw);
   y = zeros(nrep+n_burnin,1);
   for t = 2:nrep+n_burnin;
       y(t) = 0.7*y(t-1) + e(t);
   end;
   y = y(n_burnin+1:end);
   m = mean(y);
   s = std(y);
   x = (y-m)/s;
   skew = mean(x.^3);
   kurt = mean(x.^4);
   [imw m s skew kurt]
end;



path(p);  % Reset path
 