% Compute Figure 1 .. a summary figure
% 20180509
% 

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

sz = 0.05;      % Size to use for calculations

% Compute Omega values
ar_coef = 0.7;
n_acv = 1000;
acv = arma_acv(ar_coef,0,n_acv);
acv_0 = acv(1);
acv_L = acv(2:end);
spec_0 = acv_0 + 2*sum(acv_L,1);
tmp = (1:1:n_acv)';
tmp2 = tmp.^2;
sec_1 = 2*sum(tmp.*acv_L,1);
sec_2 = 2*sum(tmp2.*acv_L,1);
omega_1 = sec_1/spec_0;
omega_2 = sec_2/spec_0;
[size_constant_vec,power_constant_vec] = compute_size_power_constants(1,sz);
bvec = linspace(0.001,1.00,400);
q_ewc = 2;
kq_ewc = pi^2/6;
int_ksq_ewc = 1;
q_nw = 1;
kq_nw = 1;
int_ksq_nw = 2/3;
q_qs = 2;
kq_qs = pi^2/10;
int_ksq_qs = 6/5;
T = 200;

% Compute Bounds;
    
% Results for NW
    q = q_nw;
    kq = kq_nw;
    int_ksq = int_ksq_nw;
    omega = omega_1;
    nw_sd_lls = size_constant_vec(1)*omega*kq*(bvec*T).^(-q);
    nw_pd_lls = power_constant_vec(1)*(int_ksq*bvec);
    
% Results for ewc
    q = q_ewc;
    kq = kq_ewc;
    int_ksq = int_ksq_ewc;
    omega = omega_2;
    cos_sd_lls = size_constant_vec(1)*omega*kq*(bvec*T).^(-q);
    cos_pd_lls = power_constant_vec(1)*(int_ksq*bvec); 
    
% Results for qs  
    q = q_qs;
    kq = kq_qs;
    int_ksq = int_ksq_qs;
    omega = omega_2;
    qs_sd_lls = size_constant_vec(1)*omega*kq*(bvec*T).^(-q);
    qs_pd_lls = power_constant_vec(1)*(int_ksq*bvec); 
 
figure;
MS = 10;  % Marker Size
axFS = 25;

subplot(2,3,1);
% Read in Results
    experiment_group = 1;
    i_experiment = 1;
    fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
    NW_rslt = rslt.NW_rslt;
    Cos_rslt = rslt.Cos_rslt;
    nw_sd = NW_rslt.size - 0.05;
    cos_sd = Cos_rslt.size - 0.05;
    nw_pd = NW_rslt.pow_dif_sizeadj;
    cos_pd = Cos_rslt.pow_dif_sizeadj;
 
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(a) Gaussian');
  lgd=legend('EWC: asymptotic frontier','NW: asymptotic frontier','EWC: finite sample','NW: finite sample');
  lgd.FontSize = 20;
  
  
  subplot(2,3,2);
  experiment_group = 2;
  i_experiment = 1;
  fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
  NW_rslt = rslt.NW_rslt;
  Cos_rslt = rslt.Cos_rslt;
  nw_sd = NW_rslt.size - 0.05;
  cos_sd = Cos_rslt.size - 0.05;
  nw_pd = NW_rslt.pow_dif_sizeadj;
  cos_pd = Cos_rslt.pow_dif_sizeadj;
  
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(b) Skewed');
  
  subplot(2,3,3);
  experiment_group = 2;
  i_experiment = 2;
  fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
  NW_rslt = rslt.NW_rslt;
  Cos_rslt = rslt.Cos_rslt;
  nw_sd = NW_rslt.size - 0.05;
  cos_sd = Cos_rslt.size - 0.05;
  nw_pd = NW_rslt.pow_dif_sizeadj;
  cos_pd = Cos_rslt.pow_dif_sizeadj;
  
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(c) Strongly Skewed');
  
  subplot(2,3,4);
  experiment_group = 2;
  i_experiment = 3;
  fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
  NW_rslt = rslt.NW_rslt;
  Cos_rslt = rslt.Cos_rslt;
  nw_sd = NW_rslt.size - 0.05;
  cos_sd = Cos_rslt.size - 0.05;
  nw_pd = NW_rslt.pow_dif_sizeadj;
  cos_pd = Cos_rslt.pow_dif_sizeadj;
  
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(d) Kurtotic');
  
  subplot(2,3,5);
  experiment_group = 2;
  i_experiment = 4;
  fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
  NW_rslt = rslt.NW_rslt;
  Cos_rslt = rslt.Cos_rslt;
  nw_sd = NW_rslt.size - 0.05;
  cos_sd = Cos_rslt.size - 0.05;
  nw_pd = NW_rslt.pow_dif_sizeadj;
  cos_pd = Cos_rslt.pow_dif_sizeadj;
  
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(e) Outlier');
  
  subplot(2,3,6);
  experiment_group = 3;
  i_experiment = 1;
  fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
  NW_rslt = rslt.NW_rslt;
  Cos_rslt = rslt.Cos_rslt;
  nw_sd = NW_rslt.size - 0.05;
  cos_sd = Cos_rslt.size - 0.05;
  nw_pd = NW_rslt.pow_dif_sizeadj;
  cos_pd = Cos_rslt.pow_dif_sizeadj;
  
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(f) GARCH(0.85,0.10)');


set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_3'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);


MS = 15;  % Marker Size
axFS = 25;

% Read in Results
    experiment_group = 1;
    i_experiment = 1;
    fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
    NW_rslt = rslt.NW_rslt;
    Cos_rslt = rslt.Cos_rslt;
    nw_sd = NW_rslt.size - 0.05;
    cos_sd = Cos_rslt.size - 0.05;
    nw_pd = NW_rslt.pow_dif_sizeadj;
    cos_pd = Cos_rslt.pow_dif_sizeadj;

  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(a) Gaussian');
  lgd=legend('EWC: asymptotic frontier','NW: asymptotic frontier','EWC: finite sample','NW: finite sample');
  lgd.FontSize = 20;
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
  fig_str = 'Figure_3a'; str_fig = [figdir fig_str]; 
  saveas(gcf,str_fig);
  saveas(gcf,[str_fig '.png']);
  close(gcf);
  
  
  experiment_group = 2;
  i_experiment = 1;
  fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
  NW_rslt = rslt.NW_rslt;
  Cos_rslt = rslt.Cos_rslt;
  nw_sd = NW_rslt.size - 0.05;
  cos_sd = Cos_rslt.size - 0.05;
  nw_pd = NW_rslt.pow_dif_sizeadj;
  cos_pd = Cos_rslt.pow_dif_sizeadj;
  
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(b) Skewed');
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_3b'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);
  
  experiment_group = 2;
  i_experiment = 2;
  fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
  NW_rslt = rslt.NW_rslt;
  Cos_rslt = rslt.Cos_rslt;
  nw_sd = NW_rslt.size - 0.05;
  cos_sd = Cos_rslt.size - 0.05;
  nw_pd = NW_rslt.pow_dif_sizeadj;
  cos_pd = Cos_rslt.pow_dif_sizeadj;
  
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(c) Strongly Skewed');
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_3c'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);
  
  experiment_group = 2;
  i_experiment = 3;
  fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
  NW_rslt = rslt.NW_rslt;
  Cos_rslt = rslt.Cos_rslt;
  nw_sd = NW_rslt.size - 0.05;
  cos_sd = Cos_rslt.size - 0.05;
  nw_pd = NW_rslt.pow_dif_sizeadj;
  cos_pd = Cos_rslt.pow_dif_sizeadj;
  
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(d) Kurtotic');
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_3d'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);
  
  experiment_group = 2;
  i_experiment = 4;
  fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
  NW_rslt = rslt.NW_rslt;
  Cos_rslt = rslt.Cos_rslt;
  nw_sd = NW_rslt.size - 0.05;
  cos_sd = Cos_rslt.size - 0.05;
  nw_pd = NW_rslt.pow_dif_sizeadj;
  cos_pd = Cos_rslt.pow_dif_sizeadj;
  
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(e) Outlier');
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_3e'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);
  
 
  experiment_group = 3;
  i_experiment = 1;
  fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];load(fstr);
  NW_rslt = rslt.NW_rslt;
  Cos_rslt = rslt.Cos_rslt;
  nw_sd = NW_rslt.size - 0.05;
  cos_sd = Cos_rslt.size - 0.05;
  nw_pd = NW_rslt.pow_dif_sizeadj;
  cos_pd = Cos_rslt.pow_dif_sizeadj;
  
  plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
    plot(nw_sd(2:end-4),nw_pd(2:end-4),'ro','LineWidth',3,'MarkerSize',MS);
    plot(cos_sd(1:end),cos_pd(1:end),'bs','LineWidth',3,'MarkerSize',MS);
  hold off;
  ax = gca;
  ax.FontSize = axFS;
  xlabel('Size Distortion');
  ylabel('Power Loss');
  xlim([0 0.10]);
  ylim([0 0.25]);
  title('(f) GARCH(0.85,0.10)');
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_3f'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);


path(p);  % Reset path
 