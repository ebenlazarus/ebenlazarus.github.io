% Departures from null
% Compute infeasible power and calibrate a grid of values to approximate sup
% power loss
% MWW, 20180114

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat_cv/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

mvec = (1:1:12)';   % values of m to consider
q = 18;             % values of q for calibration
n_delta = 50;       % Number of points

size_vec = [0.10 0.05 0.01]';
n_size = size(size_vec,1);

for im = 1:size(mvec,1);
    m = mvec(im);
    nu1 = m;
    nu2 = q-m+1;
    nuL = 999999;
    nrep = 1000;
%     %Simulations to check calculations
%     b = randn(m,nrep);
%     vbi = NaN(m,m,nrep);
%     for irep = 1:nrep;
%         z = randn(q,m);
%         vbi(:,:,irep) = inv(z'*z/q);
%     end;
    
    for isize = 1:n_size;
        sz = size_vec(isize);
        pct_vec = linspace(sz+.001,0.999,n_delta)';  % Target power values
        pct_vec = [pct_vec;linspace(0.9991,0.9999,9)'];
        delta_mat = NaN(size(pct_vec,1)+1,2);
        cv_feas = finv(1-sz,m,q-m+1);    % Critical value for feasible test
        cv_inf = finv(1-sz,nu1,nuL);    % Critical value for infeasible test
        for id = 1:size(pct_vec,1);
            pct = pct_vec(id);       % Target power
            del = find_delta(cv_feas,pct,nu1,nu2);
            % Compute infeasible power
            pow = ncfcdf(cv_inf,nu1,nuL,del,'upper');
            delta_mat(id,1) = del;
            delta_mat(id,2) = pow;
%             
%             % Check .. compute MC power;
%             cv_fstat = cv_feas*q/(q-m+1);   % For
%             f_feas = NaN(nrep,1);
%             for irep = 1:nrep;
%                vi = squeeze(vbi(:,:,irep));
%                bi = b(:,irep);
%                bi(1) = bi(1)+sqrt(del);
%                f_feas(irep) = bi'*vi*bi/m;
%             end;
%             [m del pct mean(f_feas > cv_fstat)]   

        end;
        % find value of delta with infeasible power = 0.5;
        del = find_delta(cv_inf,0.5,nu1,nuL);
        pow = ncfcdf(cv_inf,nu1,nuL,del,'upper');
        delta_mat(end,1) = del;  
        delta_mat(end,2) = pow;
        delta_mat(:,1) = sqrt(delta_mat(:,1));  % Square root of nc parameter in Matlab
        fstr = [matdir 'delta_mat_' num2str(m) '_' num2str(100*sz)];save(fstr,'delta_mat');  
    end;
end;

path(p);  % Reset path
 