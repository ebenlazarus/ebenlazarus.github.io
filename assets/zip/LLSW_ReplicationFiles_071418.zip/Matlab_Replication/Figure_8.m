% Summary plots for GLM Factor MCs

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
acvdir = '../Factor_Replication/matlab/mat/';
matcvdir = 'mat_cv/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;                               % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

% Demeaning Parameters .. model for data when estimates
i_demean = 1;  % 0 Do Nothing
               % 1 Eliminate low-frequency by local Demeaning
               % 2 Eliminate low-frequency trend by full-sample demeaning;
% DGP
i_dgp = 2;  % 1 for "independent"; 2 for "normal"; 3 for "empirical");

if i_dgp == 1
    suf = ['independent_' num2str(i_demean) '_'];
elseif i_dgp == 2
    suf = ['normal_' num2str(i_demean) '_'];
elseif i_dgp == 3
    suf = ['empirical_' num2str(i_demean) '_'];
end;


% Step 1 .. read in results and save key statistics
iexp = 1;

% Read in results
fstr = [matdir 'rslt_glm_fac_randn_' suf '_' num2str(iexp)];load(fstr); 
NW_rslt_mat = rslt.NW_rslt_mat;
Cos_rslt_mat = rslt.Cos_rslt_mat;
T = rslt.T;
% Subtract 5% size so these are size distortions
sz = 0.05;
NW_rslt_mat.size_dist = NW_rslt_mat.size - sz;
Cos_rslt_mat.size_dist = Cos_rslt_mat.size - sz;

cos_sd_mat = Cos_rslt_mat.size_dist;
nw_sd_mat = NW_rslt_mat.size_dist;
cos_pd_mat = Cos_rslt_mat.pow_dif_sizeadj;
nw_pd_mat = NW_rslt_mat.pow_dif_sizeadj;

% Read in Autocovariances from DGP
fstr = [acvdir 'har_fac_acvmatrix'];load(fstr); 
fstr = [acvdir 'har_fac_' num2str(i_demean)];load(fstr,'har_fac'); 
bplabvec_short = har_fac.bplabvec_short;
bpnamevec = har_fac.bpnamevec;

[size_constant_vec,power_constant_vec] = compute_size_power_constants(1,sz);
bvec = linspace(0.001,1.00,400)';
q_ewc = 2;
kq_ewc = pi^2/6;
int_ksq_ewc = 1;
q_nw = 1;
kq_nw = 1;
int_ksq_nw = 2/3;

n_series = size(cos_sd_mat,2);
n_acv = size(acv_mat,1)-1;


% Series to use
i_series_plot = [1 12 73 184 183 154];
i_title = {...
    '(a) GDP (growth rate)';...
    '(b) Government spending (growth rate)'; ...
    '(c) Avg. hourly earning in mfg. (growth rate)'; ...
    '(d) Real housing prices (growth rate)'; ...
    '(e) VIX'; ...
    '(f) 1Year - 3month term spread'};

ax_fs = 15;
ms = 15;
figure;
for j = 1:6;
    i = i_series_plot(j);
    str_tit = char(i_title(j));
    cos_sd = cos_sd_mat(:,i);
    cos_pd = cos_pd_mat(:,i);
    nw_sd = nw_sd_mat(:,i);
    nw_pd = nw_pd_mat(:,i);
    acv = acv_mat(:,i);
    acv_0 = acv(1);
    acv_L = acv(2:end);
    spec_0 = acv_0 + 2*sum(acv_L,1);
    tmp = (1:1:n_acv)';
    tmp2 = tmp.^2;
    sec_1 = 2*sum(tmp.*acv_L,1);
    sec_2 = 2*sum(tmp2.*acv_L,1);
    omega_1 = sec_1/spec_0;
    omega_2 = sec_2/spec_0;
    % LLS Results for NW
    q = q_nw;
    kq = kq_nw;
    int_ksq = int_ksq_nw;
    omega = omega_1;
    nw_sd_lls = size_constant_vec(1)*omega*kq*(bvec*T).^(-q);
    nw_pd_lls = power_constant_vec(1)*(int_ksq*bvec); 
    % LLS Results for ewc
    q = q_ewc;
    kq = kq_ewc;
    int_ksq = int_ksq_ewc;
    omega = omega_2;
    cos_sd_lls = size_constant_vec(1)*omega*kq*(bvec*T).^(-q);
    cos_pd_lls = power_constant_vec(1)*(int_ksq*bvec); 
    
    subplot(2,3,j);
     plot(cos_sd_lls,cos_pd_lls,'- b','LineWidth',3);
     hold on;
      plot(nw_sd_lls,nw_pd_lls,'-- r','LineWidth',3);
      plot(cos_sd,cos_pd,'bs','LineWidth',3,'MarkerSize',ms);
      plot(nw_sd,nw_pd,'ro','LineWidth',3,'MarkerSize',ms);
     hold off;
     ax = gca;
     ax.FontSize = ax_fs;
     xlabel('Size Distortion'); 
     ylabel('Power Loss');
     if j == 1
       legend('EWC: GLM Asymptotic Tradeoff','NW: GLM Asymptotic Tradeoff','EWC Finite Sample','NW: Finite Sample','Location','NorthEast');
     end
     x1 = min([cos_sd;nw_sd]);
     x1 = min([0;x1]);
     x2 = max([cos_sd;nw_sd]);
     x2 = max([x2;0.10]);
     xlim([x1 x2]);
     ylim([0 0.20]);
     title(str_tit);    
end;

set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen 
str_fig = [figdir 'Figure_8']; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
  
path(p);  % Reset path
 