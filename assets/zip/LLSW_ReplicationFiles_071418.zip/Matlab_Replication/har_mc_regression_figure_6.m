% har_mc .. regression in Figure 5
% MWW, 20180511
% Regresion model with one regressor
% Simulation Results for figure 5

clear all;
small = 1.0e-10;
aa=datetime('now','TimeZone','America/New_York');

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
matcvdir = 'mat_cv/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

% Some parameters for calculations
nrep = 100000;
sz = 0.05;      % Size to use for calculations

% Experiment description
T = 200;
Tvec = linspace(100,500,9)';
dataparm.m = 1;
dataparm.k = 0;
dataparm.arma_x = zeros(2,1);
dataparm.arma_u = zeros(2,1);
dataparm.experiment_group = 1;  % regression with gaussian variables
rho = 0.7;
dataparm.arma_x(1) = sqrt(rho);
dataparm.arma_u(1) = sqrt(rho);
n_experiments = size(Tvec,1);
m = dataparm.m;


for i_experiment = 1:n_experiments;
    fprintf('Experiment %4i of %4i: ',[i_experiment n_experiments]);
    tic;
    rng(876997);                            % Same Seed for all experiments
    T = Tvec(i_experiment);
    dataparm.T = T;
    
    % Choose Cosine and NW Weights -- use many values 
    [Cos_Mat,qvec,i_qvec] = Cosine_rules_fig5b(T); 
    n_cos = size(qvec,1);        % Number of Cos Tests
    [NW_Mat,kvec] = NW_rules_fig5b(T);
    n_nw = size(kvec,1);         % Number of NW Tests
  
    % Step 0:  Initial calibration to determine grid of departures from null for beta
    n_init = 1000;
    bhat = NaN(m,n_init);
    parfor irep = 1:n_init;   
      [bhat(:,irep),tmp1,tmp2]=gendata(dataparm);
    end;
    var_bhat = bhat*bhat'/n_init;
    chol_varbhat = chol(var_bhat);
    % Read in power vector and delta values ...
    [dvec,power_inf_dvec]=get_delta(dataparm.m,sz,matcvdir);
    % Select grid of infeasible power values 
    b_inf_power = [0.05 0.25 0.50 0.66 0.75 1.00]';
    n_b = size(b_inf_power,1);
    bvec = NaN(m,n_b);              % bvec contains the departures from null that are considered
    for ib = 1:n_b;
        [tmp,ii]=min(abs(power_inf_dvec-b_inf_power(ib)));
        bvec(:,ib) = dvec(ii)*chol_varbhat(1,:)';
    end;
    bvec = [bvec 100*chol_varbhat(1,:)'];  % add distance departure to check consistency
    n_b = n_b+1;

    % Matrices for Storing Results
    bhat_mat = NaN(m,nrep);
    NW_var_inv_uhatx_mat = NaN(m,m,n_nw,nrep);
    Cos_var_inv_uhatx_mat = NaN(m,m,n_cos,nrep);
    NW_var_inv_ux_mat = NaN(m,m,n_nw,n_b+1,nrep);
    Cos_var_inv_ux_mat = NaN(m,m,n_cos,n_b+1,nrep);

    for irep = 1:nrep;   
      [bhat_mat(:,irep),uhatx,ux_mat]=gendata_depnull(dataparm,bvec);
      [NW_var_inv_uhatx_mat(:,:,:,irep)]=omega_hat_inv_nw(uhatx,NW_Mat);
      [Cos_var_inv_uhatx_mat(:,:,:,irep)]=omega_hat_inv_cos(uhatx,Cos_Mat,qvec);
      [NW_var_inv_ux_mat(:,:,:,:,irep)]=omega_hat_inv_nw_depnull(ux_mat,NW_Mat);
      [Cos_var_inv_ux_mat(:,:,:,:,irep)]=omega_hat_inv_cos_depnull(ux_mat,Cos_Mat,qvec); 
    end;

    % Compute exact power values using elements of bvec
    power_inf_bvec = compute_power_inf_bvec(bhat_mat,bvec,sz);

    % Summarize Type 1 and Type 2 errors;
    % Read in asymptotic critical values
    NW_cv = get_nw_cv(dataparm,kvec,sz,matcvdir);
    Cos_cv = get_cos_cv(dataparm,sz,qvec);
    
    % Compute error frequencies
    NW_uhatx_rslt = data_to_rslt_uxhat(bhat_mat,NW_var_inv_uhatx_mat,NW_cv,sz,bvec,power_inf_bvec,dataparm);
    Cos_uhatx_rslt = data_to_rslt_uxhat(bhat_mat,Cos_var_inv_uhatx_mat,Cos_cv,sz,bvec,power_inf_bvec,dataparm);
    NW_ux_rslt = data_to_rslt_ux(bhat_mat,NW_var_inv_ux_mat,NW_cv,sz,bvec,power_inf_bvec,dataparm);
    Cos_ux_rslt = data_to_rslt_ux(bhat_mat,Cos_var_inv_ux_mat,Cos_cv,sz,bvec,power_inf_bvec,dataparm);
  
    % Save Results
    rslt.NW_ux_rslt = NW_ux_rslt;
    rslt.Cos_ux_rslt = Cos_ux_rslt;
    rslt.NW_uhatx_rslt = NW_uhatx_rslt;
    rslt.Cos_uhatx_rslt = Cos_uhatx_rslt;

    fstr = [matdir 'rslt_regression_figure6_' num2str(i_experiment)];save(fstr,'rslt');
    toc;
end;

path(p);  % Reset path
 