% har_mc_factor_randn_figure8
% MWW, 20180512
% MC for Table 6 factor results

% Notation: var_ubar_actual: Exact Finite-Sample Covariance matrix for ubar 

clear all;
small = 1.0e-10;
%rng(20394183);

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
sdata_dir = '../Factor_Replication/matlab/sdata/';
fac_dir = '../Factor_Replication/matlab/mat/';
matcvdir = 'mat_cv/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

% Some parameters for calculations
sz = 0.05;      % Size to use for calculations

% Demeaning Parameters .. model for data when estimates
i_demean = 1;  % 0 Do Nothing
               % 1 Eliminate low-frequency by local Demeaning
               % 2 Eliminate low-frequency trend by full-sample demeaning;


               % DGP
i_dgp = 2;  % 1 for "independent"; 2 for "normal"; 3 for "empirical");

% Experiments to Run
iexp_vec = [7 19]';

nrand_series = 1;  % Number of random series to draw;
NW_ux_rslt_mat.size = NaN;
NW_uhatx_rslt_mat.size = NaN;
Cos_ux_rslt_mat.size = NaN;
Cos_uhatx_rslt_mat.size = NaN;

for jexp = 1:size(iexp_vec);
  iexp = iexp_vec(jexp);
  fprintf('Experiment %3i \n',iexp);
  for i_series = 1:nrand_series;
     tic;
     fprintf('   Experiment %3i and draw %3i: ',[iexp i_series]);
     % Set up Experiment 
     [y_mat,x_mat,z_mat,T,ind_series] = har_fac_experiment_randn_fig8(iexp,fac_dir,i_demean,i_dgp,i_series,sdata_dir);
     m = size(x_mat,1);
     dataparm.m = m;
     k = size(z_mat,1);
     dataparm.k = k;
     nrep = size(y_mat,2);
     dataparm.T = T;
     ym = y_mat;
     xm = x_mat;
     zm = z_mat;
    
     % Choose Cosine and NW Weights
     [Cos_Mat,qvec,i_qvec] = Cosine_rules_fig5(T,m); 
     n_cos = size(qvec,1);        % Number of Cos Tests
     [NW_Mat,kvec] = NW_rules_fig5(T);
     n_nw = size(kvec,1);         % Number of NW Tests
     
     % Compute approximation to population value of b
     b_avg = compute_b_avg(ym,xm,zm);
    
     % Step 0:  Initial calibration to determine grid of departures from null for beta
     n_init = 1000;
     bhat = NaN(m,n_init);
     parfor irep = 1:n_init;  
         ymi = ym(:,irep);
         xmi = squeeze(xm(:,:,irep))';
         zmi = squeeze(zm(:,:,irep))';
         umi = ymi - [xmi zmi]*b_avg;
         [bhat(:,irep),tmp1,tmp2]=reg_har_fac(umi,xmi,zmi); 
     end;
     var_bhat = bhat*bhat'/n_init;
     chol_varbhat = chol(var_bhat);
     % Read in power vector and delta values ...
     [dvec,power_inf_dvec]=get_delta(dataparm.m,sz,matcvdir);
     % Select grid of infeasible power values 
     b_inf_power = [0.05 0.25 0.50 0.66 0.75 1.00]';
     n_b = size(b_inf_power,1);
     bvec = NaN(m,n_b);              % bvec contains the departures from null that are considered
     for ib = 1:n_b;
        [tmp,ii]=min(abs(power_inf_dvec-b_inf_power(ib)));
        bvec(:,ib) = dvec(ii)*chol_varbhat(1,:)';
     end;
     bvec = [bvec 100*chol_varbhat(1,:)'];  % add distance departure to check consistency
     n_b = n_b+1;
     
     % Matrices for storing things
     bhat_mat = NaN(m,nrep);
     NW_var_inv_uhatx_mat = NaN(m,m,n_nw,nrep);
     Cos_var_inv_uhatx_mat = NaN(m,m,n_cos,nrep);
     NW_var_inv_ux_mat = NaN(m,m,n_nw,n_b+1,nrep);
     Cos_var_inv_ux_mat = NaN(m,m,n_cos,n_b+1,nrep); 
     parfor irep = 1:nrep; 
         ymi = ym(:,irep);
         xmi = squeeze(xm(:,:,irep))';
         zmi = squeeze(zm(:,:,irep))';
         umi = ymi - [xmi zmi]*b_avg;
         [bhat_mat(:,irep),uhatx,ux_mat]=reg_har_fac_depnull(umi,xmi,zmi,bvec);
         [NW_var_inv_uhatx_mat(:,:,:,irep)]=omega_hat_inv_nw(uhatx,NW_Mat);
         [Cos_var_inv_uhatx_mat(:,:,:,irep)]=omega_hat_inv_cos(uhatx,Cos_Mat,qvec);
         [NW_var_inv_ux_mat(:,:,:,:,irep)]=omega_hat_inv_nw_depnull(ux_mat,NW_Mat);
         [Cos_var_inv_ux_mat(:,:,:,:,irep)]=omega_hat_inv_cos_depnull(ux_mat,Cos_Mat,qvec);  
      end;
      
     % Compute exact power values using elements of bvec
     power_inf_bvec = compute_power_inf_bvec(bhat_mat,bvec,sz);

     % Summarize Type 1 and Type 2 errors;
     % Read in asymptotic critical values
     NW_cv = get_nw_cv(dataparm,kvec,sz,matcvdir);
     Cos_cv = get_cos_cv(dataparm,sz,qvec);
    
     % Compute error frequencies
     NW_uhatx_rslt = data_to_rslt_uxhat(bhat_mat,NW_var_inv_uhatx_mat,NW_cv,sz,bvec,power_inf_bvec,dataparm);
     Cos_uhatx_rslt = data_to_rslt_uxhat(bhat_mat,Cos_var_inv_uhatx_mat,Cos_cv,sz,bvec,power_inf_bvec,dataparm);
     NW_ux_rslt = data_to_rslt_ux(bhat_mat,NW_var_inv_ux_mat,NW_cv,sz,bvec,power_inf_bvec,dataparm);
     Cos_ux_rslt = data_to_rslt_ux(bhat_mat,Cos_var_inv_ux_mat,Cos_cv,sz,bvec,power_inf_bvec,dataparm);
     
      % Save Results
      NW_ux_rslt_mat = rslt_to_mat_randn(NW_ux_rslt,NW_ux_rslt_mat,i_series,nrand_series);
      NW_uhatx_rslt_mat = rslt_to_mat_randn(NW_uhatx_rslt,NW_uhatx_rslt_mat,i_series,nrand_series);
      Cos_ux_rslt_mat = rslt_to_mat_randn(Cos_ux_rslt,Cos_ux_rslt_mat,i_series,nrand_series);
      Cos_uhatx_rslt_mat = rslt_to_mat_randn(Cos_uhatx_rslt,Cos_uhatx_rslt_mat,i_series,nrand_series);  
     
      if i_series == 1
          rslt.ind_series = NaN(size(ind_series,1),nrand_series);
      end
      rslt.ind_series(:,i_series) = ind_series;
  
      tElapsed = toc;
      fprintf(' Seconds =  %6.2f \n',tElapsed);
      
    end;
    rslt.T = T;
    rslt.NW_ux_rslt_mat = NW_ux_rslt_mat;
    rslt.NW_uhatx_rslt_mat = NW_uhatx_rslt_mat;
    rslt.Cos_ux_rslt_mat = Cos_ux_rslt_mat;
    rslt.Cos_uhatx_rslt_mat = Cos_uhatx_rslt_mat;
    if i_dgp == 1
        suf = ['independent_' num2str(i_demean) '_'];
      elseif i_dgp == 2
        suf = ['normal_' num2str(i_demean) '_'];
      elseif i_dgp == 3
        suf = ['empirical_' num2str(i_demean) '_'];
    end
    fstr = [matdir 'rslt_hac_fac_randn_fig8_' suf '_' num2str(iexp)];save(fstr,'rslt'); 
    
end;

path(p);  % Reset path
 