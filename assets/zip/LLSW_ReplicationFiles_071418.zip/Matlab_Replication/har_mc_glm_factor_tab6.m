% Generate MC results to be plotted in Figure 7 .. All series
% MWW, 20180512
%  

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
sdata_dir = '../Factor_Replication/matlab/sdata/';
fac_dir = '../Factor_Replication/matlab/mat/';
matcvdir = 'mat_cv/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

% Some parameters for calculations
sz = 0.05;      % Size to use for calculations

% Demeaning Parameters .. model for data when estimates
i_demean = 1;  % 0 Do Nothing
               % 1 Eliminate low-frequency by local Demeaning
               % 2 Eliminate low-frequency trend by full-sample demeaning;


               % DGP
i_dgp = 2;  % 1 for "independent"; 2 for "normal"; 3 for "empirical");


% Set up Experiment 
iexp = 1;

NW_rslt_mat.size = NaN;
Cos_rslt_mat.size = NaN;

nrand_series = 207;
for i_series = 1:nrand_series;
  tic;
  fprintf('   Series Number %3i: ',[i_series]);
  [y_mat,T] = har_glm_fac_experiment(fac_dir,i_demean,i_dgp,sdata_dir,i_series);
  m = 1;
  dataparm.m = m;
  k = 1;
  dataparm.k = k;
  nrep = size(y_mat,2);
  dataparm.T = T;
  ym = y_mat(1:T,:);
  % Choose Cosine and NW Weights
  [Cos_Mat,qvec,i_qvec] = Cosine_rules_tab6(T);  
  n_cos = size(qvec,1);        % Number of Cos Tests
  [NW_Mat,kvec] = NW_rules_tab6(T);
  n_nw = size(kvec,1);         % Number of NW Tests
    
  % Matrices for Storing Results
    bhat_mat = NaN(m,nrep);
    NW_var_inv_mat = NaN(m,m,n_nw,nrep);
    Cos_var_inv_mat = NaN(m,m,n_cos,nrep);
    parfor irep = 1:nrep; 
        ymi = ym(:,irep);
        bhat_mat(:,irep) = mean(ymi);
        uhat = ymi - mean(ymi);
        [NW_var_mat(:,:,:,irep)]=omega_hat_nw(uhat,NW_Mat);
        [Cos_var_mat(:,:,:,irep)]=omega_hat_cos(uhat,Cos_Mat,qvec);
    end;
    % Standardize problem so that bhat has identity population covariance matrix
    var_bhat = bhat_mat*bhat_mat'/nrep;
    chol_varbhat = chol(var_bhat);
    chol_varbhat_inv = inv(chol_varbhat);
    scl_bhat_mat = chol_varbhat_inv'*bhat_mat;
    % Compute inverse of estimated covariance matrices for standardized problem
    NW_var_inv_mat=omega_hat_inv_scl(NW_var_mat,chol_varbhat_inv);  
    clear NW_var_mat;
    Cos_var_inv_mat=omega_hat_inv_scl(Cos_var_mat,chol_varbhat_inv);  
    clear Cos_var_ux_mat;
    
    % Summarize Type 1 and Type 2 errors;
    % Read in asymptotic critical values
    NW_cv = get_nw_cv(dataparm,kvec,sz,matcvdir);
    Cos_cv = get_cos_cv(dataparm,sz,qvec);
    
    % Read in power vector and delta values ...
    [dvec,power_inf_dvec]=get_delta(dataparm.m,sz,matcvdir);
    
    % Compute error frequencies
    NW_rslt = data_to_rslt(scl_bhat_mat,NW_var_inv_mat,NW_cv,sz,dvec,power_inf_dvec,dataparm);
    Cos_rslt = data_to_rslt(scl_bhat_mat,Cos_var_inv_mat,Cos_cv,sz,dvec,power_inf_dvec,dataparm);
    
    % Save Results
    NW_rslt_mat = rslt_to_mat_randn(NW_rslt,NW_rslt_mat,i_series,nrand_series);
    Cos_rslt_mat = rslt_to_mat_randn(Cos_rslt,Cos_rslt_mat,i_series,nrand_series);  

  tElapsed = toc;
  fprintf(' Seconds =  %6.2f \n',tElapsed);
  
end;
rslt.T = T;
rslt.NW_rslt_mat = NW_rslt_mat;
rslt.Cos_rslt_mat = Cos_rslt_mat;
if i_dgp == 1
        suf = ['independent_' num2str(i_demean) '_'];
elseif i_dgp == 2
        suf = ['normal_' num2str(i_demean) '_'];
elseif i_dgp == 3
        suf = ['empirical_' num2str(i_demean) '_'];
end
fstr = [matdir 'rslt_glm_fac_randn_tab6_' suf '_' num2str(iexp)];save(fstr,'rslt'); 
 
path(p);  % Reset path
 