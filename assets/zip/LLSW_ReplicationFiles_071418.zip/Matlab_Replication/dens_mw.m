function [x,dens] = dens_mw(imw)
% Marron and Wand Density
%
npoints = 500;
if imw == 1  % Gaussian
    xmin = -3.5;
    xmax = 3.5;
    step = (xmax-xmin)/(npoints-1);
    x = (xmin:step:xmax)';
    dens = (1/sqrt(2*pi))*exp(-0.5*(x.^2));
    m1 = 0;
    m2 = 1;
    m3 = 0;
    m4 = 3;
elseif imw == 2;  % Skewed unimodal
    p = [1/5 1/5 3/5];
    m = [0 1/2 13/12];
    s = [1 2/3 5/9];
    k = size(p,2);
    xmin = -3.5;
    xmax = 3.5;
    step = (xmax-xmin)/(npoints-1);
    x = (xmin:step:xmax)';
    dens = zeros(npoints,1);
    for i = 1:k;
        z = (x-m(i))/s(i);
        tmp = (1/sqrt(2*pi))*(1/s(i))*exp(-0.5*(z.^2));
        dens = dens + p(i)*tmp;
    end;
    % Compute Moments
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    sd_y = sqrt(m2 - m1^2);
    x = (x-m1)/sd_y;
    dens = sd_y*dens;
 elseif imw == 3  % Strongly skewed
    p = (1/8)*ones(1,8);
    k = size(p,2);
    m = NaN(1,8);
    s = NaN(1,8);
    for i = 0:7;
       m(i+1) = 3*((2/3)^i-1);
       s(i+1) = (2/3)^i;
    end; 
    xmin = -3.5;
    xmax = 3.5;
    step = (xmax-xmin)/(npoints-1);
    x = (xmin:step:xmax)';
    dens = zeros(npoints,1);
    for i = 1:k;
        z = (x-m(i))/s(i);
        tmp = (1/sqrt(2*pi))*(1/s(i))*exp(-0.5*(z.^2));
        dens = dens + p(i)*tmp;
    end;  
    % Compute Moments
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    sd_y = sqrt(m2 - m1^2);
    x = (x-m1)/sd_y;
    dens = sd_y*dens;
 elseif imw == 4;  % kurtotic unimodal
    p = [2/3 1/3];
    m = [0 0];
    s = [1 1/10];
    k = size(p,2);
    xmin = -3.5;
    xmax = 3.5;
    step = (xmax-xmin)/(npoints-1);
    x = (xmin:step:xmax)';
    dens = zeros(npoints,1);
    for i = 1:k;
        z = (x-m(i))/s(i);
        tmp = (1/sqrt(2*pi))*(1/s(i))*exp(-0.5*(z.^2));
        dens = dens + p(i)*tmp;
    end;
    % Compute Moments
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    sd_y = sqrt(m2 - m1^2);
    x = (x-m1)/sd_y;
    dens = sd_y*dens;
 elseif imw == 5;  % outlier
    p = [1/10 9/10];
    m = [0 0];
    s = [1 1/10];
    k = size(p,2);
    xmin = -3.5;
    xmax = 3.5;
    step = (xmax-xmin)/(npoints-1);
    x = (xmin:step:xmax)';
    dens = zeros(npoints,1);
    for i = 1:k;
        z = (x-m(i))/s(i);
        tmp = (1/sqrt(2*pi))*(1/s(i))*exp(-0.5*(z.^2));
        dens = dens + p(i)*tmp;
    end;
    % Compute Moments
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    sd_y = sqrt(m2 - m1^2);
    x = (x-m1)/sd_y;
    dens = sd_y*dens;
elseif imw == 6;  % bimodal
    p = [1/2 1/2];
    m = [-1 1];
    s = [2/3 2/3];
    k = size(p,2);
    xmin = -3.5;
    xmax = 3.5;
    step = (xmax-xmin)/(npoints-1);
    x = (xmin:step:xmax)';
    dens = zeros(npoints,1);
    for i = 1:k;
        z = (x-m(i))/s(i);
        tmp = (1/sqrt(2*pi))*(1/s(i))*exp(-0.5*(z.^2));
        dens = dens + p(i)*tmp;
    end;
    % Compute Moments
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    sd_y = sqrt(m2 - m1^2);
    x = (x-m1)/sd_y;
    dens = sd_y*dens;
 elseif imw == 7;  % separated bimodal
    p = [1/2 1/2];
    m = [-3/2 3/2];
    s = [1/2 1/2];
    k = size(p,2);
     xmin = -3.5;
    xmax = 3.5;
    step = (xmax-xmin)/(npoints-1);
    x = (xmin:step:xmax)';
    dens = zeros(npoints,1);
    for i = 1:k;
        z = (x-m(i))/s(i);
        tmp = (1/sqrt(2*pi))*(1/s(i))*exp(-0.5*(z.^2));
        dens = dens + p(i)*tmp;
    end;
    % Compute Moments
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    sd_y = sqrt(m2 - m1^2);
    x = (x-m1)/sd_y;
    dens = sd_y*dens;
 elseif imw == 8;  % skewed bimodal
    p = [3/4 1/4];
    m = [0 3/2];
    s = [1 1/3];
    k = size(p,2);
    xmin = -3.5;
    xmax = 3.5;
    step = (xmax-xmin)/(npoints-1);
    x = (xmin:step:xmax)';
    dens = zeros(npoints,1);
    for i = 1:k;
        z = (x-m(i))/s(i);
        tmp = (1/sqrt(2*pi))*(1/s(i))*exp(-0.5*(z.^2));
        dens = dens + p(i)*tmp;
    end    
 elseif imw == 9;  % tri-modal
    p = [9/20 9/20 1/10];
    m = [-6/5 6/5 0];
    s = [3/5 3/5 1/4];
    k = size(p,2);
   xmin = -3.5;
    xmax = 3.5;
    step = (xmax-xmin)/(npoints-1);
    x = (xmin:step:xmax)';
    dens = zeros(npoints,1);
    for i = 1:k;
        z = (x-m(i))/s(i);
        tmp = (1/sqrt(2*pi))*(1/s(i))*exp(-0.5*(z.^2));
        dens = dens + p(i)*tmp;
    end;
    % Compute Moments
    m1 = p*m';
    m2 = p*(m.^2 + s.^2)';
    sd_y = sqrt(m2 - m1^2);
    x = (x-m1)/sd_y;
    dens = sd_y*dens;
end

end
