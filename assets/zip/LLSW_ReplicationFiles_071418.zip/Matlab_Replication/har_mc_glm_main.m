% har_mc_glm_figures_1_3
% MWW, 20180509
% Gaussian Location Model
% Some Results shown in Figure 1 and in Figure 3

clear all;
small = 1.0e-10;
aa=datetime('now','TimeZone','America/New_York');

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
matcvdir = 'mat_cv/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

% Some parameters for calculations
nrep = 50000;
sz = 0.05;      % Size to use for calculations

% Experiment to Run

% Results for Figure 1 and Figure 3a
  experiment_group = 1;
  T = 200;
  rho = 0.7;
  n_experiment = 1;
  m = 1;
  k = 1;
  dataparm.experiment_group = experiment_group;
  dataparm.m = m;
  dataparm.rho = rho;
  dataparm.k = 1;
  dataparm.T = T;
  
%   experiment_group = 2;
%   T = 200;
%   rho = 0.7;
%   m = 1;
%   k = 1;
%   imwvec = [2 3 4 5]';
%   n_experiment = size(imwvec,1);
%   dataparm.experiment_group = experiment_group;
%   dataparm.m = m;
%   dataparm.rho = rho;
%   dataparm.k = 1;
%   dataparm.T = T;
  
% experiment_group = 3;
% T = 200;
% rho = 0.7;
% n_experiment = 1;
% m = 1;
% k = 1;
% % Garch parameters;
% b1 = 0.85;
% b2 = 0.10;
% b0 = (1-b1-b2);  % Unconditional variance = 1;
% b = [b0 b1 b2]';
% dataparm.experiment_group = experiment_group;
% dataparm.m = m;
% dataparm.rho = rho;
% dataparm.k = 1;
% dataparm.T = T;
% dataparm.b = b;

%   experiment_group = 4;
%   Tvec = [100 150 200 250 300 350 400 450 500]';
%   rho = 0.7;
%   n_experiment = size(Tvec,1);
%   m = 1;
%   k = 1;
%   dataparm.experiment_group = experiment_group;
%   dataparm.m = m;
%   dataparm.rho = rho;
%   dataparm.k = 1;
 
  
for i_experiment = 1:n_experiment;
    fprintf('Experiment %4i of %4i: ',[i_experiment n_experiment]);
    tic;
    rng(876997);                            % Same Seed for all experiments
    if experiment_group == 1
        m = dataparm.m;
        T = dataparm.T;
    end
    if experiment_group == 2
        m = dataparm.m;
        T = dataparm.T;
        imw = imwvec(i_experiment);
        dataparm.imw = imw;
    end
    if experiment_group == 3
        m = dataparm.m;
        T = dataparm.T;
    end
    if experiment_group == 4
        m = dataparm.m;
        T = Tvec(i_experiment);
        dataparm.T = T;
    end
    % Choose Cosine and NW Weights
    [Cos_Mat,qvec,i_qvec] = Cosine_rules_glm(T,m); 
    n_cos = size(qvec,1);        % Number of Cos Tests
    [NW_Mat,kvec] = NW_rules_glm(T);
    n_nw = size(kvec,1);         % Number of NW Tests
   
    % Matrices for Storing Results
    bhat_mat = NaN(m,nrep);
    NW_var_mat = NaN(m,m,n_nw,nrep);
    Cos_var_mat = NaN(m,m,n_cos,nrep);
    parfor irep = 1:nrep;    
        [bhat_mat(:,irep),uhat]=gendata_glm(dataparm);
        [NW_var_mat(:,:,:,irep)]=omega_hat_nw(uhat,NW_Mat);
        [Cos_var_mat(:,:,:,irep)]=omega_hat_cos(uhat,Cos_Mat,qvec);
    end;
    % Standardize problem so that bhat has identity population covariance matrix
    var_bhat = bhat_mat*bhat_mat'/nrep;
    chol_varbhat = chol(var_bhat);
    chol_varbhat_inv = inv(chol_varbhat);
    scl_bhat_mat = chol_varbhat_inv'*bhat_mat;
    % Compute inverse of estimated covariance matrices for standardized problem
    NW_var_inv_mat=omega_hat_inv_scl(NW_var_mat,chol_varbhat_inv);  
    clear NW_var_mat;
    Cos_var_inv_mat=omega_hat_inv_scl(Cos_var_mat,chol_varbhat_inv);  
    clear Cos_var_ux_mat;
    
    % Summarize Type 1 and Type 2 errors;
    % Read in asymptotic critical values
    NW_cv = get_nw_cv(dataparm,kvec,sz,matcvdir);
    Cos_cv = get_cos_cv(dataparm,sz,qvec);
    
    % Read in power vector and delta values ...
    [dvec,power_inf_dvec]=get_delta(dataparm.m,sz,matcvdir);
    
    % Compute error frequencies
    NW_rslt = data_to_rslt(scl_bhat_mat,NW_var_inv_mat,NW_cv,sz,dvec,power_inf_dvec,dataparm);
    Cos_rslt = data_to_rslt(scl_bhat_mat,Cos_var_inv_mat,Cos_cv,sz,dvec,power_inf_dvec,dataparm);
    
    % Save Results
    rslt.NW_rslt = NW_rslt;
    rslt.Cos_rslt = Cos_rslt;
    fstr = [matdir 'rslt_glm_' num2str(experiment_group) '_' num2str(i_experiment)];save(fstr,'rslt');
    toc;
 end; 

    
path(p);  % Reset path
 