% Construct NW Critical Values for fixed b for df = m.
% critical values as a function of b=S/T, where S is the truncation term
% approximation based on large T
% 

clear all;
small = 1.0e-10;
rng(88741997);

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat_cv/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

T = 1000;                   % Large T analysis
nrep = 500000;              % Number of replications for CV tests
m_max = 1;
if m_max ~= 1
    error('change acv_sample_uncentered to multivariate version');
end

kfrac = (0.0:0.005:0.99);
kfrac = kfrac';
kvec = floor(T*kfrac);
n_kvec = size(kvec,1);
% Generate NW weight matrix
wght = zeros(n_kvec,T);
wght(:,1) = ones(n_kvec,1);
for ii = 1:n_kvec;
 k = kvec(ii);
 if k > 0
    wght(ii,2:k+1) = (k:-1:1)/(k+1);  % Note .. no factor of 2 because sum is used
 end
end;

F_save = NaN(nrep,n_kvec,m_max);

parfor irep = 1:nrep;
    u = randn(T,m_max);
    ubar = mean(u,1);
    [acv_mat] = acv_sample_uncentered(u,T-1);
    omega_hat_mat = NaN(n_kvec,m_max,m_max);
    for ii = 1:m_max;
        for jj = ii:m_max;
          omega_hat_mat(:,ii,jj) = wght*acv_mat(:,ii,jj)/T;
          omega_hat_mat(:,jj,ii) = omega_hat_mat(:,ii,jj);
        end;
    end;
    for ik = 1:n_kvec;
        for m = 1:m_max;
            omega_hat = squeeze(omega_hat_mat(ik,1:m,1:m));
            om_inv = inv(omega_hat);
            F_save(irep,ik,m) = ubar(1:m)*om_inv*ubar(1:m)'/m;
        end;
    end;
end;

cv_nw_uc_05 = NaN(n_kvec,m_max);
cv_nw_uc_10 = NaN(n_kvec,m_max);
cv_nw_uc_01 = NaN(n_kvec,m_max);
parfor ik = 1:n_kvec;
  for m = 1:m_max
    f = squeeze(F_save(:,ik,m));
    cv_nw_uc_10(ik,m) = pctile(f,0.90);
    cv_nw_uc_05(ik,m) = pctile(f,0.95);
    cv_nw_uc_01(ik,m) = pctile(f,0.99);
  end;
end;

cv_nw_uc_01 = [kfrac cv_nw_uc_01];
cv_nw_uc_05 = [kfrac cv_nw_uc_05];
cv_nw_uc_10 = [kfrac cv_nw_uc_10];

fstr = [matdir 'cv_nw_uc_10'];
save(fstr,'cv_nw_uc_10');
 
fstr = [matdir 'cv_nw_uc_05'];
save(fstr,'cv_nw_uc_05');

fstr = [matdir 'cv_nw_uc_01'];
save(fstr,'cv_nw_uc_01');

path(p);  % Reset path
 