% Compute Figure 1 .. a summary figure
% 20180509
% 

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

sz = 0.05;      % Size to use for calculations
Tvec = linspace(100,500,9)';

% Compute Omega values
ar_coef = 0.7;
n_acv = 1000;
acv = arma_acv(ar_coef,0,n_acv);
acv_0 = acv(1);
acv_L = acv(2:end);
spec_0 = acv_0 + 2*sum(acv_L,1);
tmp = (1:1:n_acv)';
tmp2 = tmp.^2;
sec_1 = 2*sum(tmp.*acv_L,1);
sec_2 = 2*sum(tmp2.*acv_L,1);
omega_1 = sec_1/spec_0;
omega_2 = sec_2/spec_0;
[size_constant_vec,power_constant_vec] = compute_size_power_constants(1,sz);
q_ewc = 2;
kq_ewc = pi^2/6;
int_ksq_ewc = 1;
q_nw = 1;
kq_nw = 1;
int_ksq_nw = 2/3;
q_qs = 2;
kq_qs = pi^2/10;
int_ksq_qs = 6/5;

% Compute Bounds;

Tvec1 = linspace(100,500,50);
% Results for NW
    q = q_nw;
    kq = kq_nw;
    int_ksq = int_ksq_nw;
    omega = omega_1;
    bstar = 1.3*Tvec1.^(-1/2);
    nw_sd_lls = size_constant_vec(1)*omega*kq*(bstar.*Tvec1).^(-q);
    nw_pd_lls = power_constant_vec(1)*(int_ksq*bstar);
    
% Results for ewc
    q = q_ewc;
    kq = kq_ewc;
    int_ksq = int_ksq_ewc;
    omega = omega_2;
    nustar = 0.41*Tvec1.^(2/3);
    bstar = 1./(nustar*int_ksq);
    cos_sd_lls = size_constant_vec(1)*omega*kq*(bstar.*Tvec1).^(-q);
    cos_pd_lls = power_constant_vec(1)*(int_ksq*bstar); 
 
    % % Read in Results
    nw_uhatx_sd = NaN(size(Tvec,1),1);
    nw_uhatx_pd = NaN(size(Tvec,1),1);
    cos_uhatx_sd = NaN(size(Tvec,1),1);
    cos_uhatx_pd = NaN(size(Tvec,1),1);
    nw_ux_sd = NaN(size(Tvec,1),1);
    nw_ux_pd = NaN(size(Tvec,1),1);
    cos_ux_sd = NaN(size(Tvec,1),1);
    cos_ux_pd = NaN(size(Tvec,1),1);
    for i_T = 1:size(Tvec,1);
     i_experiment = i_T;
     fstr = [matdir 'rslt_regression_figure6_' num2str(i_T)];load(fstr);
     NW_uhatx_rslt = rslt.NW_uhatx_rslt;
     Cos_uhatx_rslt = rslt.Cos_uhatx_rslt;
     NW_ux_rslt = rslt.NW_ux_rslt;
     Cos_ux_rslt = rslt.Cos_ux_rslt;
     nw_uhatx_sd(i_T) = NW_uhatx_rslt.size - 0.05;
     cos_uhatx_sd(i_T) = Cos_uhatx_rslt.size - 0.05; 
     nw_uhatx_pd(i_T) = NW_uhatx_rslt.pow_dif_sizeadj;
     cos_uhatx_pd(i_T) = Cos_uhatx_rslt.pow_dif_sizeadj;
     nw_ux_sd(i_T) = NW_ux_rslt.size - 0.05;
     cos_ux_sd(i_T) = Cos_ux_rslt.size - 0.05; 
     nw_ux_pd(i_T) = NW_ux_rslt.pow_dif_sizeadj;
     cos_ux_pd(i_T) = Cos_ux_rslt.pow_dif_sizeadj;  
    end;

    
  axFS = 25;
  MS = 20;
  
  figure;
  subplot(1,2,1);
  
  plot(Tvec1,cos_sd_lls,'- b','LineWidth',3);
  hold on;
    plot(Tvec1,nw_sd_lls,'-- r','LineWidth',3);
  ax = gca;
  ax.FontSize = axFS;
  xlabel('T');
  xlim([100 500]);
  ylim([0 0.20]);
  title('(a) Size Distortion');
  plot(Tvec,cos_uhatx_sd,'bs','LineWidth',3,'MarkerSize',MS);
  plot(Tvec,nw_uhatx_sd,'ro','LineWidth',3,'MarkerSize',MS);
  plot(Tvec,cos_ux_sd,'bs','LineWidth',3,'MarkerSize',MS,'MarkerFaceColor','b');
  plot(Tvec,nw_ux_sd,'ro','LineWidth',3,'MarkerSize',MS,'MarkerFaceColor','r');
  hold off; 
  lgd=legend('EWC: GLM asymptotic frontier','NW: GLM asymptotic frontier','EWC: finite sample','NW: finite sample','EWC: finite sample with null imposed','NW: finite sample with null imposed');
  lgd.FontSize = 20;

  subplot(1,2,2);
  axFS = 25;
  MS = 20;
  plot(Tvec1,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(Tvec1,nw_pd_lls,'-- r','LineWidth',3);
  ax = gca;
  ax.FontSize = axFS;
  xlabel('T');
  xlim([100 500]);
  ylim([0 0.20]);
  title('(b) Power Loss');
  plot(Tvec,cos_uhatx_pd,'bs','LineWidth',3,'MarkerSize',MS);
  plot(Tvec,nw_uhatx_pd,'ro','LineWidth',3,'MarkerSize',MS);
  plot(Tvec,cos_ux_pd,'bs','LineWidth',3,'MarkerSize',MS,'MarkerFaceColor','b');
  plot(Tvec,nw_ux_pd,'ro','LineWidth',3,'MarkerSize',MS,'MarkerFaceColor','r');
  hold off; 
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
  fig_str = 'Figure_6'; str_fig = [figdir fig_str]; 
  saveas(gcf,str_fig);
  saveas(gcf,[str_fig '.png']);
  close(gcf);
  
  axFS = 25;
  MS = 20;
  
  plot(Tvec1,cos_sd_lls,'- b','LineWidth',3);
  hold on;
    plot(Tvec1,nw_sd_lls,'-- r','LineWidth',3);
  ax = gca;
  ax.FontSize = axFS;
  xlabel('T');
  xlim([100 500]);
  ylim([0 0.20]);
  title('(a) Size Distortion');
  plot(Tvec,cos_uhatx_sd,'bs','LineWidth',3,'MarkerSize',MS);
  plot(Tvec,nw_uhatx_sd,'ro','LineWidth',3,'MarkerSize',MS);
  plot(Tvec,cos_ux_sd,'bs','LineWidth',3,'MarkerSize',MS,'MarkerFaceColor','b');
  plot(Tvec,nw_ux_sd,'ro','LineWidth',3,'MarkerSize',MS,'MarkerFaceColor','r');
  hold off; 
  lgd=legend('EWC: GLM asymptotic frontier','NW: GLM asymptotic frontier','EWC: finite sample','NW: finite sample','EWC: finite sample with null imposed','NW: finite sample with null imposed');
  lgd.FontSize = 20;

  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
  fig_str = 'Figure_6a'; str_fig = [figdir fig_str]; 
  saveas(gcf,str_fig);
  saveas(gcf,[str_fig '.png']);
  close(gcf);
 
  
  plot(Tvec1,cos_pd_lls,'- b','LineWidth',3);
  hold on;
    plot(Tvec1,nw_pd_lls,'-- r','LineWidth',3);
  ax = gca;
  ax.FontSize = axFS;
  xlabel('T');
  xlim([100 500]);
  ylim([0 0.20]);
  title('(b) Power Loss');
  plot(Tvec,cos_uhatx_pd,'bs','LineWidth',3,'MarkerSize',MS);
  plot(Tvec,nw_uhatx_pd,'ro','LineWidth',3,'MarkerSize',MS);
  plot(Tvec,cos_ux_pd,'bs','LineWidth',3,'MarkerSize',MS,'MarkerFaceColor','b');
  plot(Tvec,nw_ux_pd,'ro','LineWidth',3,'MarkerSize',MS,'MarkerFaceColor','r');
  hold off; 
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
  set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
  fig_str = 'Figure_6b'; str_fig = [figdir fig_str]; 
  saveas(gcf,str_fig);
  saveas(gcf,[str_fig '.png']);
  close(gcf);
 
path(p);  % Reset path
 