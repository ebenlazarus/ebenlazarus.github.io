% Plot Figure 2

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
matcvdir = 'mat_cv/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

sz = 0.05;      % Size to use for calculations

cos_ux_sd = NaN(3,4);
cos_uhatx_sd = NaN(3,4);
cos_ux_pd = NaN(3,4);
cos_uhatx_pd = NaN(3,4);
nw_ux_sd_mat = NaN(4,4);
nw_uhatx_sd = NaN(4,4);
nw_ux_pd = NaN(4,4);
nw_uhatx_pd = NaN(4,4);
 
for i = 1:4;
    fstr=[matdir 'rslt_regression_figure7_' num2str(i)]; load(fstr);
    NW_ux_rslt = rslt.NW_ux_rslt;
    Cos_ux_rslt = rslt.Cos_ux_rslt;
    NW_uhatx_rslt = rslt.NW_uhatx_rslt;
    Cos_uhatx_rslt = rslt.Cos_uhatx_rslt;
    
    nw_ux_sd(:,i) = NW_ux_rslt.size - sz;
    cos_ux_sd(:,i) = Cos_ux_rslt.size - sz;
    nw_ux_pd(:,i) = NW_ux_rslt.pow_dif_sizeadj;
    cos_ux_pd(:,i) = Cos_ux_rslt.pow_dif_sizeadj;
    
    nw_uhatx_sd(:,i) = NW_uhatx_rslt.size - sz;
    cos_uhatx_sd(:,i) = Cos_uhatx_rslt.size - sz;
    nw_uhatx_pd(:,i) = NW_uhatx_rslt.pow_dif_sizeadj;
    cos_uhatx_pd(:,i) = Cos_uhatx_rslt.pow_dif_sizeadj;
end;

x = (1:1:4)';
w1 = 1.0;
w2 = 0.5;
ax_fs = 15;
lgd_fs = 12;
TitleFS_mult = 1.5;

a1 = max(max(nw_uhatx_sd));
a2 = max(max(cos_ux_pd));
y1 = 0.05*ceil(a1/.05);
y2 = 0.05*ceil(a2/.05);


figure;
for iplot = 1:3;
  subplot(4,4,iplot);
  bar(x,cos_uhatx_sd(iplot,:)',w1,'b');
  hold on;
    bar(x,cos_ux_sd(iplot,:)',w2,'w');
  hold off;
  ax = gca;
  ax.FontSize = ax_fs;
  ylim([0.0 y1]);
  yticks([0 0.05 0.10 0.15 0.20])
  set(gca,'xticklabel',[]);
  if iplot == 1
    lgd=legend('EWC size distortion','EWC size distortion (null imposed)');
    lgd.FontSize = lgd_fs;
  end
  ax.TitleFontSizeMultiplier = TitleFS_mult;
  if iplot == 1
    title('\nu = 7');
  elseif iplot == 2
    title('\nu = 14');  
  elseif iplot == 3
    title('\nu = 21');
  end
end;

for iplot = 1:4;
  subplot(4,4,4+iplot);
  bar(x,nw_uhatx_sd(iplot,:)',w1,'b');
  hold on;
    bar(x,nw_ux_sd(iplot,:)',w2,'w');
  hold off;
  ax = gca;
  ax.FontSize = ax_fs;
  ylim([0.0 y1]);
  yticks([0 0.05 0.10 0.15 0.20])
  set(gca,'xticklabel',[]);
  if iplot == 1
    lgd = legend('NW size distortion','NW size distortion (null imposed)');
    lgd.FontSize = lgd_fs;
  end
  ax.TitleFontSizeMultiplier = TitleFS_mult;
  if iplot == 1
    title('S = 28');
  elseif iplot == 2
    title('S = 19');  
  elseif iplot == 3
    title('S = 10');
  elseif iplot == 4
    title('S = 5');
  end
end;

for iplot = 1:3;
  subplot(4,4,8+iplot);
  bar(x,cos_uhatx_pd(iplot,:)',w1,'b');
  hold on;
    bar(x,cos_ux_pd(iplot,:)',w2,'w');
  hold off;
  ax = gca;
  ax.FontSize = ax_fs;
  ylim([0.0 y2]);
  yticks([0 0.05 0.10 0.15 0.20])
  set(gca,'xticklabel',[]);
  if iplot == 1
    lgd = legend('EWC power loss','EWC power loss (null imposed)');
    lgd.FontSize = lgd_fs;
  end
  ax.TitleFontSizeMultiplier = TitleFS_mult;
  if iplot == 1
    title('\nu = 7');
  elseif iplot == 2
    title('\nu = 14');  
  elseif iplot == 3
    title('\nu = 21');
  end
end;

for iplot = 1:4;
  subplot(4,4,12+iplot);
  bar(x,nw_uhatx_pd(iplot,:)',w1,'b');
  hold on;
    bar(x,nw_ux_pd(iplot,:)',w2,'w');
  hold off;
  ax = gca;
  ax.FontSize = ax_fs;
  ylim([0.0 y2]);
  yticks([0 0.05 0.10 0.15 0.20])
  set(gca,'xticklabel',[]);
  if iplot == 1
    lgd = legend('NW power loss','NW power loss (null imposed)');
    lgd.FontSize = lgd_fs;
  end
  ax.TitleFontSizeMultiplier = TitleFS_mult;
  if iplot == 1
    title('S = 28');
  elseif iplot == 2
    title('S = 19');  
  elseif iplot == 3
    title('S = 10');
  elseif iplot == 4
    title('S = 5');
  end
end;
     
set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
set(gcf, 'Position', get(0, 'Screensize'));  % Full Screen
fig_str = 'Figure_7'; str_fig = [figdir fig_str]; 
saveas(gcf,str_fig);
saveas(gcf,[str_fig '.png']);
close(gcf);
    
path(p);  % Reset path
 