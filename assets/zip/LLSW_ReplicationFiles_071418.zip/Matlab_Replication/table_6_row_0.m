% Plot Figure 2

clear all;
small = 1.0e-10;

% -- File Directories   
figdir = 'fig/';
outdir = 'out/';
matdir = 'mat/';
procs_dir = 'matlab_procs/';            % Directory for necessary matlab_procs and functions
p = path;   % Update path to access procs_dir                              
p0=path(procs_dir,p);    
procs_dir2 = 'm_utilities/';            % Directory for necessary matlab_procs and functions
p1=path(procs_dir2,p0);

% Demeaning Parameters .. model for data when estimates
i_demean = 1;  % 0 Do Nothing
               % 1 Eliminate low-frequency by local Demeaning
               % 2 Eliminate low-frequency trend by full-sample demeaning;
% DGP
%i_dgp = 3;  % 1 for "independent"; 2 for "normal"; 3 for "empirical");
i_dgp = 2;  % 1 for "independent"; 2 for "normal"; 3 for "empirical");

if i_dgp == 1
    suf = ['independent_' num2str(i_demean) '_'];
elseif i_dgp == 2
    suf = ['normal_' num2str(i_demean) '_'];
elseif i_dgp == 3
    suf = ['empirical_' num2str(i_demean) '_'];
end;

% Step 1 .. read in results and save key statistics
iexp = 1;
pct = 0.95;

fstr = [matdir 'rslt_glm_fac_randn_tab6_' suf '_' num2str(iexp)];load(fstr); 
NW_rslt_mat = rslt.NW_rslt_mat;
Cos_rslt_mat = rslt.Cos_rslt_mat;
% Subtract 5% size so these are size distortions
sz = 0.05;
NW_rslt_mat.size_dist = NW_rslt_mat.size - sz;
Cos_rslt_mat.size_dist = Cos_rslt_mat.size - sz;

cos_sd = Cos_rslt_mat.size_dist';
cos_pd = Cos_rslt_mat.pow_dif_sizeadj';
nw_sd = NW_rslt_mat.size_dist(1,:)';
nw_pd = NW_rslt_mat.pow_dif_sizeadj(1,:)';
tb_sd = NW_rslt_mat.size_dist(2,:)';
tb_pd = NW_rslt_mat.pow_dif_sizeadj(2,:)';

cos_sd_pct = pctile(cos_sd,pct);
cos_pd_pct = pctile(cos_pd,pct);
nw_sd_pct = pctile(nw_sd,pct);
nw_pd_pct = pctile(nw_pd,pct);
tb_sd_pct = pctile(tb_sd,pct);
tb_pd_pct = pctile(tb_pd,pct);
tmp = [cos_sd_pct cos_pd_pct nw_sd_pct nw_pd_pct tb_sd_pct tb_pd_pct];
prtmat_comma_screen(tmp,'%5.2f','\n');

    
path(p);  % Reset path
 