
clear;

number=1000;

tables = cell(number,1);


for tt=1:number;
    tt
    [output] = Model(5); 
    tables{tt} = output;
end;
    
results=zeros(4,5);

for r=1:4;
    for c=1:5;
        for i = 1:number
        temp=tables{i};
        temprr(i)=temp(r,c);
        end;
      results(r,c)=mean(temprr);
    end;
end;


rowNames = {'ret', 'alpha','beta', 'beta_dur'};
colNames = {'hml', 'rmw','cma','bab','dur'};

FinalResults = array2table(results,'RowNames',rowNames,'VariableNames',colNames)




writetable(FinalResults,'Sims1000.xlsx','WriteRowNames',true)

