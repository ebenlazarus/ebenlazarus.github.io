% Generates results for Table 5 (multi-horizon returns tests)
%
% Requires MHR_test_linfac_for_dist.m and GeoSum.m from Chernov, Lochstoer, and Lundeby (RFS, 2022),
% which can be downloaded from https://doi.org/10.7910/DVN/4XPIE6.
%
% Tested on MATLAB R2022a

clear;
close all;

if ~isfile('MHR_test_linfac_for_dist.m')
    disp('Warning: Must download additional code from https://doi.org/10.7910/DVN/4XPIE6');
end

addpath(genpath('..'));

% Load data and extract needed series
factors = readmatrix('factors_mhr.csv','NumHeaderLines',1);
rf = factors(:,1);
factors_main = factors(:,2:4);
factors_com = factors(:,[2 5:8]);
horizon = [1 3 6 12 24 48]';

% Run test with three factors and common (FF5) factors
[pval, MAPE, maxSR, maxIR, ~] = MHR_test_linfac_for_dist(rf, factors_main, factors_main, horizon);
[pval_com, MAPE_com, maxSR_com, maxIR_com, ~] = MHR_test_linfac_for_dist(rf, factors_com, factors_main, horizon);

% Report
TestAssets = {'Own Model';'FF5'};
pvals = round([pval;pval_com],3);
meanPEs = round([MAPE;MAPE_com],3);
maxSRs = round([maxSR;maxSR_com],3);
maxIRs = round([maxIR;maxIR_com],3);
result = table(TestAssets,pvals,meanPEs,maxSRs,maxIRs);
disp(result);
