function [output ] =  generate(tt);
clear

%% Initialize constants and compute affine model;
quarters=2000;

g=0.028/4;
rf=0.0193/4;
xbar=0.625;
phi_z=0.91^0.25;
phi_x=0.87^0.25;

sigma_d=[0.0724 0 0];
sigma_z=[-0.0013 0.0009 0];
sigma_x=[0 0 0.12 ];

horizon=400;
nfirms=200;
durlength=100;
share_g = 0.05;

Beta_z=zeros(1,horizon);
Beta_x=zeros(1,horizon);
A=zeros(1,horizon);
V=zeros(horizon,3);

Beta_z(1,1)=1;
Beta_x(1,1)=-sigma_d*transpose(sigma_d)/norm(sigma_d);
A(1,1)=-rf+g+0.5*sigma_d*transpose(sigma_d);
V(1,:)=sigma_d+Beta_z(1,1)*sigma_z+Beta_x(1,1)*sigma_x;

for n=2:horizon;
    Beta_z(1,n)=(1-phi_z^n)/(1-phi_z);
    Beta_x(1,n)=Beta_x(1,n-1)*(phi_x-sigma_x*transpose(sigma_d)/norm(sigma_d))-...
        (sigma_d+Beta_z(1,n-1)*sigma_z)*transpose(sigma_d)/norm(sigma_d);
    A(1,n)=A(1,n-1)-rf+g+Beta_x(1,n-1)*(1-phi_x)*xbar+0.5*V(n-1,:)*transpose(V(n-1,:));
    V(n,1:3)=sigma_d+Beta_z(1,n)*sigma_z+Beta_x(1,n)*sigma_x;
end;



%% Simulate state variables and calculate prices and returns

%rng(108308);

x_t1=zeros(quarters,1);
z_t1=zeros(quarters,1);
div=ones(quarters,1); 
g_t1d=zeros(quarters,1);
r_t1=zeros(quarters, horizon);
re_t1=zeros(quarters, horizon);
rm_t1=zeros(quarters,1);
epremium_t1=zeros(quarters, horizon); 
eterm_t1=zeros(quarters, horizon); 
term_t1=zeros(quarters, horizon); 
pd_true_t1=zeros(quarters, 1); 
tp_t1=zeros(quarters, 1); 


s1_t1=randn(quarters, 1);
s2_t1=randn(quarters, 1);
s3_t1=randn(quarters, 1);

s_t1=[s1_t1 s2_t1 s3_t1];

pd_t1=zeros(quarters, horizon);
yields_t1=zeros(quarters, horizon);
pdm_t1=zeros(quarters,1);

z_t1(1,1)=sigma_z*transpose(s_t1(1,:));
x_t1(1,1)=xbar+sigma_x*transpose(s_t1(1,:));

for i=2:quarters;
    z_t1(i,1)=z_t1(i-1,1)*phi_z+sigma_z*transpose(s_t1(i,:));
    x_t1(i,1)=(1-phi_x)*xbar+phi_x*x_t1(i-1,1)+sigma_x*transpose(s_t1(i,:));
    g_t1d(i,1)=g+z_t1(i-1,1)+sigma_d*transpose(s_t1(i,:));
    div(i,1)=div(i-1,1)+g_t1d(i,1); 
end;
    
for i=2:quarters;
for n=2:horizon-1;
    pd_t1(i,n)=exp(A(1,n)+Beta_x(1,n)*x_t1(i,1)+Beta_z(1,n)*z_t1(i,1));
    yields_t1(i,n)=-log(pd_t1(i,n))/n;
    epremium_t1(i,n)=V(n-1,:)*transpose(sigma_d)*x_t1(i,1)/norm(sigma_d)-rf;
    r_t1(i,n)=epremium_t1(i-1,n)+rf+V(n-1,:)*transpose(s_t1(i,:));
    re_t1(i,n)=epremium_t1(i-1,n)+V(n-1,:)*transpose(s_t1(i,:));
    re_t1(i,n)=(pd_t1(i,n)*exp(div(i,1)))/(pd_t1(i-1,n+1)*exp(div(i-1,1)));
end;
    pdm_t1(i,1)=sum(pd_t1(i,:));
end;



for k=4:quarters;
pd_true_t1(k,1)=log((pdm_t1(k,1))*exp(div(k,1)-div(k-3,1))/(exp(div(k,1)-div(k-3,1))+...
    exp(div(k-1,1)-div(k-3,1))+exp(div(k-2,1)-div(k-3,1))+exp(div(k-3,1)-div(k-3,1))));
end;



syms k; 
s_bottom =  double(1/(1+(1+share_g)^(nfirms/2)+2*symsum((1+share_g)^k,k, 1, nfirms/2-1)));
s_bar = s_bottom*(1+share_g)^(nfirms/2) ;



firms = zeros(quarters,nfirms);


for f=0:(nfirms/2-1)
    firms(1,f+1)=s_bottom*(1+share_g)^f;
    firms(2,f+1)=firms(1,1+f)*(1+share_g);
    
    firms(1,nfirms/2+1+f)=s_bar/((1+share_g)^f);
    firms(2,nfirms/2+1+f)=firms(1,nfirms/2+1+f)/(1+share_g);
end;   



for i=3:quarters;
    for f=1:nfirms;
    if (firms(i-1,f) > firms(i-2,f)) && (firms(i-1,f) < s_bar) 
        firms(i,f)=firms(i-1,f)*(1+share_g) ;
    elseif (firms(i-1,f) > firms(i-2,f)) && (firms(i-1,f) >= s_bar )
        firms(i,f)=firms(i-1,f)/(1+share_g);
               
    elseif  (firms(i-1,f) < firms(i-2,f)) && (firms(i-1,f) > s_bottom )
        firms(i,f)=firms(i-1,f)/(1+share_g);
        
    elseif  (firms(i-1,f) < firms(i-2,f)) && (firms(i-1,f) <= s_bottom )
        firms(i,f)=firms(i-1,f)*(1+share_g)    ;   
    end;   
    end;
end;


%% Cross-section



%for i=2:quarters;
%    for f=1:nfirms;
%    if (firms(i,f) >= firms(i-1,f) && firms(i,f) < s_bar) peak(i,f)=peak(i-1,f)+1 ;
%    elseif (firms(i,f) <= firms(i-1,f) && firms(i,f) < s_bar) peak(i,f)=peak(i-1,f)-1 ;
%    elseif (firms(i,f) >= s_bar)  peak(i,f)=0;
%    end;
%    end;
%end;





firmprice_t = zeros(quarters, nfirms);

for i=1:(quarters-410);
    for f=1:nfirms;
        firmprice_t(i,f)=pd_t1(i,:)*firms((i+1):(horizon+i),f)*div(i);
    end;
end;


firms_returns = zeros(quarters, nfirms);

for i=2:(quarters-410);
    for f=1:nfirms;
        firms_returns(i,f)=(firmprice_t(i,f)+firms(i,f)*div(i))/(firmprice_t(i-1,f))-1;
    end;
end;

firms_erets = zeros(quarters, nfirms);
firms_weights = zeros(horizon, nfirms);

for i=1:(quarters-410);
    for f=1:nfirms;
        firms_weights(:,f)=(transpose(pd_t1(i,:)).*firms((i+1):(horizon+i),f))/(pd_t1(i,:)*firms((i+1):(horizon+i),f));
        firms_erets(i+1,f)=epremium_t1(i,:)*firms_weights(:,f)+rf;
    end;
end;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the characteristics

bookvalue_t = zeros(quarters, nfirms);

%present value of divs

pvdivs = zeros(quarters,horizon);

for i=1:(horizon);
    for j=1:quarters;
        pvdivs(j,1)=div(j);
        pvdivs(j,i+1)=pvdivs(j,i)*exp(g-rf-0.07/4+(phi_z^i)*z_t1(j));
    end;
end;

bookvalue_t = zeros(quarters, nfirms);

roe_t = zeros(quarters, nfirms);


for i=2:(quarters-410);
    for f=1:nfirms;
        bookvalue_t(i,f)=pvdivs(i,:)*firms((i):(horizon+i),f);
        roe_t(i,f)=(firms(i,f)*div(i)) / (pvdivs(i-1,:)*firms((i-1):(horizon+i-1),f));
    end;
end;


dur_t = zeros(quarters, nfirms);
tempdur=1:durlength;

for i=1:(quarters-410);
    for f=1:nfirms;
    dur_t(i,f)=(0.25*(pd_t1(i,1:durlength).*tempdur)*firms((i+1):(durlength+i),f))/((pd_t1(i,1:durlength))*firms((i+1):(durlength+i),f));
    end;
end;






mom_t = zeros(quarters, nfirms);

for i=5:(quarters-410);
    for f=1:nfirms;
    mom_t(i,f)=sum(firms_returns((i-4):(i-1),f)) ;
    end;
end;



mkt_temp = mean(firms_returns(:,:),2); 

tv_t = zeros(quarters, nfirms);

for i=20:(quarters-410);
    for f=1:nfirms;
     betas(:) = regress(firms_returns(i-12:i,f), [ones(13,1) mkt_temp(i-12:i)]);
     tv_t(i,f)= betas(2);
    end;
end;

growth_rates=zeros(quarters, nfirms);
for i=1:(quarters-410);
    for f=1:nfirms;
     growth_rates(i,f)= (firms(i+20,f)/firms(i,f))^(1/5)-1;
    end;
end;



bm_t = bookvalue_t./firmprice_t;
inv_t = vertcat(ones(1,nfirms), bookvalue_t(2:quarters,:)-bookvalue_t(1:(quarters-1),:));


[dursort] = portfolioreturns2(dur_t, firms_returns, quarters, nfirms);
[dursort_dur] = portfolioreturns2(dur_t, dur_t, quarters, nfirms);
%[dursort_growth] = portfolioreturns2(dur_t, growth_rates, 1200, nfirms);
%disp('sort on dur');
%4*(mean(dursort(3:790,:))-rf);

dur_out = zeros((quarters-12), 12);
dur_out(:,1) = dursort(1:(quarters-12),5)-dursort(1:(quarters-12),1);

for i = 2:12
    dur_out(1:(quarters-12),i)=g_t1d(i:(quarters-(13-i)),1);
end;

dur_out_cum = zeros((quarters-12), 12);
dur_out_cum(:,1)=dur_out(:,1);
for i = 2:12
    dur_out_cum(:,i)=sum(dur_out(:,2:i),2);
end;


Y=dur_out_cum(:,1);
G=dur_out_cum(:,2:12);

%plot(corr(Y,G))


clear dur_out dur_out_cum G Y
dur_out = zeros((quarters-12), 12);
dur_out(:,1) = dursort(1:(quarters-12),5)-dursort(1:(quarters-12),1);

for i = 2:12
    dur_out(1:(quarters-12),i)=g_t1d((i-1):(quarters-(14-i)),1);
end;

dur_out_cum = zeros((quarters-12), 12);
dur_out_cum(:,1)=dur_out(:,1);
for i = 2:12
    dur_out_cum(:,i)=sum(dur_out(:,2:i),2);
end;



Y=-dur_out_cum(:,1);
G=dur_out_cum(:,2:12);

for i = 1:11
    tempi=cov(Y,G(:,i));
    cov_out(i)=tempi(1,2);
    clear tempi;
end;

%plot(cov_out)

%cov(Y,G(:,2))





[roesort] = portfolioreturns2(roe_t, firms_returns, quarters, nfirms);
[roesort_dur] = portfolioreturns2(roe_t, dur_t, quarters, nfirms);
%[roesort_growth] = portfolioreturns2(roe_t, growth_rates, 1200, nfirms);
%disp('sort on roe');
%(mean(roesort_dur(3:790,:)))

[invsort] = portfolioreturns2(inv_t, firms_returns, quarters, nfirms);
[invsort_dur] = portfolioreturns2(inv_t, dur_t, quarters, nfirms);
%[invsort_growth] = portfolioreturns2(inv_t, growth_rates, 1200, nfirms);
%disp('sort on inv');
%4*(mean(invsort(3:790,:))-rf);

[bmsort] = portfolioreturns2(bm_t, firms_returns, quarters, nfirms);
[bmsort_dur] = portfolioreturns2(bm_t, dur_t, quarters, nfirms);
%[bmsort_growth] = portfolioreturns2(bm_t, growth_rates, 1200, nfirms);
%disp('sort on bm');
%4*(mean(bmsort(3:790,:))-rf);

[sizesort] = portfolioreturns2(firmprice_t, firms_returns, quarters, nfirms);
[sizesort_dur] = portfolioreturns2(firmprice_t, dur_t, quarters, nfirms);
%[sizesort_growth] = portfolioreturns2(firmprice_t, growth_rates, 1200, nfirms);
%disp('sort on size');
%4*(mean(sizesort(3:790,:))-rf);

[momsort] = portfolioreturns2(mom_t, firms_returns, quarters, nfirms);
[momsort_dur] = portfolioreturns2(mom_t, dur_t, quarters, nfirms);
%[momsort_growth] = portfolioreturns2(mom_t, growth_rates, 1200, nfirms);
%disp('sort on mom');
%4*(mean(momsort(3:790,:))-rf);


[tvsort] = portfolioreturns2(tv_t, firms_returns, quarters, nfirms);
[tvsort_dur] = portfolioreturns2(tv_t, dur_t, quarters, nfirms);
%[tvsort_growth] = portfolioreturns2(tv_t, growth_rates, 1200, nfirms);
%disp('sort on tv');
%4*(mean(tvsort(3:790,:))-rf);
%mean(tvsort_dur)


%Set regression length
rl=700;

%DUR = dursort(3:rl,5)-dursort(3:rl,1);

%DUR = r_t1(3:rl,300)-r_t1(3:rl,10);
DUR = dursort(3:rl,5)-dursort(3:rl,1);

%DUR = r_t1(3:rl,nfirms)-r_t1(3:rl,5);


RMW = roesort(3:rl,5)-roesort(3:rl,1);
CMA = invsort(3:rl,1)-invsort(3:rl,5);
HML = bmsort(3:rl,5)-bmsort(3:rl,1);
SMB = sizesort(3:rl,1)-sizesort(3:rl,5);
UMD = momsort(3:rl,5)-momsort(3:rl,1);
BAB = tvsort(3:rl,1)-tvsort(3:rl,5);
MKT = mean(firms_returns(3:rl,:),2)-rf;


DUR_dur= dursort_dur(3:rl,5)-dursort_dur(3:rl,1);
RMW_dur = roesort_dur(3:rl,5)-roesort_dur(3:rl,1);
CMA_dur = invsort_dur(3:rl,1)-invsort_dur(3:rl,5);
HML_dur = bmsort_dur(3:rl,5)-bmsort_dur(3:rl,1);
SMB_dur = sizesort_dur(3:rl,1)-sizesort_dur(3:rl,5);
UMD_dur = momsort_dur(3:rl,5)-momsort_dur(3:rl,1);
BAB_dur = tvsort_dur(3:rl,1)-tvsort_dur(3:rl,5);
MKT_dur = mean(dur_t(3:rl,:),2);

%RMW_growth = roesort_growth(3:rl,5)-roesort_growth(3:rl,1);
%CMA_growth = invsort_growth(3:rl,1)-invsort_growth(3:rl,5);
%HML_growth = bmsort_growth(3:rl,5)-bmsort_growth(3:rl,1);
%SMB_growth = sizesort_growth(3:rl,1)-sizesort_growth(3:rl,5);
%UMD_growth = momsort_growth(3:rl,5)-momsort_growth(3:rl,1);
%BAB_growth = tvsort_growth(3:rl,1)-tvsort_growth(3:rl,5);
%MKT_growth = mean(firms_returns(3:rl,:),2)-rf;

%DUR = -(RMW+CMA)/2;

mktret = vertcat(ones(1,1), (div(2:quarters).*pdm_t1(2:quarters)+div(2:quarters))./(div(1:(quarters-1)).*pdm_t1(1:(quarters-1)))-1)-rf;

MKT = mktret(3:rl);

% One factor models;

X = [ones(698,1) MKT ];
[bc_r]=regress(RMW, X);
[bc_c]=regress(CMA, X);
[bc_h]=regress(HML, X);
[bc_s]=regress(SMB, X);
[bc_u]=regress(UMD, X);
[bc_b]=regress(BAB, X);
[bc_d]=regress(DUR, X);
bc = [bc_h bc_r bc_c bc_b bc_d];

% Two factor models;

X = [ones(698,1) MKT DUR];
[b2_r]=regress(RMW, X);
[b2_c]=regress(CMA, X);
[b2_h]=regress(HML, X);
[b2_s]=regress(SMB, X);
[b2_u]=regress(UMD, X);
[b2_b]=regress(BAB, X);
[b2_d]=regress(DUR, X);
b2 = [b2_r b2_c b2_h b2_s b2_u b2_b b2_d];

factors_xret = mean([HML RMW CMA BAB DUR],1);

factors_dur = mean([HML_dur RMW_dur CMA_dur BAB_dur DUR_dur  ], 1);

factors_dur = mean([HML_dur RMW_dur CMA_dur BAB_dur DUR_dur ], 1);

output = vertcat(factors_xret, bc*100/3, factors_dur);
