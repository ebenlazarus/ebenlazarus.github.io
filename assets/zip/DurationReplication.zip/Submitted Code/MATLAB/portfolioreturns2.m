function[returns] = portfolioreturns2(sort, retfile, quarters, nfirmss);

portfolios=zeros(quarters,5);

for i = 1:(quarters-1);
    pctiles=prctile(sort(i,:),1:100);
       %for j = 1 :200;
       for j = 1 :nfirmss; 
       if (sort(i,j) <= pctiles(20) )
           portfolios(i+1,1)=portfolios(i+1,1)+retfile(i+1,j)/(nfirmss/5);
        
        elseif (sort(i,j) > pctiles(20)) && (sort(i,j) <= pctiles(40))
           portfolios(i+1,2)=portfolios(i+1,2)+retfile(i+1,j)/(nfirmss/5);
           
        elseif (sort(i,j) > pctiles(40)) && (sort(i,j) <= pctiles(60))
           portfolios(i+1,3)=portfolios(i+1,3)+retfile(i+1,j)/(nfirmss/5);
        
        elseif (sort(i,j) > pctiles(60)) && (sort(i,j) <= pctiles(80))
           portfolios(i+1,4)=portfolios(i+1,4)+retfile(i+1,j)/(nfirmss/5);
        
        elseif (sort(i,j) > pctiles(80)) 
           portfolios(i+1,5)=portfolios(i+1,5)+retfile(i+1,j)/(nfirmss/5);
        
        end;
       end;
end;
returns = portfolios;